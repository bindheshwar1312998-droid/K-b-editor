package com.aistudio.kbeditor.r7v4qx.model

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
enum class AspectRatioPreset(val label: String, val widthRatio: Float, val heightRatio: Float) {
    RATIO_9_16("9:16", 9f, 16f),
    RATIO_16_9("16:9", 16f, 9f),
    RATIO_1_1("1:1", 1f, 1f),
    RATIO_4_5("4:5", 4f, 5f),
    RATIO_21_9("21:9", 21f, 9f)
}

@Serializable
enum class CanvasFillMode(val label: String) {
    FILL_CROP("Fill / Crop"),
    BLUR_CANVAS("Blur Canvas"),
    SOLID_COLOR("Solid Color")
}

@Serializable
enum class SpeedRampPreset(val label: String) {
    CONSTANT("Constant"),
    HERO_DIP("Hero Dip"),
    FLASH_IN("Flash In"),
    BULLET_TIME("Bullet Time"),
    BUILD_UP("Build Up")
}

@Serializable
enum class MaskType(val label: String) {
    NONE("None"),
    CIRCLE("Circle"),
    ROUNDED_RECT("Rounded"),
    SPLIT_WIPE("Split Wipe"),
    ANAMORPHIC_BARS("2.39:1 Bars")
}

@Serializable
enum class MotionAnimation3D(val label: String) {
    NONE("Static"),
    POP_3D("Pop 3D"),
    FLIP_3D("Flip 3D"),
    FLOAT_NEON("Float Neon"),
    TYPEWRITER("Typewriter"),
    GLITCH_PULSE("Glitch Pulse"),
    SLIDE_KINETIC("Slide Kinetic")
}

@Serializable
enum class BlendModePreset(val label: String) {
    NORMAL("Normal"),
    SCREEN("Screen"),
    MULTIPLY("Multiply"),
    ADD("Add"),
    OVERLAY("Overlay")
}

@Serializable
enum class TransitionType(val label: String) {
    NONE("Cut"),
    CROSS_DISSOLVE("Dissolve"),
    WHIP_PAN("Whip Pan"),
    FLASH_CUT("Flash"),
    ZOOM_THROUGH("Zoom")
}

@Serializable
enum class VocalIsolationMode(val label: String) {
    FULL_MIX("Full Mix"),
    ISOLATE_VOCALS("Vocals Only"),
    INSTRUMENTAL_ONLY("Instrumental")
}

@Serializable
enum class ExportResolution(val label: String, val widthPx: Int, val heightPx: Int) {
    HD_720("720p", 1280, 720),
    FHD_1080("1080p", 1920, 1080),
    UHD_4K("4K UHD", 3840, 2160)
}

@Serializable
enum class ExportFps(val value: Int, val label: String) {
    FPS_24(24, "24 fps"),
    FPS_30(30, "30 fps"),
    FPS_60(60, "60 fps")
}

@Serializable
enum class ExportDynamicRange(val label: String) {
    SDR_8BIT("SDR 8-bit (H.264)"),
    HDR10_HLG("HDR10 HLG (10-bit HEVC)")
}

@Serializable
data class ColorWheelPoint(
    val dx: Float = 0f,
    val dy: Float = 0f,
    val luma: Float = 0f
)

@Serializable
data class ColorGradeSpec(
    val lift: ColorWheelPoint = ColorWheelPoint(),
    val gamma: ColorWheelPoint = ColorWheelPoint(),
    val gain: ColorWheelPoint = ColorWheelPoint(),
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val warmth: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val vignette: Float = 0f,
    val beautySmooth: Float = 0f,
    val beautyGlow: Float = 0f,
    val lutName: String = "Neutral"
)

@Serializable
data class ChromaKeySpec(
    val enabled: Boolean = false,
    val keyHue: String = "Green",
    val tolerance: Float = 0.25f,
    val spillSuppression: Float = 0.4f,
    val aiAutoCut: Boolean = false,
    val studioBackdropHex: Long = 0xFF0F172A
)

@Serializable
data class KeyframePoint(
    val normalizedTime: Float,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val scale: Float = 1f,
    val rotationDeg: Float = 0f,
    val opacity: Float = 1f
)

@Serializable
data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Clip",
    val mediaUri: String = "",
    val isAiGeneratedBroll: Boolean = false,
    val sourceDurationMs: Long = 6000L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 6000L,
    val slipOffsetMs: Long = 0L,
    val speedMultiplier: Float = 1f,
    val speedRamp: SpeedRampPreset = SpeedRampPreset.CONSTANT,
    val opticalFlowEnabled: Boolean = true,
    val volume: Float = 1f,
    val muted: Boolean = false,
    val colorGrade: ColorGradeSpec = ColorGradeSpec(),
    val maskType: MaskType = MaskType.NONE,
    val maskFeather: Float = 0.08f,
    val chromaKey: ChromaKeySpec = ChromaKeySpec(),
    val keyframes: List<KeyframePoint> = emptyList(),
    val motionTrackPoints: List<KeyframePoint> = emptyList(),
    val transitionOut: TransitionType = TransitionType.NONE,
    val transitionDurationMs: Long = 400L,
    val reframeOffsetX: Float = 0f
) {
    val activeDurationMs: Long
        get() = ((trimEndMs - trimStartMs).coerceAtLeast(300L) / speedMultiplier.coerceAtLeast(0.25f)).toLong()
}

@Serializable
data class OverlayPipClip(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "PiP Overlay",
    val mediaUri: String = "",
    val opticalFxPreset: String? = null,
    val startMs: Long = 0L,
    val durationMs: Long = 3500L,
    val blendMode: BlendModePreset = BlendModePreset.SCREEN,
    val opacity: Float = 0.85f,
    val posX: Float = 0.5f,
    val posY: Float = 0.5f,
    val scale: Float = 0.55f,
    val rotationDeg: Float = 0f
)

@Serializable
data class CaptionClip(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "KB EDITOR PRO",
    val startMs: Long = 0L,
    val durationMs: Long = 3000L,
    val animation3D: MotionAnimation3D = MotionAnimation3D.POP_3D,
    val posX: Float = 0.5f,
    val posY: Float = 0.8f,
    val fontSizeSp: Float = 24f,
    val colorHex: Long = 0xFFF8FAFC,
    val accentHex: Long = 0xFF22D3EE,
    val trackedToClipId: String? = null
)

@Serializable
data class AudioClip(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Audio Track",
    val mediaUri: String = "",
    val startMs: Long = 0L,
    val durationMs: Long = 6000L,
    val volume: Float = 1f,
    val windFilterEnabled: Boolean = false,
    val noiseGateEnabled: Boolean = false,
    val vocalMode: VocalIsolationMode = VocalIsolationMode.FULL_MIX,
    val beatMarkersMs: List<Long> = emptyList(),
    val isVoiceover: Boolean = false
)

@Serializable
data class TrackState(
    val v1Locked: Boolean = false,
    val v1Visible: Boolean = true,
    val o1Locked: Boolean = false,
    val o1Visible: Boolean = true,
    val t1Locked: Boolean = false,
    val t1Visible: Boolean = true,
    val a1Locked: Boolean = false,
    val a1Muted: Boolean = false
)

@Serializable
data class ExportSettings(
    val resolution: ExportResolution = ExportResolution.FHD_1080,
    val fps: ExportFps = ExportFps.FPS_60,
    val dynamicRange: ExportDynamicRange = ExportDynamicRange.SDR_8BIT
)

@Serializable
data class KbEditorProject(
    val projectName: String = "Studio Sequence 01",
    val aspectRatio: AspectRatioPreset = AspectRatioPreset.RATIO_9_16,
    val canvasFillMode: CanvasFillMode = CanvasFillMode.FILL_CROP,
    val canvasBlurRadius: Float = 24f,
    val canvasSolidColorHex: Long = 0xFF090D16,
    val safeZoneVisible: Boolean = false,
    val tracks: TrackState = TrackState(),
    val videoClips: List<VideoClip> = defaultSampleVideoClips(),
    val pipClips: List<OverlayPipClip> = emptyList(),
    val captionClips: List<CaptionClip> = listOf(
        CaptionClip(
            text = "SHOT ON KB STUDIO",
            startMs = 200L,
            durationMs = 2800L,
            animation3D = MotionAnimation3D.POP_3D
        )
    ),
    val audioClips: List<AudioClip> = emptyList(),
    val exportSettings: ExportSettings = ExportSettings()
) {
    val totalDurationMs: Long
        get() {
            val vEnd = videoClips.sumOf { it.activeDurationMs }
            val oEnd = pipClips.maxOfOrNull { it.startMs + it.durationMs } ?: 0L
            val tEnd = captionClips.maxOfOrNull { it.startMs + it.durationMs } ?: 0L
            val aEnd = audioClips.maxOfOrNull { it.startMs + it.durationMs } ?: 0L
            return maxOf(vEnd, oEnd, tEnd, aEnd, 1000L)
        }
}

fun defaultSampleVideoClips(): List<VideoClip> = listOf(
    VideoClip(
        title = "A-Roll Intro",
        sourceDurationMs = 5000L,
        trimStartMs = 0L,
        trimEndMs = 5000L,
        transitionOut = TransitionType.CROSS_DISSOLVE
    ),
    VideoClip(
        title = "B-Roll Hero",
        sourceDurationMs = 4500L,
        trimStartMs = 0L,
        trimEndMs = 4500L,
        speedRamp = SpeedRampPreset.HERO_DIP
    )
)
