package com.aistudio.kbeditor.r7v4qx.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.aistudio.kbeditor.r7v4qx.model.KbEditorProject
import com.aistudio.kbeditor.r7v4qx.model.TrackState
import com.aistudio.kbeditor.r7v4qx.ui.theme.*

@Composable
fun MultiTrackTimeline(
    project: KbEditorProject,
    playheadMs: Long,
    selectedVideoIndex: Int,
    onSelectVideo: (Int) -> Unit,
    onSeekMs: (Long) -> Unit,
    onToggleTrack: ((TrackState) -> TrackState) -> Unit,
    onOpenSheet: (ActiveStudioSheet) -> Unit,
    onSplitClip: () -> Unit,
    onRippleDelete: () -> Unit,
    onMoveClip: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val pxPerSec = 42.dp

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SlateBase, RoundedCornerShape(14.dp))
            .border(1.dp, SlateBorder, RoundedCornerShape(14.dp))
            .padding(8.dp)
    ) {
        // Timecode + Playhead Scrub Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = formatTimecode(playheadMs),
                style = MaterialTheme.typography.labelMedium,
                color = ElectricCyan
            )
            Slider(
                value = playheadMs.toFloat(),
                onValueChange = { onSeekMs(it.toLong()) },
                valueRange = 0f..project.totalDurationMs.toFloat().coerceAtLeast(1000f),
                colors = SliderDefaults.colors(
                    thumbColor = ElectricCyan,
                    activeTrackColor = ElectricCyan,
                    inactiveTrackColor = SlateElevated
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(24.dp)
                    .padding(horizontal = 8.dp)
            )
            Text(
                text = formatTimecode(project.totalDurationMs),
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }

        Spacer(Modifier.height(6.dp))

        // 4-Track Magnetic Lanes: V1, O1, T1, A1
        Row(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.width(68.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TrackHeaderCell(
                    label = "V1",
                    accent = ElectricCyan,
                    locked = project.tracks.v1Locked,
                    active = project.tracks.v1Visible,
                    onToggleLock = { onToggleTrack { it.copy(v1Locked = !it.v1Locked) } },
                    onToggleActive = { onToggleTrack { it.copy(v1Visible = !it.v1Visible) } }
                )
                TrackHeaderCell(
                    label = "O1",
                    accent = VioletClip,
                    locked = project.tracks.o1Locked,
                    active = project.tracks.o1Visible,
                    onToggleLock = { onToggleTrack { it.copy(o1Locked = !it.o1Locked) } },
                    onToggleActive = { onToggleTrack { it.copy(o1Visible = !it.o1Visible) } }
                )
                TrackHeaderCell(
                    label = "T1",
                    accent = WarmAmber,
                    locked = project.tracks.t1Locked,
                    active = project.tracks.t1Visible,
                    onToggleLock = { onToggleTrack { it.copy(t1Locked = !it.t1Locked) } },
                    onToggleActive = { onToggleTrack { it.copy(t1Visible = !it.t1Visible) } }
                )
                TrackHeaderCell(
                    label = "A1",
                    accent = EmeraldTrack,
                    locked = project.tracks.a1Locked,
                    active = !project.tracks.a1Muted,
                    onToggleLock = { onToggleTrack { it.copy(a1Locked = !it.a1Locked) } },
                    onToggleActive = { onToggleTrack { it.copy(a1Muted = !it.a1Muted) } }
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // V1 Video Lane
                Row(
                    modifier = Modifier.height(34.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    project.videoClips.forEachIndexed { idx, clip ->
                        val widthDp = (clip.activeDurationMs / 1000f * pxPerSec.value).coerceIn(72f, 260f).dp
                        val selected = idx == selectedVideoIndex
                        Box(
                            modifier = Modifier
                                .width(widthDp)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) ElectricCyan.copy(alpha = 0.25f) else SlateElevated)
                                .border(
                                    width = if (selected) 1.5.dp else 1.dp,
                                    color = if (selected) ElectricCyan else SlateBorder,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelectVideo(idx) }
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = clip.title,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextPrimary,
                                maxLines = 1
                            )
                        }
                        if (idx < project.videoClips.lastIndex) {
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .background(SlateVoid, RoundedCornerShape(4.dp))
                                    .border(1.dp, SlateBorder, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = clip.transitionOut.label.take(3),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WarmAmber
                                )
                            }
                        }
                    }
                }

                // O1 PiP Overlay Lane
                Row(
                    modifier = Modifier.height(28.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (project.pipClips.isEmpty()) {
                        EmptyTrackHint("Tap PiP to add overlay", Modifier.clickable { onOpenSheet(ActiveStudioSheet.PIP_OVERLAY) })
                    } else {
                        project.pipClips.forEach { pip ->
                            Box(
                                modifier = Modifier
                                    .width(110.dp)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(VioletClip.copy(alpha = 0.22f))
                                    .border(1.dp, VioletClip, RoundedCornerShape(6.dp))
                                    .clickable { onOpenSheet(ActiveStudioSheet.PIP_OVERLAY) }
                                    .padding(horizontal = 6.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = "${pip.title} (${pip.blendMode.label})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // T1 Caption Lane
                Row(
                    modifier = Modifier.height(28.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (project.captionClips.isEmpty()) {
                        EmptyTrackHint("Tap 3D Text to add caption", Modifier.clickable { onOpenSheet(ActiveStudioSheet.CAPTION_3D) })
                    } else {
                        project.captionClips.forEach { cap ->
                            Box(
                                modifier = Modifier
                                    .width(120.dp)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(WarmAmber.copy(alpha = 0.20f))
                                    .border(1.dp, WarmAmber, RoundedCornerShape(6.dp))
                                    .clickable { onOpenSheet(ActiveStudioSheet.CAPTION_3D) }
                                    .padding(horizontal = 6.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = cap.text,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // A1 Audio Lane
                Row(
                    modifier = Modifier.height(28.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (project.audioClips.isEmpty()) {
                        EmptyTrackHint("Extract Audio or AI Voiceover", Modifier.clickable { onOpenSheet(ActiveStudioSheet.AUDIO_PRO) })
                    } else {
                        project.audioClips.forEach { audio ->
                            Box(
                                modifier = Modifier
                                    .width(140.dp)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(EmeraldTrack.copy(alpha = 0.20f))
                                    .border(1.dp, EmeraldTrack, RoundedCornerShape(6.dp))
                                    .clickable { onOpenSheet(ActiveStudioSheet.AUDIO_PRO) }
                                    .padding(horizontal = 6.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = "${audio.title} • ${audio.beatMarkersMs.size}♪",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Pro Studio Action Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            StudioActionPill("Split", Icons.Default.ContentCut, onClick = onSplitClip)
            StudioActionPill("Ripple Del", Icons.Default.DeleteSweep, onClick = onRippleDelete)
            StudioActionPill("Left", Icons.Default.ChevronLeft, onClick = { onMoveClip(-1) })
            StudioActionPill("Right", Icons.Default.ChevronRight, onClick = { onMoveClip(1) })
            StudioActionPill("Color Wheels", Icons.Default.Palette, onClick = { onOpenSheet(ActiveStudioSheet.COLOR_WHEELS) })
            StudioActionPill("Speed Ramp", Icons.Default.Speed, onClick = { onOpenSheet(ActiveStudioSheet.SPEED_RAMP) })
            StudioActionPill("VFX/Mask", Icons.Default.AutoFixHigh, onClick = { onOpenSheet(ActiveStudioSheet.VFX_CHROMA_MASK) })
            StudioActionPill("Track 2D", Icons.Default.MyLocation, onClick = { onOpenSheet(ActiveStudioSheet.MOTION_TRACKER) })
            StudioActionPill("PiP", Icons.Default.Layers, onClick = { onOpenSheet(ActiveStudioSheet.PIP_OVERLAY) })
            StudioActionPill("3D Text", Icons.Default.TextFields, onClick = { onOpenSheet(ActiveStudioSheet.CAPTION_3D) })
            StudioActionPill("Audio Pro", Icons.Default.GraphicEq, onClick = { onOpenSheet(ActiveStudioSheet.AUDIO_PRO) })
            StudioActionPill("Auto-Edit", Icons.Default.AutoAwesome, onClick = { onOpenSheet(ActiveStudioSheet.AUTO_CREATOR) })
        }
    }
}

@Composable
private fun TrackHeaderCell(
    label: String,
    accent: Color,
    locked: Boolean,
    active: Boolean,
    onToggleLock: () -> Unit,
    onToggleActive: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
            .background(SlateVoid, RoundedCornerShape(6.dp))
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = accent)
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Icon(
                imageVector = if (locked) Icons.Default.Lock else Icons.Default.LockOpen,
                contentDescription = "Lock $label",
                tint = if (locked) CoralAmber else TextMuted,
                modifier = Modifier
                    .size(14.dp)
                    .clickable(onClick = onToggleLock)
            )
            Icon(
                imageVector = if (active) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                contentDescription = "Toggle $label",
                tint = if (active) accent else TextMuted,
                modifier = Modifier
                    .size(14.dp)
                    .clickable(onClick = onToggleActive)
            )
        }
    }
}

@Composable
private fun EmptyTrackHint(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .width(180.dp)
            .fillMaxHeight()
            .background(SlateVoid.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .border(1.dp, SlateBorder.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = TextMuted)
    }
}

@Composable
private fun StudioActionPill(label: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = SlateElevated,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(14.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextPrimary)
        }
    }
}

private fun formatTimecode(ms: Long): String {
    val totalSec = ms / 1000L
    val min = totalSec / 60L
    val sec = totalSec % 60L
    val frames = (ms % 1000L) / 33L
    return "%02d:%02d:%02d".format(min, sec, frames)
}
