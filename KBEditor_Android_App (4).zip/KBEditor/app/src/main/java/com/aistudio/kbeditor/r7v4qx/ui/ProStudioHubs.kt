package com.aistudio.kbeditor.r7v4qx.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aistudio.kbeditor.r7v4qx.model.*
import com.aistudio.kbeditor.r7v4qx.ui.theme.ElectricCyan
import com.aistudio.kbeditor.r7v4qx.ui.theme.TextMuted
import com.aistudio.kbeditor.r7v4qx.ui.theme.TextPrimary

@Composable
fun PipOverlaySheet(
    onPickPipMedia: () -> Unit,
    onAddOpticalPreset: (String, BlendModePreset) -> Unit
) {
    var selectedBlend by remember { mutableStateOf(BlendModePreset.SCREEN) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("PiP Overlays & Blend Modes (Track O1)", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Text("Blend Mode", style = MaterialTheme.typography.labelSmall, color = TextMuted)

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BlendModePreset.entries.forEach { mode ->
                FilterChip(
                    selected = selectedBlend == mode,
                    onClick = { selectedBlend = mode },
                    label = { Text(mode.label) }
                )
            }
        }

        Button(onClick = onPickPipMedia, modifier = Modifier.fillMaxWidth()) {
            Text("Import Photo / Video PiP Overlay")
        }

        Text("Optical FX Presets", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Neon Light Leak", "Anamorphic Flare", "Cyber HUD Grid").forEach { preset ->
                OutlinedButton(onClick = { onAddOpticalPreset(preset, selectedBlend) }) {
                    Text(preset)
                }
            }
        }
    }
}

@Composable
fun Caption3DSheet(
    onAddCaption: (String, MotionAnimation3D) -> Unit
) {
    var text by remember { mutableStateOf("SHOT ON KB STUDIO") }
    var anim by remember { mutableStateOf(MotionAnimation3D.POP_3D) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("3D Motion Text (Track T1)", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Caption Text") },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            MotionAnimation3D.entries.take(4).forEach { preset ->
                FilterChip(
                    selected = anim == preset,
                    onClick = { anim = preset },
                    label = { Text(preset.label) }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            MotionAnimation3D.entries.drop(4).forEach { preset ->
                FilterChip(
                    selected = anim == preset,
                    onClick = { anim = preset },
                    label = { Text(preset.label) }
                )
            }
        }
        Button(onClick = { onAddCaption(text, anim) }, modifier = Modifier.fillMaxWidth()) {
            Text("Add 3D Caption at Playhead")
        }
    }
}

@Composable
fun AudioProSheet(
    audioClip: AudioClip?,
    onExtractAudio: () -> Unit,
    onUpdateDsp: (Boolean, Boolean, VocalIsolationMode) -> Unit,
    onDetectBeats: () -> Unit,
    onGenerateVoiceover: (String, String) -> Unit
) {
    var wind by remember { mutableStateOf(audioClip?.windFilterEnabled ?: false) }
    var gate by remember { mutableStateOf(audioClip?.noiseGateEnabled ?: false) }
    var vocalMode by remember { mutableStateOf(audioClip?.vocalMode ?: VocalIsolationMode.FULL_MIX) }
    var voScript by remember { mutableStateOf("") }
    var voLang by remember { mutableStateOf("en-US") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Audio Pro & AI DSP (Track A1)", style = MaterialTheme.typography.titleMedium, color = TextPrimary)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onExtractAudio, modifier = Modifier.weight(1f)) {
                Text("Extract Audio")
            }
            OutlinedButton(onClick = onDetectBeats, modifier = Modifier.weight(1f)) {
                Text("Auto-Beat Sync")
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("High-Pass Wind Filter", color = TextPrimary, modifier = Modifier.weight(1f))
            Switch(checked = wind, onCheckedChange = {
                wind = it
                onUpdateDsp(wind, gate, vocalMode)
            })
        }

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Studio Noise Gate", color = TextPrimary, modifier = Modifier.weight(1f))
            Switch(checked = gate, onCheckedChange = {
                gate = it
                onUpdateDsp(wind, gate, vocalMode)
            })
        }

        Text("Mid/Side Vocal Isolator", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            VocalIsolationMode.entries.forEach { mode ->
                FilterChip(
                    selected = vocalMode == mode,
                    onClick = {
                        vocalMode = mode
                        onUpdateDsp(wind, gate, vocalMode)
                    },
                    label = { Text(mode.label) }
                )
            }
        }

        HorizontalDivider()
        Text("Multilingual AI Voiceover (TTS)", style = MaterialTheme.typography.labelSmall, color = ElectricCyan)
        OutlinedTextField(
            value = voScript,
            onValueChange = { voScript = it },
            label = { Text("Voiceover Script") },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("en-US" to "English", "hi-IN" to "Hindi", "es-ES" to "Spanish").forEach { (tag, label) ->
                FilterChip(
                    selected = voLang == tag,
                    onClick = { voLang = tag },
                    label = { Text(label) }
                )
            }
        }
        Button(
            onClick = { onGenerateVoiceover(voScript, voLang) },
            enabled = voScript.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Synthesize Voiceover to A1")
        }
    }
}

@Composable
fun AutoCreatorSheet(
    onRunAutoCreator: (String) -> Unit,
    onGenerateAiBroll: (String) -> Unit
) {
    var prompt by remember { mutableStateOf("High-energy cinematic reel with teal orange LUT and hero dip speed ramp") }
    var brollPrompt by remember { mutableStateOf("Futuristic neon city skyline at night") }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("One-Prompt AI Auto-Creator", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text("Describe your full edit") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { onRunAutoCreator(prompt) }, modifier = Modifier.fillMaxWidth()) {
            Text("Run Gemini 3.8 Flash Auto-Edit")
        }

        HorizontalDivider()
        Text("Text-to-Video Generative B-Roll", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        OutlinedTextField(
            value = brollPrompt,
            onValueChange = { brollPrompt = it },
            label = { Text("B-Roll Scene Prompt") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = { onGenerateAiBroll(brollPrompt) }, modifier = Modifier.fillMaxWidth()) {
            Text("Generate AI B-Roll onto V1")
        }
    }
}
