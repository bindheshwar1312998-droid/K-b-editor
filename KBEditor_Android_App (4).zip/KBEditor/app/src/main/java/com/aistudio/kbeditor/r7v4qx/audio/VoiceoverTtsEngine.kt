package com.aistudio.kbeditor.r7v4qx.audio

import android.content.Context
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

class VoiceoverTtsEngine(private val context: Context) {

    suspend fun synthesizeVoiceover(
        scriptText: String,
        languageTag: String = "en-US"
    ): Result<Pair<String, Long>> = suspendCancellableCoroutine { cont ->
        if (scriptText.isBlank()) {
            cont.resume(Result.failure(IllegalArgumentException("Voiceover script cannot be empty")))
            return@suspendCancellableCoroutine
        }

        var tts: TextToSpeech? = null
        val outFile = File(context.cacheDir, "kb_vo_${System.currentTimeMillis()}.wav")
        val utteranceId = "vo_${System.currentTimeMillis()}"

        tts = TextToSpeech(context) { status ->
            if (status != TextToSpeech.SUCCESS) {
                if (cont.isActive) cont.resume(Result.failure(IllegalStateException("TTS initialization failed")))
                tts?.shutdown()
                return@TextToSpeech
            }
            tts?.language = Locale.forLanguageTag(languageTag)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) = Unit
                override fun onDone(id: String?) {
                    val estDurationMs = (scriptText.split(Regex("\\s+")).size * 420L).coerceAtLeast(1500L)
                    if (cont.isActive) {
                        cont.resume(Result.success(Uri.fromFile(outFile).toString() to estDurationMs))
                    }
                    tts?.shutdown()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    if (cont.isActive) cont.resume(Result.failure(IllegalStateException("TTS synthesis failed")))
                    tts?.shutdown()
                }
            })
            tts?.synthesizeToFile(scriptText, null, outFile, utteranceId)
        }

        cont.invokeOnCancellation {
            tts?.stop()
            tts?.shutdown()
        }
    }
}
