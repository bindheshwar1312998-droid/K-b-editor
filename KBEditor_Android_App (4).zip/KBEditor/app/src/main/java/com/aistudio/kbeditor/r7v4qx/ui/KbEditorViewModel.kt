package com.aistudio.kbeditor.r7v4qx.ui

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import com.aistudio.kbeditor.r7v4qx.ai.GeminiStudioEngine
import com.aistudio.kbeditor.r7v4qx.audio.AudioBeatDetector
import com.aistudio.kbeditor.r7v4qx.audio.AudioExtractorEngine
import com.aistudio.kbeditor.r7v4qx.audio.VoiceoverTtsEngine
import com.aistudio.kbeditor.r7v4qx.media.VideoExportEngine
import com.aistudio.kbeditor.r7v4qx.model.*
import com.aistudio.kbeditor.r7v4qx.storage.ProjectStorage
import com.aistudio.kbeditor.r7v4qx.vision.SmartVisionEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ActiveStudioSheet {
    NONE,
    COLOR_WHEELS,
    SPEED_RAMP,
    VFX_CHROMA_MASK,
    MOTION_TRACKER,
    PIP_OVERLAY,
    CAPTION_3D,
    AUDIO_PRO,
    AUTO_CREATOR,
    EXPORT_PRO,
    CANVAS_REFRAME
}

data class StudioUiState(
    val project: KbEditorProject = KbEditorProject(),
    val playheadMs: Long = 0L,
    val isPlaying: Boolean = false,
    val selectedVideoIndex: Int = 0,
    val selectedPipId: String? = null,
    val selectedCaptionId: String? = null,
    val selectedAudioId: String? = null,
    val activeSheet: ActiveStudioSheet = ActiveStudioSheet.NONE,
    val aiDrawerExpanded: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isBusy: Boolean = false,
    val statusBanner: String? = null,
    val exportProgress: Float? = null,
    val lastExportPath: String? = null
)

@UnstableApi
class KbEditorViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = ProjectStorage(application)
    private val visionEngine = SmartVisionEngine(application)
    private val audioExtractor = AudioExtractorEngine(application)
    private val beatDetector = AudioBeatDetector(application)
    private val ttsEngine = VoiceoverTtsEngine(application)
    private val exportEngine = VideoExportEngine(application)
    private val geminiEngine = GeminiStudioEngine(application)

    private val _uiState = MutableStateFlow(
        StudioUiState(project = storage.loadProject())
    )
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private var playbackJob: Job? = null

    private fun updateProject(recordUndo: Boolean = true, transform: (KbEditorProject) -> KbEditorProject) {
        _uiState.update { state ->
            if (recordUndo) {
                storage.pushUndoSnapshot(state.project)
            }
            val next = transform(state.project)
            storage.saveProject(next)
            state.copy(
                project = next,
                canUndo = storage.canUndo(),
                canRedo = storage.canRedo()
            )
        }
    }

    fun undo() {
        val prev = storage.undo(_uiState.value.project) ?: return
        _uiState.update {
            it.copy(
                project = prev,
                canUndo = storage.canUndo(),
                canRedo = storage.canRedo(),
                statusBanner = "Undid last edit"
            )
        }
    }

    fun redo() {
        val next = storage.redo(_uiState.value.project) ?: return
        _uiState.update {
            it.copy(
                project = next,
                canUndo = storage.canUndo(),
                canRedo = storage.canRedo(),
                statusBanner = "Redid edit"
            )
        }
    }

    fun resetProject() {
        storage.clearHistory()
        val fresh = KbEditorProject()
        storage.saveProject(fresh)
        _uiState.update {
            StudioUiState(
                project = fresh,
                statusBanner = "Reset studio sequence"
            )
        }
    }

    fun togglePlayPause() {
        val currentlyPlaying = _uiState.value.isPlaying
        if (currentlyPlaying) {
            playbackJob?.cancel()
            _uiState.update { it.copy(isPlaying = false) }
        } else {
            _uiState.update { it.copy(isPlaying = true) }
            playbackJob = viewModelScope.launch {
                while (true) {
                    delay(33L)
                    _uiState.update { s ->
                        val total = s.project.totalDurationMs.coerceAtLeast(1000L)
                        val nextMs = s.playheadMs + 33L
                        s.copy(playheadMs = if (nextMs >= total) 0L else nextMs)
                    }
                }
            }
        }
    }

    fun seekTo(ms: Long) {
        _uiState.update {
            it.copy(playheadMs = ms.coerceIn(0L, it.project.totalDurationMs))
        }
    }

    fun stepFrames(frameDelta: Int) {
        val frameMs = (1000L / _uiState.value.project.exportSettings.fps.value.coerceAtLeast(24))
        seekTo(_uiState.value.playheadMs + frameDelta * frameMs)
    }

    fun stepSeconds(secDelta: Int) {
        seekTo(_uiState.value.playheadMs + secDelta * 1000L)
    }

    fun selectVideoClip(index: Int) {
        _uiState.update { it.copy(selectedVideoIndex = index.coerceIn(0, (it.project.videoClips.size - 1).coerceAtLeast(0))) }
    }

    fun openSheet(sheet: ActiveStudioSheet) {
        _uiState.update { it.copy(activeSheet = sheet) }
    }

    fun toggleAiDrawer(expanded: Boolean? = null) {
        _uiState.update { it.copy(aiDrawerExpanded = expanded ?: !it.aiDrawerExpanded) }
    }

    fun toggleSafeZone() {
        updateProject(recordUndo = false) { it.copy(safeZoneVisible = !it.safeZoneVisible) }
    }

    fun cycleAspectRatio() {
        val all = AspectRatioPreset.entries
        val current = _uiState.value.project.aspectRatio
        val next = all[(all.indexOf(current) + 1) % all.size]
        updateProject { it.copy(aspectRatio = next) }
    }

    fun updateCanvasSettings(
        ratio: AspectRatioPreset = _uiState.value.project.aspectRatio,
        fillMode: CanvasFillMode = _uiState.value.project.canvasFillMode,
        blurRadius: Float = _uiState.value.project.canvasBlurRadius
    ) {
        updateProject {
            it.copy(
                aspectRatio = ratio,
                canvasFillMode = fillMode,
                canvasBlurRadius = blurRadius
            )
        }
    }

    fun updateTrackState(transform: (TrackState) -> TrackState) {
        updateProject(recordUndo = false) { it.copy(tracks = transform(it.tracks)) }
    }

    fun importVideoClip(uri: Uri, title: String = "Imported Clip") {
        val app = getApplication<Application>()
        runCatching {
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        val resolvedTitle = runCatching {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.substringBeforeLast('.') else null
            }
        }.getOrNull()?.takeIf { it.isNotBlank() } ?: title

        val realDurationMs = runCatching {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(app, uri)
            val dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            retriever.release()
            dur
        }.getOrNull()?.coerceAtLeast(1000L) ?: 8000L

        var newIndex = 0
        updateProject { proj ->
            val clip = VideoClip(
                title = resolvedTitle,
                mediaUri = uri.toString(),
                sourceDurationMs = realDurationMs,
                trimStartMs = 0L,
                trimEndMs = realDurationMs
            )
            val baseList = if (proj.videoClips.all { it.mediaUri.isBlank() }) emptyList() else proj.videoClips
            newIndex = baseList.size
            proj.copy(videoClips = baseList + clip)
        }
        _uiState.update {
            it.copy(
                selectedVideoIndex = newIndex,
                playheadMs = 0L,
                statusBanner = "Loaded '$resolvedTitle' (${realDurationMs / 1000}s) on V1"
            )
        }
    }

    fun importPipOverlay(uri: Uri?, opticalPreset: String? = null, blendMode: BlendModePreset = BlendModePreset.SCREEN) {
        if (uri != null) {
            runCatching {
                getApplication<Application>().contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
        updateProject { proj ->
            val pip = OverlayPipClip(
                title = opticalPreset ?: "PiP Media",
                mediaUri = uri?.toString() ?: "",
                opticalFxPreset = opticalPreset,
                startMs = _uiState.value.playheadMs,
                blendMode = blendMode
            )
            proj.copy(pipClips = proj.pipClips + pip)
        }
        _uiState.update { it.copy(statusBanner = "Added PiP overlay to O1") }
    }

    fun updateSelectedClip(transform: (VideoClip) -> VideoClip) {
        val idx = _uiState.value.selectedVideoIndex
        updateProject { proj ->
            if (idx !in proj.videoClips.indices) return@updateProject proj
            val updated = proj.videoClips.toMutableList()
            updated[idx] = transform(updated[idx])
            proj.copy(videoClips = updated)
        }
    }

    fun splitSelectedClipAtPlayhead() {
        val proj = _uiState.value.project
        if (proj.tracks.v1Locked) {
            _uiState.update { it.copy(statusBanner = "V1 track is locked") }
            return
        }
        val idx = _uiState.value.selectedVideoIndex
        if (idx !in proj.videoClips.indices) return
        val clip = proj.videoClips[idx]
        if (clip.activeDurationMs < 800L) return
        val half = (clip.trimStartMs + clip.trimEndMs) / 2L
        val first = clip.copy(title = "${clip.title} A", trimEndMs = half)
        val second = clip.copy(id = java.util.UUID.randomUUID().toString(), title = "${clip.title} B", trimStartMs = half)
        updateProject {
            val list = it.videoClips.toMutableList()
            list[idx] = first
            list.add(idx + 1, second)
            it.copy(videoClips = list)
        }
    }

    fun rippleDeleteSelectedClip() {
        val proj = _uiState.value.project
        if (proj.tracks.v1Locked || proj.videoClips.size <= 1) return
        val idx = _uiState.value.selectedVideoIndex
        updateProject { p ->
            p.copy(videoClips = p.videoClips.filterIndexed { i, _ -> i != idx })
        }
        _uiState.update { it.copy(selectedVideoIndex = 0, statusBanner = "Magnetic ripple deleted clip") }
    }

    fun moveSelectedClip(delta: Int) {
        val idx = _uiState.value.selectedVideoIndex
        val clips = _uiState.value.project.videoClips
        val target = idx + delta
        if (idx !in clips.indices || target !in clips.indices) return
        updateProject { p ->
            val mutable = p.videoClips.toMutableList()
            val item = mutable.removeAt(idx)
            mutable.add(target, item)
            p.copy(videoClips = mutable)
        }
        _uiState.update { it.copy(selectedVideoIndex = target) }
    }

    fun addOrUpdateCaption(text: String, anim: MotionAnimation3D, trackedToClipId: String? = null) {
        updateProject { proj ->
            val cap = CaptionClip(
                text = text.ifBlank { "KB STUDIO" },
                startMs = _uiState.value.playheadMs,
                durationMs = 3000L,
                animation3D = anim,
                trackedToClipId = trackedToClipId
            )
            proj.copy(captionClips = proj.captionClips + cap)
        }
    }

    fun extractAudioFromSelectedClip() {
        val clip = _uiState.value.project.videoClips.getOrNull(_uiState.value.selectedVideoIndex) ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Extracting audio stream...") }
            val res = audioExtractor.extractAudioToM4a(clip.mediaUri, clip.title)
            res.onSuccess { (uriStr, durMs) ->
                updateProject { proj ->
                    proj.copy(
                        audioClips = proj.audioClips + AudioClip(
                            title = "${clip.title} Audio",
                            mediaUri = uriStr,
                            durationMs = durMs
                        )
                    )
                }
                _uiState.update { it.copy(isBusy = false, statusBanner = "Extracted audio to Track A1") }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "No embedded audio stream") }
            }
        }
    }

    fun updateAudioDsp(windFilter: Boolean, noiseGate: Boolean, vocalMode: VocalIsolationMode) {
        updateProject { proj ->
            val list = if (proj.audioClips.isEmpty()) {
                listOf(
                    AudioClip(
                        title = "Master Audio Bus",
                        windFilterEnabled = windFilter,
                        noiseGateEnabled = noiseGate,
                        vocalMode = vocalMode
                    )
                )
            } else {
                proj.audioClips.map {
                    it.copy(
                        windFilterEnabled = windFilter,
                        noiseGateEnabled = noiseGate,
                        vocalMode = vocalMode
                    )
                }
            }
            proj.copy(audioClips = list)
        }
    }

    fun detectBeatsOnAudio() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Analyzing audio beats...") }
            val audioUri = _uiState.value.project.audioClips.firstOrNull()?.mediaUri ?: ""
            val beats = beatDetector.detectBeatTimestampsMs(audioUri, _uiState.value.project.totalDurationMs)
            updateProject { proj ->
                val clips = if (proj.audioClips.isEmpty()) {
                    listOf(AudioClip(title = "Beat Track", beatMarkersMs = beats))
                } else {
                    proj.audioClips.mapIndexed { idx, c -> if (idx == 0) c.copy(beatMarkersMs = beats) else c }
                }
                proj.copy(audioClips = clips)
            }
            _uiState.update { it.copy(isBusy = false, statusBanner = "Synced ${beats.size} beat markers on A1") }
        }
    }

    fun generateVoiceover(script: String, languageTag: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Synthesizing AI voiceover...") }
            val res = ttsEngine.synthesizeVoiceover(script, languageTag)
            res.onSuccess { (uriStr, durMs) ->
                updateProject { proj ->
                    proj.copy(
                        audioClips = proj.audioClips + AudioClip(
                            title = "VO ($languageTag)",
                            mediaUri = uriStr,
                            startMs = _uiState.value.playheadMs,
                            durationMs = durMs,
                            isVoiceover = true
                        )
                    )
                }
                _uiState.update { it.copy(isBusy = false, statusBanner = "Added AI Voiceover to A1") }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "TTS error") }
            }
        }
    }

    fun runMotionTracking(targetNormX: Float, targetNormY: Float) {
        val clip = _uiState.value.project.videoClips.getOrNull(_uiState.value.selectedVideoIndex) ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Tracking 2D motion across frames...") }
            val points = visionEngine.trackMotionAcrossClip(
                mediaUri = clip.mediaUri,
                startMs = clip.trimStartMs,
                endMs = clip.trimEndMs,
                targetNormX = targetNormX,
                targetNormY = targetNormY
            )
            updateSelectedClip { it.copy(motionTrackPoints = points) }
            _uiState.update { it.copy(isBusy = false, statusBanner = "Locked ${points.size} motion keyframes") }
        }
    }

    fun runSmartAutoReframe() {
        val clip = _uiState.value.project.videoClips.getOrNull(_uiState.value.selectedVideoIndex) ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Computing Smart Auto-Reframe...") }
            val offset = visionEngine.computeSmartReframeOffset(clip.mediaUri, clip.trimStartMs + 500L)
            updateSelectedClip { it.copy(reframeOffsetX = offset) }
            _uiState.update { it.copy(isBusy = false, statusBanner = "Smart Auto-Reframe applied (${(offset * 100).toInt()}%)") }
        }
    }

    fun runAiAutoCreator(prompt: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Gemini 3.8 Flash analyzing sequence...") }
            val summary = geminiEngine.runAutoCreator(prompt, _uiState.value.project)
            updateProject { summary.updatedProject }
            _uiState.update { it.copy(isBusy = false, statusBanner = summary.message) }
        }
    }

    fun runAiColorGrade(stylePrompt: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Grading with Gemini LUT...") }
            val summary = geminiEngine.runAiColorGrade(stylePrompt, _uiState.value.project, _uiState.value.selectedVideoIndex)
            updateProject { summary.updatedProject }
            _uiState.update { it.copy(isBusy = false, statusBanner = summary.message) }
        }
    }

    fun runAiCopilot(command: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "AI Copilot executing...") }
            val summary = geminiEngine.runAiCopilotCommand(command, _uiState.value.project, _uiState.value.selectedVideoIndex)
            updateProject { summary.updatedProject }
            _uiState.update { it.copy(isBusy = false, statusBanner = summary.message) }
        }
    }

    fun generateAiBroll(prompt: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Generating AI B-Roll...") }
            val res = geminiEngine.generateAiBrollImage(prompt)
            res.onSuccess { combined ->
                val uriStr = combined.substringBefore("|")
                updateProject { proj ->
                    proj.copy(
                        videoClips = proj.videoClips + VideoClip(
                            title = "AI: ${prompt.take(14)}",
                            mediaUri = uriStr,
                            isAiGeneratedBroll = true,
                            sourceDurationMs = 4000L,
                            trimEndMs = 4000L
                        )
                    )
                }
                _uiState.update { it.copy(isBusy = false, statusBanner = "Inserted AI B-Roll onto V1") }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "B-Roll failed") }
            }
        }
    }

    fun updateExportSettings(settings: ExportSettings) {
        updateProject(recordUndo = false) { it.copy(exportSettings = settings) }
    }

    fun startExport() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, exportProgress = 0.05f, statusBanner = "Exporting zero-watermark master...") }
            val res = exportEngine.exportProject(_uiState.value.project) { progress ->
                _uiState.update { it.copy(exportProgress = progress) }
            }
            res.onSuccess { path ->
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        exportProgress = null,
                        lastExportPath = path,
                        statusBanner = "Saved to $path"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        exportProgress = null,
                        statusBanner = err.message ?: "Export failed"
                    )
                }
            }
        }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }
}
