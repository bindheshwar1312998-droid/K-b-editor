package com.aistudio.kbeditor.r7v4qx.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aistudio.kbeditor.r7v4qx.model.*
import com.aistudio.kbeditor.r7v4qx.ui.theme.ElectricCyan
import com.aistudio.kbeditor.r7v4qx.ui.theme.TextMuted
import com.aistudio.kbeditor.r7v4qx.ui.theme.TextPrimary

@Composable
fun SpeedRampSheet(
    clip: VideoClip,
    onUpdateClip: (VideoClip) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Optical Flow Speed Ramping", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        SpeedRampGraph(clip.speedRamp)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SpeedRampPreset.entries.forEach { preset ->
                FilterChip(
                    selected = clip.speedRamp == preset,
                    onClick = { onUpdateClip(clip.copy(speedRamp = preset)) },
                    label = { Text(preset.label, maxLines = 1) }
                )
            }
        }

        SliderRow("Base Speed", clip.speedMultiplier, 0.25f..4.0f) {
            onUpdateClip(clip.copy(speedMultiplier = it))
        }

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Optical Flow Frame Interpolation", color = TextPrimary, modifier = Modifier.weight(1f))
            Switch(
                checked = clip.opticalFlowEnabled,
                onCheckedChange = { onUpdateClip(clip.copy(opticalFlowEnabled = it)) }
            )
        }
    }
}

@Composable
fun VfxChromaMaskSheet(
    clip: VideoClip,
    onUpdateClip: (VideoClip) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Chroma Key, AI Auto-Cut & Masking", style = MaterialTheme.typography.titleMedium, color = TextPrimary)

        Text("Mask Shape", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            MaskType.entries.forEach { mask ->
                FilterChip(
                    selected = clip.maskType == mask,
                    onClick = { onUpdateClip(clip.copy(maskType = mask)) },
                    label = { Text(mask.label) }
                )
            }
        }
        SliderRow("Mask Feather", clip.maskFeather, 0f..0.4f) {
            onUpdateClip(clip.copy(maskFeather = it))
        }

        HorizontalDivider()

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Chroma Key Extraction", color = TextPrimary, modifier = Modifier.weight(1f))
            Switch(
                checked = clip.chromaKey.enabled,
                onCheckedChange = { onUpdateClip(clip.copy(chromaKey = clip.chromaKey.copy(enabled = it))) }
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Green", "Blue", "Cyan").forEach { hue ->
                FilterChip(
                    selected = clip.chromaKey.keyHue == hue,
                    onClick = { onUpdateClip(clip.copy(chromaKey = clip.chromaKey.copy(keyHue = hue))) },
                    label = { Text(hue) }
                )
            }
        }

        SliderRow("Key Tolerance", clip.chromaKey.tolerance, 0.05f..0.75f) {
            onUpdateClip(clip.copy(chromaKey = clip.chromaKey.copy(tolerance = it)))
        }
        SliderRow("Spill Suppress", clip.chromaKey.spillSuppression, 0f..1f) {
            onUpdateClip(clip.copy(chromaKey = clip.chromaKey.copy(spillSuppression = it)))
        }

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("AI Auto-Cut Foreground Matting", color = ElectricCyan, modifier = Modifier.weight(1f))
            Switch(
                checked = clip.chromaKey.aiAutoCut,
                onCheckedChange = { onUpdateClip(clip.copy(chromaKey = clip.chromaKey.copy(aiAutoCut = it))) }
            )
        }
    }
}
