package com.aistudio.kbeditor.r7v4qx.media

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.aistudio.kbeditor.r7v4qx.audio.StudioAudioDspProcessor
import com.aistudio.kbeditor.r7v4qx.model.ColorGradeSpec
import com.aistudio.kbeditor.r7v4qx.model.ExportDynamicRange
import com.aistudio.kbeditor.r7v4qx.model.KbEditorProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

@UnstableApi
class VideoExportEngine(private val context: Context) {

    suspend fun exportProject(
        project: KbEditorProject,
        onProgress: (Float) -> Unit
    ): Result<String> = withContext(Dispatchers.Main) {
        val validClips = project.videoClips.filter { it.mediaUri.isNotBlank() }
        if (validClips.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("Import at least one video clip before exporting."))
        }

        val outFile = File(context.cacheDir, "kb_export_${System.currentTimeMillis()}.mp4")
        val targetWidth = computeTargetWidth(project)
        val targetHeight = computeTargetHeight(project)

        val editedVideoItems = validClips.map { clip ->
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.trimStartMs)
                .setEndPositionMs(clip.trimEndMs.coerceAtLeast(clip.trimStartMs + 300L))
                .build()
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(clip.mediaUri))
                .setClippingConfiguration(clipping)
                .build()

            val videoEffects = mutableListOf<Effect>()
            videoEffects.add(Presentation.createForWidthAndHeight(targetWidth, targetHeight, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            videoEffects.add(buildRgbAdjustment(clip.colorGrade))

            val overlayBitmap = renderCaptionOverlayBitmap(project, targetWidth, targetHeight)
            if (overlayBitmap != null) {
                val bitmapOverlay = BitmapOverlay.createStaticBitmapOverlay(overlayBitmap)
                videoEffects.add(OverlayEffect(listOf(bitmapOverlay)))
            }

            val audioDsp = StudioAudioDspProcessor(
                windFilterEnabled = project.audioClips.any { it.windFilterEnabled },
                noiseGateEnabled = project.audioClips.any { it.noiseGateEnabled },
                vocalMode = project.audioClips.firstOrNull()?.vocalMode
                    ?: com.aistudio.kbeditor.r7v4qx.model.VocalIsolationMode.FULL_MIX
            )

            EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(listOf(audioDsp), videoEffects))
                .setRemoveAudio(clip.muted || project.tracks.a1Muted)
                .build()
        }

        val sequence = EditedMediaItemSequence.Builder(editedVideoItems).build()
        val hdrMode = if (project.exportSettings.dynamicRange == ExportDynamicRange.HDR10_HLG) {
            Composition.HDR_MODE_KEEP_HDR
        } else {
            Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL
        }

        val composition = Composition.Builder(listOf(sequence))
            .setHdrMode(hdrMode)
            .build()

        val videoMime = if (project.exportSettings.dynamicRange == ExportDynamicRange.HDR10_HLG) {
            MimeTypes.VIDEO_H265
        } else {
            MimeTypes.VIDEO_H264
        }

        val result = runTransformer(composition, outFile, videoMime, onProgress)
        if (result.isFailure && videoMime == MimeTypes.VIDEO_H265) {
            // H.264 SDR fallback if device HEVC 10-bit encoder is unavailable
            val fallbackComp = Composition.Builder(listOf(sequence))
                .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
                .build()
            val fallbackResult = runTransformer(fallbackComp, outFile, MimeTypes.VIDEO_H264, onProgress)
            if (fallbackResult.isFailure) return@withContext fallbackResult
        } else if (result.isFailure) {
            return@withContext result
        }

        val savedPath = withContext(Dispatchers.IO) {
            saveToMoviesKbEditor(outFile)
        }
        Result.success(savedPath)
    }

    private suspend fun runTransformer(
        composition: Composition,
        outFile: File,
        videoMime: String,
        onProgress: (Float) -> Unit
    ): Result<String> = suspendCancellableCoroutine { cont ->
        val transformer = Transformer.Builder(context)
            .setVideoMimeType(videoMime)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onProgress(1f)
                    if (cont.isActive) cont.resume(Result.success(outFile.absolutePath))
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    if (cont.isActive) cont.resume(Result.failure(exportException))
                }
            })
            .build()

        transformer.start(composition, outFile.absolutePath)
        cont.invokeOnCancellation {
            transformer.cancel()
        }
    }

    private fun buildRgbAdjustment(grade: ColorGradeSpec): RgbAdjustment {
        val rScale = (grade.contrast * (1f + grade.gain.dx * 0.25f + grade.warmth * 0.15f)).coerceIn(0.4f, 2.2f)
        val gScale = (grade.contrast * (1f + grade.gamma.dy * 0.2f)).coerceIn(0.4f, 2.2f)
        val bScale = (grade.contrast * (1f - grade.gain.dx * 0.25f - grade.warmth * 0.15f)).coerceIn(0.4f, 2.2f)
        return RgbAdjustment.Builder()
            .setRedScale(rScale)
            .setGreenScale(gScale)
            .setBlueScale(bScale)
            .build()
    }

    private fun renderCaptionOverlayBitmap(
        project: KbEditorProject,
        width: Int,
        height: Int
    ): Bitmap? {
        if (!project.tracks.t1Visible || project.captionClips.isEmpty()) return null
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(8f, 0f, 3f, Color.argb(190, 0, 0, 0))
        }
        project.captionClips.take(2).forEach { cap ->
            paint.color = cap.colorHex.toInt()
            paint.textSize = (cap.fontSizeSp * (width / 360f)).coerceIn(28f, 140f)
            canvas.drawText(cap.text, width * cap.posX, height * cap.posY, paint)
        }
        return bitmap
    }

    private fun computeTargetWidth(project: KbEditorProject): Int {
        val base = project.exportSettings.resolution.heightPx
        val ar = project.aspectRatio.widthRatio / project.aspectRatio.heightRatio
        val raw = if (ar >= 1f) (base * ar).toInt() else base
        return raw - (raw % 2)
    }

    private fun computeTargetHeight(project: KbEditorProject): Int {
        val base = project.exportSettings.resolution.heightPx
        val ar = project.aspectRatio.widthRatio / project.aspectRatio.heightRatio
        val raw = if (ar >= 1f) base else (base / ar).toInt()
        return raw - (raw % 2)
    }

    private fun saveToMoviesKbEditor(sourceFile: File): String {
        val displayName = "KB_Editor_${System.currentTimeMillis()}.mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/KB Editor")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    sourceFile.inputStream().use { it.copyTo(out) }
                }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                return "Movies/KB Editor/$displayName"
            }
        }
        val moviesDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
            "KB Editor"
        ).apply { mkdirs() }
        val dest = File(moviesDir, displayName)
        sourceFile.copyTo(dest, overwrite = true)
        return dest.absolutePath
    }
}
