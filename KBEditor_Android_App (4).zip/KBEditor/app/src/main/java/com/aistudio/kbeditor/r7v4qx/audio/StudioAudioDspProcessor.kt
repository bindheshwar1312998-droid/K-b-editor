package com.aistudio.kbeditor.r7v4qx.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import com.aistudio.kbeditor.r7v4qx.model.VocalIsolationMode
import java.nio.ByteBuffer
import kotlin.math.abs

@UnstableApi
class StudioAudioDspProcessor(
    @Volatile var windFilterEnabled: Boolean = false,
    @Volatile var noiseGateEnabled: Boolean = false,
    @Volatile var vocalMode: VocalIsolationMode = VocalIsolationMode.FULL_MIX
) : BaseAudioProcessor() {

    private var prevInL = 0f
    private var prevOutL = 0f
    private var prevInR = 0f
    private var prevOutR = 0f
    private val highPassAlpha = 0.965f
    private val gateThreshold = 0.018f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val outBuffer = replaceOutputBuffer(remaining)
        val channels = inputAudioFormat.channelCount.coerceAtLeast(1)

        if (channels >= 2) {
            while (inputBuffer.remaining() >= 4) {
                var l = inputBuffer.short / 32768f
                var r = inputBuffer.short / 32768f

                if (windFilterEnabled) {
                    val hpL = highPassAlpha * (prevOutL + l - prevInL)
                    prevInL = l
                    prevOutL = hpL
                    l = hpL

                    val hpR = highPassAlpha * (prevOutR + r - prevInR)
                    prevInR = r
                    prevOutR = hpR
                    r = hpR
                }

                if (noiseGateEnabled) {
                    if (abs(l) < gateThreshold) l *= 0.12f
                    if (abs(r) < gateThreshold) r *= 0.12f
                }

                // Mid/Side Vocal Isolation
                val mid = (l + r) * 0.5f
                val side = (l - r) * 0.5f
                when (vocalMode) {
                    VocalIsolationMode.FULL_MIX -> Unit
                    VocalIsolationMode.ISOLATE_VOCALS -> {
                        l = (mid * 1.15f).coerceIn(-1f, 1f)
                        r = l
                    }
                    VocalIsolationMode.INSTRUMENTAL_ONLY -> {
                        l = (side * 1.4f).coerceIn(-1f, 1f)
                        r = (-side * 1.4f).coerceIn(-1f, 1f)
                    }
                }

                outBuffer.putShort((l.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                outBuffer.putShort((r.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            }
        } else {
            while (inputBuffer.remaining() >= 2) {
                var s = inputBuffer.short / 32768f
                if (windFilterEnabled) {
                    val hp = highPassAlpha * (prevOutL + s - prevInL)
                    prevInL = s
                    prevOutL = hp
                    s = hp
                }
                if (noiseGateEnabled && abs(s) < gateThreshold) {
                    s *= 0.12f
                }
                outBuffer.putShort((s.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            }
        }

        outBuffer.flip()
    }
}
