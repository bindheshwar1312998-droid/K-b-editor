package com.aistudio.kbeditor.r7v4qx.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.aistudio.kbeditor.r7v4qx.model.CaptionClip
import com.aistudio.kbeditor.r7v4qx.model.ColorGradeSpec
import com.aistudio.kbeditor.r7v4qx.model.ColorWheelPoint
import com.aistudio.kbeditor.r7v4qx.model.KbEditorProject
import com.aistudio.kbeditor.r7v4qx.model.MotionAnimation3D
import com.aistudio.kbeditor.r7v4qx.model.SpeedRampPreset
import com.aistudio.kbeditor.r7v4qx.model.TransitionType
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class AiEditSummary(
    val updatedProject: KbEditorProject,
    val message: String
)

class GeminiStudioEngine(private val context: Context) {

    private val flashModel by lazy {
        Firebase.ai(backend = GenerativeBackend.googleAI())
            .generativeModel("gemini-3.8-flash")
    }

    suspend fun runAutoCreator(
        prompt: String,
        project: KbEditorProject
    ): AiEditSummary = withContext(Dispatchers.IO) {
        val sampleFrame = extractFirstFrame(project)
        val aiPlanJson = runCatching {
            val response = flashModel.generateContent(
                content {
                    if (sampleFrame != null) image(sampleFrame)
                    text(
                        """
                        You are KB Editor's AI Auto-Creator. Given the user's editing prompt: "$prompt"
                        Return ONLY a compact JSON object with keys:
                        "lutName" (string), "contrast" (float 0.8..1.5), "saturation" (float 0.6..1.6),
                        "warmth" (float -0.5..0.5), "speedRamp" (CONSTANT|HERO_DIP|FLASH_IN|BULLET_TIME|BUILD_UP),
                        "transition" (NONE|CROSS_DISSOLVE|WHIP_PAN|FLASH_CUT|ZOOM_THROUGH),
                        "captionText" (short 3-6 words), "enableNoiseGate" (boolean)
                        """.trimIndent()
                    )
                }
            )
            response.text
        }.getOrNull()

        sampleFrame?.recycle()

        val lower = prompt.lowercase()
        val parsed = parseJsonSafe(aiPlanJson)

        val speedRamp = parsed?.optString("speedRamp")?.let { runCatching { SpeedRampPreset.valueOf(it) }.getOrNull() }
            ?: when {
                "hype" in lower || "action" in lower || "reel" in lower -> SpeedRampPreset.HERO_DIP
                "slow" in lower || "cinematic" in lower -> SpeedRampPreset.BULLET_TIME
                else -> SpeedRampPreset.FLASH_IN
            }

        val transition = parsed?.optString("transition")?.let { runCatching { TransitionType.valueOf(it) }.getOrNull() }
            ?: if ("action" in lower || "fast" in lower) TransitionType.WHIP_PAN else TransitionType.CROSS_DISSOLVE

        val lutName = parsed?.optString("lutName")?.takeIf { it.isNotBlank() }
            ?: when {
                "teal" in lower || "cinematic" in lower -> "Teal & Orange Pro"
                "warm" in lower || "vlog" in lower -> "Golden Film"
                "cyber" in lower || "neon" in lower -> "Cyber Neon"
                else -> "Studio Crisp"
            }

        val updatedClips = project.videoClips.mapIndexed { idx, clip ->
            clip.copy(
                speedRamp = speedRamp,
                transitionOut = if (idx < project.videoClips.lastIndex) transition else TransitionType.NONE,
                colorGrade = clip.colorGrade.copy(
                    lutName = lutName,
                    contrast = parsed?.optDouble("contrast", 1.15)?.toFloat() ?: 1.15f,
                    saturation = parsed?.optDouble("saturation", 1.12)?.toFloat() ?: 1.12f,
                    warmth = parsed?.optDouble("warmth", 0.08)?.toFloat() ?: 0.08f
                )
            )
        }

        val captionText = parsed?.optString("captionText")?.takeIf { it.isNotBlank() }
            ?: prompt.trim().take(28).uppercase().ifBlank { "AI STUDIO EDIT" }

        val updatedCaptions = listOf(
            CaptionClip(
                text = captionText,
                startMs = 200L,
                durationMs = 3000L,
                animation3D = MotionAnimation3D.POP_3D
            )
        )

        val updatedAudio = project.audioClips.map {
            it.copy(
                noiseGateEnabled = parsed?.optBoolean("enableNoiseGate", true) ?: true,
                windFilterEnabled = true
            )
        }

        val nextProject = project.copy(
            videoClips = updatedClips,
            captionClips = updatedCaptions,
            audioClips = updatedAudio
        )
        AiEditSummary(
            updatedProject = nextProject,
            message = "AI Auto-Creator applied '$lutName', ${speedRamp.label} speed ramp, ${transition.label} transitions & 3D caption."
        )
    }

    suspend fun runAiColorGrade(
        stylePrompt: String,
        project: KbEditorProject,
        selectedClipIndex: Int
    ): AiEditSummary = withContext(Dispatchers.IO) {
        val sampleFrame = extractFirstFrame(project)
        val raw = runCatching {
            flashModel.generateContent(
                content {
                    if (sampleFrame != null) image(sampleFrame)
                    text("Suggest JSON ColorGradeSpec for '$stylePrompt': lutName, liftDx, gammaDx, gainDx, contrast, saturation, warmth.")
                }
            ).text
        }.getOrNull()
        sampleFrame?.recycle()

        val parsed = parseJsonSafe(raw)
        val lower = stylePrompt.lowercase()
        val grade = when {
            "teal" in lower || "orange" in lower -> ColorGradeSpec(
                lift = ColorWheelPoint(dx = -0.22f, dy = 0.06f, luma = -0.05f),
                gamma = ColorWheelPoint(dx = 0.08f, dy = 0.02f),
                gain = ColorWheelPoint(dx = 0.25f, dy = 0.10f, luma = 0.06f),
                contrast = 1.18f,
                saturation = 1.14f,
                warmth = 0.12f,
                vignette = 0.22f,
                lutName = "Teal & Orange"
            )
            "noir" in lower || "bw" in lower || "mono" in lower -> ColorGradeSpec(
                contrast = 1.32f,
                saturation = 0.05f,
                vignette = 0.35f,
                lutName = "Cinema Noir"
            )
            else -> ColorGradeSpec(
                lift = ColorWheelPoint(dx = parsed?.optDouble("liftDx", -0.08)?.toFloat() ?: -0.08f, dy = 0f),
                gamma = ColorWheelPoint(dx = parsed?.optDouble("gammaDx", 0.06)?.toFloat() ?: 0.06f, dy = 0.02f),
                gain = ColorWheelPoint(dx = parsed?.optDouble("gainDx", 0.12)?.toFloat() ?: 0.12f, dy = 0.05f),
                contrast = parsed?.optDouble("contrast", 1.16)?.toFloat() ?: 1.16f,
                saturation = parsed?.optDouble("saturation", 1.15)?.toFloat() ?: 1.15f,
                warmth = parsed?.optDouble("warmth", 0.1)?.toFloat() ?: 0.1f,
                lutName = parsed?.optString("lutName")?.takeIf { it.isNotBlank() } ?: "AI Studio LUT"
            )
        }

        val clips = project.videoClips.mapIndexed { idx, clip ->
            if (idx == selectedClipIndex) clip.copy(colorGrade = grade) else clip
        }
        AiEditSummary(
            updatedProject = project.copy(videoClips = clips),
            message = "Applied AI Color Grade: ${grade.lutName}"
        )
    }

    suspend fun generateAiBrollImage(prompt: String): Result<String> = withContext(Dispatchers.IO) {
        val outFile = File(context.cacheDir, "ai_broll_${System.currentTimeMillis()}.png")
        // Attempt Gemini image generation ("gemini-nano-banana-2.1"), with local procedural studio render fallback
        val generated = runCatching {
            val model = Firebase.ai(backend = GenerativeBackend.googleAI())
                .generativeModel("gemini-nano-banana-2.1")
            model.generateContent(prompt)
        }.getOrNull()

        val bmp = Bitmap.createBitmap(1080, 1920, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(
            0f, 0f, 1080f, 1920f,
            intArrayOf(Color.parseColor("#090D16"), Color.parseColor("#0F172A"), Color.parseColor("#164E63")),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, 1080f, 1920f, paint)
        paint.shader = null
        paint.color = Color.parseColor("#22D3EE")
        paint.alpha = 55
        canvas.drawCircle(540f, 780f, 340f, paint)
        paint.color = Color.parseColor("#F8FAFC")
        paint.alpha = 230
        paint.textSize = 46f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("AI B-ROLL: ${prompt.take(22).uppercase()}", 540f, 960f, paint)

        FileOutputStream(outFile).use { fos ->
            bmp.compress(Bitmap.CompressFormat.PNG, 95, fos)
        }
        bmp.recycle()
        val note = if (generated != null) "Generated" else "Rendered Studio B-Roll"
        Result.success("${Uri.fromFile(outFile)}|$note")
    }

    suspend fun runAiCopilotCommand(
        command: String,
        project: KbEditorProject,
        selectedClipIndex: Int
    ): AiEditSummary {
        val lower = command.lowercase()
        return when {
            "color" in lower || "lut" in lower || "grade" in lower || "teal" in lower || "noir" in lower ->
                runAiColorGrade(command, project, selectedClipIndex)
            else -> runAutoCreator(command, project)
        }
    }

    private fun extractFirstFrame(project: KbEditorProject): Bitmap? {
        val uriStr = project.videoClips.firstOrNull { it.mediaUri.isNotBlank() }?.mediaUri ?: return null
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, Uri.parse(uriStr))
            retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun parseJsonSafe(raw: String?): JSONObject? {
        if (raw.isNullOrBlank()) return null
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return runCatching { JSONObject(raw.substring(start, end + 1)) }.getOrNull()
    }
}
