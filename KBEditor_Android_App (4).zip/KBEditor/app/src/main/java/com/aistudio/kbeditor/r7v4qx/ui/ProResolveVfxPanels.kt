package com.aistudio.kbeditor.r7v4qx.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.aistudio.kbeditor.r7v4qx.model.ColorGradeSpec
import com.aistudio.kbeditor.r7v4qx.model.ColorWheelPoint
import com.aistudio.kbeditor.r7v4qx.model.SpeedRampPreset
import com.aistudio.kbeditor.r7v4qx.ui.theme.*
import com.aistudio.kbeditor.r7v4qx.vfx.CurveEvaluators
import kotlin.math.hypot

@Composable
fun ColorWheelsPanel(
    grade: ColorGradeSpec,
    onUpdateGrade: (ColorGradeSpec) -> Unit,
    onAiColorGrade: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("3-Way Primary Color Wheels", style = MaterialTheme.typography.titleMedium, color = TextPrimary)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            SingleColorWheel("Lift (Shadows)", grade.lift) { pt ->
                onUpdateGrade(grade.copy(lift = pt))
            }
            SingleColorWheel("Gamma (Mid)", grade.gamma) { pt ->
                onUpdateGrade(grade.copy(gamma = pt))
            }
            SingleColorWheel("Gain (High)", grade.gain) { pt ->
                onUpdateGrade(grade.copy(gain = pt))
            }
        }

        // Real-time RGB delta readout
        val rDelta = ((grade.lift.dx + grade.gamma.dx + grade.gain.dx) * 33f).toInt()
        val gDelta = ((grade.lift.dy + grade.gamma.dy + grade.gain.dy) * 33f).toInt()
        val bDelta = (-rDelta)
        Text(
            text = "RGB Delta  R:${if (rDelta >= 0) "+$rDelta" else rDelta}  G:${if (gDelta >= 0) "+$gDelta" else gDelta}  B:${if (bDelta >= 0) "+$bDelta" else bDelta}",
            style = MaterialTheme.typography.labelMedium,
            color = ElectricCyan
        )

        SliderRow("Contrast", grade.contrast, 0.5f..1.8f) { onUpdateGrade(grade.copy(contrast = it)) }
        SliderRow("Saturation", grade.saturation, 0f..2f) { onUpdateGrade(grade.copy(saturation = it)) }
        SliderRow("Warmth", grade.warmth, -0.8f..0.8f) { onUpdateGrade(grade.copy(warmth = it)) }
        SliderRow("AI Beauty Smooth", grade.beautySmooth, 0f..1f) { onUpdateGrade(grade.copy(beautySmooth = it)) }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onAiColorGrade("Teal & Orange Cinema") }) {
                Text("AI Teal/Orange")
            }
            OutlinedButton(onClick = { onAiColorGrade("Cinema Noir") }) {
                Text("AI Noir")
            }
            OutlinedButton(onClick = { onUpdateGrade(ColorGradeSpec()) }) {
                Text("Reset")
            }
        }
    }
}

@Composable
private fun SingleColorWheel(
    label: String,
    point: ColorWheelPoint,
    onChange: (ColorWheelPoint) -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(102.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .size(86.dp)
                .clip(CircleShape)
                .border(1.5.dp, SlateBorder, CircleShape)
                .pointerInput(point) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        val r = size.width / 2f
                        val dx = ((change.position.x - r) / r).coerceIn(-1f, 1f)
                        val dy = ((change.position.y - r) / r).coerceIn(-1f, 1f)
                        val dist = hypot(dx, dy)
                        val nx = if (dist > 1f) dx / dist else dx
                        val ny = if (dist > 1f) dy / dist else dy
                        onChange(point.copy(dx = nx, dy = ny))
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(
                            Color.Red,
                            Color.Yellow,
                            Color.Green,
                            Color.Cyan,
                            Color.Blue,
                            Color.Magenta,
                            Color.Red
                        )
                    ),
                    alpha = 0.72f
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.65f), Color.Transparent)
                    )
                )
                val px = size.width / 2f + point.dx * (size.width / 2f - 8f)
                val py = size.height / 2f + point.dy * (size.height / 2f - 8f)
                drawCircle(Color.White, radius = 6f, center = Offset(px, py))
                drawCircle(SlateVoid, radius = 6f, center = Offset(px, py), style = Stroke(2f))
            }
        }
        Slider(
            value = point.luma,
            onValueChange = { onChange(point.copy(luma = it)) },
            valueRange = -0.5f..0.5f,
            modifier = Modifier.height(22.dp)
        )
    }
}

@Composable
fun SpeedRampGraph(preset: SpeedRampPreset) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(90.dp)
            .background(SlateVoid, RoundedCornerShape(10.dp))
            .border(1.dp, SlateBorder, RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        val path = Path()
        val steps = 32
        for (i in 0..steps) {
            val t = i / steps.toFloat()
            val speed = CurveEvaluators.evaluateSpeedMultiplier(preset, t)
            val x = t * size.width
            val y = size.height - ((speed - 0.25f) / 2.75f).coerceIn(0f, 1f) * size.height
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = ElectricCyan, style = Stroke(width = 3.5f))
    }
}

@Composable
fun MotionTrackerPanel(
    pointCount: Int,
    onRunTrack: (Float, Float) -> Unit
) {
    var targetX by remember { mutableFloatStateOf(0.5f) }
    var targetY by remember { mutableFloatStateOf(0.45f) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("2D Optical Motion Tracker", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Text(
            text = "Tap the reticle pad to lock onto a subject face or object ($pointCount keyframes locked).",
            style = MaterialTheme.typography.bodyMedium,
            color = TextMuted
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .background(SlateVoid, RoundedCornerShape(12.dp))
                .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        targetX = (offset.x / size.width).coerceIn(0.1f, 0.9f)
                        targetY = (offset.y / size.height).coerceIn(0.1f, 0.9f)
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width * targetX
                val cy = size.height * targetY
                drawCircle(ElectricCyan, radius = 24f, center = Offset(cx, cy), style = Stroke(2.5f))
                drawLine(ElectricCyan, Offset(cx - 32f, cy), Offset(cx + 32f, cy), strokeWidth = 2f)
                drawLine(ElectricCyan, Offset(cx, cy - 32f), Offset(cx, cy + 32f), strokeWidth = 2f)
            }
        }
        Button(
            onClick = { onRunTrack(targetX, targetY) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Lock & Track Subject Across Frames")
        }
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.width(100.dp))
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier.weight(1f).height(24.dp)
        )
        Text(
            text = "%.2f".format(value),
            style = MaterialTheme.typography.labelSmall,
            color = ElectricCyan,
            modifier = Modifier.width(42.dp)
        )
    }
}
