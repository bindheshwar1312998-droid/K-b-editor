package com.aistudio.kbeditor.r7v4qx.ui

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbAdjustment
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.aistudio.kbeditor.r7v4qx.R
import com.aistudio.kbeditor.r7v4qx.model.*
import com.aistudio.kbeditor.r7v4qx.ui.theme.*
import com.aistudio.kbeditor.r7v4qx.vfx.CurveEvaluators
import kotlin.math.abs
import kotlin.math.sin

@OptIn(UnstableApi::class)
@Composable
fun VerticalPreviewStage(
    project: KbEditorProject,
    playheadMs: Long,
    isPlaying: Boolean,
    selectedClip: VideoClip?,
    isMotionTrackerMode: Boolean = false,
    onTrackerTap: (Float, Float) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val ratio = project.aspectRatio.widthRatio / project.aspectRatio.heightRatio
    val colorMatrix = selectedClip?.let { CurveEvaluators.buildGradeColorMatrix(it.colorGrade) }

    val clipNormT = if (selectedClip != null && selectedClip.activeDurationMs > 0L) {
        ((playheadMs % selectedClip.activeDurationMs).toFloat() / selectedClip.activeDurationMs).coerceIn(0f, 1f)
    } else 0f

    val kf = selectedClip?.let { CurveEvaluators.interpolateKeyframes(it.keyframes, clipNormT) }
    val trackPt = selectedClip?.motionTrackPoints?.takeIf { it.isNotEmpty() }?.let {
        CurveEvaluators.interpolateKeyframes(it, clipNormT)
    }

    val maskShape = when (selectedClip?.maskType) {
        MaskType.CIRCLE -> CircleShape
        MaskType.ROUNDED_RECT -> RoundedCornerShape(28.dp)
        MaskType.SPLIT_WIPE -> GenericShape { size, _ ->
            addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width * 0.55f, size.height))
        }
        else -> RoundedCornerShape(14.dp)
    }

    val mediaUri = selectedClip?.mediaUri.orEmpty()
    val isImageClip = mediaUri.endsWith(".png", ignoreCase = true) ||
        mediaUri.endsWith(".jpg", ignoreCase = true) ||
        mediaUri.endsWith(".jpeg", ignoreCase = true)

    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    LaunchedEffect(mediaUri, isImageClip) {
        if (mediaUri.isNotBlank() && !isImageClip) {
            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(mediaUri)))
            exoPlayer.prepare()
        } else {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
        }
    }

    LaunchedEffect(isPlaying, mediaUri) {
        if (mediaUri.isNotBlank() && !isImageClip) {
            exoPlayer.playWhenReady = isPlaying
        }
    }

    LaunchedEffect(playheadMs, isPlaying) {
        if (mediaUri.isNotBlank() && !isImageClip && !isPlaying) {
            if (abs(exoPlayer.currentPosition - playheadMs) > 120L) {
                exoPlayer.seekTo(playheadMs)
            }
        }
    }

    val effectiveSpeed = remember(selectedClip?.speedMultiplier, selectedClip?.speedRamp, clipNormT) {
        if (selectedClip == null) {
            1f
        } else if (selectedClip.speedRamp != SpeedRampPreset.CONSTANT) {
            CurveEvaluators.evaluateSpeedMultiplier(selectedClip.speedRamp, clipNormT).coerceIn(0.25f, 4.0f)
        } else {
            selectedClip.speedMultiplier.coerceIn(0.25f, 4.0f)
        }
    }

    LaunchedEffect(effectiveSpeed, mediaUri, isImageClip) {
        if (mediaUri.isNotBlank() && !isImageClip) {
            exoPlayer.setPlaybackSpeed(effectiveSpeed)
        }
    }

    LaunchedEffect(selectedClip?.colorGrade, mediaUri, isImageClip) {
        if (mediaUri.isNotBlank() && !isImageClip && selectedClip != null) {
            val grade = selectedClip.colorGrade
            val rScale = (1f + grade.lift.dx * 0.2f + grade.gamma.dx * 0.25f + grade.gain.dx * 0.3f + grade.warmth * 0.25f).coerceIn(0.4f, 2.0f)
            val gScale = (1f + grade.lift.dy * 0.15f + grade.gamma.dy * 0.2f + grade.gain.dy * 0.25f).coerceIn(0.4f, 2.0f)
            val bScale = (1f - grade.lift.dx * 0.2f - grade.gamma.dx * 0.25f - grade.gain.dx * 0.3f - grade.warmth * 0.25f).coerceIn(0.4f, 2.0f)
            val effects = listOf<Effect>(
                Contrast((grade.contrast - 1f).coerceIn(-0.9f, 0.9f)),
                HslAdjustment.Builder()
                    .adjustSaturation(((grade.saturation - 1f) * 100f).coerceIn(-100f, 100f))
                    .adjustLightness(((grade.brightness + grade.lift.luma * 0.25f) * 100f).coerceIn(-100f, 100f))
                    .build(),
                RgbAdjustment.Builder()
                    .setRedScale(rScale)
                    .setGreenScale(gScale)
                    .setBlueScale(bScale)
                    .build()
            )
            exoPlayer.setVideoEffects(effects)
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(SlateVoid, RoundedCornerShape(16.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .aspectRatio(ratio)
                .fillMaxHeight()
                .clip(maskShape)
                .background(
                    when (project.canvasFillMode) {
                        CanvasFillMode.SOLID_COLOR -> Color(project.canvasSolidColorHex)
                        else -> SlateBase
                    }
                )
                .border(1.dp, SlateBorder, maskShape)
                .pointerInput(isMotionTrackerMode) {
                    if (isMotionTrackerMode) {
                        detectTapGestures { offset ->
                            onTrackerTap(
                                (offset.x / size.width.toFloat()).coerceIn(0.05f, 0.95f),
                                (offset.y / size.height.toFloat()).coerceIn(0.05f, 0.95f)
                            )
                        }
                    }
                }
        ) {
            if (project.tracks.v1Visible && selectedClip != null) {
                if (project.canvasFillMode == CanvasFillMode.BLUR_CANVAS && mediaUri.isNotBlank() && isImageClip) {
                    AsyncImage(
                        model = mediaUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .blur(project.canvasBlurRadius.dp)
                            .alpha(0.55f)
                    )
                }

                if (mediaUri.isNotBlank() && !isImageClip) {
                    AndroidView(
                        factory = { ctx ->
                            (LayoutInflater.from(ctx).inflate(R.layout.view_exo_texture_player, null) as PlayerView).apply {
                                player = exoPlayer
                                useController = false
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                translationX = selectedClip.reframeOffsetX * 120f + ((kf?.x ?: 0.5f) - 0.5f) * 140f
                                translationY = ((kf?.y ?: 0.5f) - 0.5f) * 140f
                                scaleX = kf?.scale ?: 1f
                                scaleY = kf?.scale ?: 1f
                                rotationZ = kf?.rotationDeg ?: 0f
                                alpha = kf?.opacity ?: 1f
                            }
                    )
                } else if (mediaUri.isNotBlank()) {
                    AsyncImage(
                        model = mediaUri,
                        contentDescription = selectedClip.title,
                        contentScale = ContentScale.Crop,
                        colorFilter = colorMatrix?.let { ColorFilter.colorMatrix(it) },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                translationX = selectedClip.reframeOffsetX * 120f + ((kf?.x ?: 0.5f) - 0.5f) * 140f
                                translationY = ((kf?.y ?: 0.5f) - 0.5f) * 140f
                                scaleX = kf?.scale ?: 1f
                                scaleY = kf?.scale ?: 1f
                                rotationZ = kf?.rotationDeg ?: 0f
                                alpha = kf?.opacity ?: 1f
                            }
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    listOf(SlateVoid, Color(0xFF162238), SlateBase)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = selectedClip.title.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = ElectricCyan
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Tap + above to import video",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }

                if (selectedClip.maskType == MaskType.ANAMORPHIC_BARS) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.12f)
                            .align(Alignment.TopCenter)
                            .background(Color.Black)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.12f)
                            .align(Alignment.BottomCenter)
                            .background(Color.Black)
                    )
                }
            }

            if (project.tracks.o1Visible) {
                project.pipClips.filter { playheadMs in it.startMs..(it.startMs + it.durationMs) }.forEach { pip ->
                    val composeBlend = when (pip.blendMode) {
                        BlendModePreset.NORMAL -> BlendMode.SrcOver
                        BlendModePreset.SCREEN -> BlendMode.Screen
                        BlendModePreset.MULTIPLY -> BlendMode.Multiply
                        BlendModePreset.ADD -> BlendMode.Plus
                        BlendModePreset.OVERLAY -> BlendMode.Overlay
                    }
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                    ) {
                        val center = Offset(size.width * pip.posX, size.height * pip.posY)
                        val radius = size.minDimension * 0.28f * pip.scale
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(ElectricCyan.copy(alpha = pip.opacity), WarmAmber.copy(alpha = 0.25f), Color.Transparent),
                                center = center,
                                radius = radius
                            ),
                            center = center,
                            radius = radius,
                            blendMode = composeBlend
                        )
                    }
                }
            }

            if (project.tracks.t1Visible) {
                project.captionClips.filter { playheadMs in it.startMs..(it.startMs + it.durationMs) }.forEach { cap ->
                    val capProgress = ((playheadMs - cap.startMs).toFloat() / cap.durationMs.coerceAtLeast(1L)).coerceIn(0f, 1f)
                    val animScale = when (cap.animation3D) {
                        MotionAnimation3D.POP_3D -> if (capProgress < 0.2f) 0.6f + capProgress * 2.2f else 1f
                        MotionAnimation3D.FLOAT_NEON -> 1f + 0.04f * sin(capProgress * 12f)
                        else -> 1f
                    }
                    val rotY = if (cap.animation3D == MotionAnimation3D.FLIP_3D && capProgress < 0.3f) {
                        (1f - capProgress / 0.3f) * 75f
                    } else 0f

                    val anchorX = trackPt?.x ?: cap.posX
                    val anchorY = trackPt?.y ?: cap.posY

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = if (cap.animation3D == MotionAnimation3D.TYPEWRITER) {
                                cap.text.take((cap.text.length * (capProgress * 2f).coerceAtMost(1f)).toInt().coerceAtLeast(1))
                            } else cap.text,
                            color = Color(cap.colorHex),
                            fontSize = cap.fontSizeSp.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .offset(
                                    x = ((anchorX - 0.5f) * 140).dp,
                                    y = ((anchorY - 0.8f) * 180).dp
                                )
                                .graphicsLayer {
                                    scaleX = animScale
                                    scaleY = animScale
                                    rotationY = rotY
                                    cameraDistance = 12f * density
                                }
                                .background(SlateVoid.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            if (trackPt != null) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cx = size.width * trackPt.x
                    val cy = size.height * trackPt.y
                    drawCircle(
                        color = ElectricCyan,
                        radius = 22f,
                        center = Offset(cx, cy),
                        style = Stroke(width = 2.5f)
                    )
                    drawLine(ElectricCyan, Offset(cx - 30f, cy), Offset(cx + 30f, cy), strokeWidth = 2f)
                    drawLine(ElectricCyan, Offset(cx, cy - 30f), Offset(cx, cy + 30f), strokeWidth = 2f)
                }
            }

            if (project.safeZoneVisible) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val insetX = size.width * 0.08f
                    val insetY = size.height * 0.10f
                    drawRect(
                        color = WarmAmber.copy(alpha = 0.65f),
                        topLeft = Offset(insetX, insetY),
                        size = androidx.compose.ui.geometry.Size(size.width - insetX * 2, size.height - insetY * 2),
                        style = Stroke(width = 1.5f)
                    )
                }
            }
        }
    }
}
