package com.aistudio.kbeditor.r7v4qx.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import com.aistudio.kbeditor.r7v4qx.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@UnstableApi
@Composable
fun KbEditorScreen(vm: KbEditorViewModel = viewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val config = LocalConfiguration.current
    val isExpandedLayout = config.screenWidthDp >= 720
    val selectedClip = state.project.videoClips.getOrNull(state.selectedVideoIndex)

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importVideoClip(uri)
    }
    val pipPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importPipOverlay(uri)
    }

    var copilotInput by remember { mutableStateOf("") }

    Scaffold(
        containerColor = SlateVoid,
        topBar = {
            StudioTopBar(
                canUndo = state.canUndo,
                canRedo = state.canRedo,
                isBusy = state.isBusy,
                onImport = {
                    videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                },
                onUndo = vm::undo,
                onRedo = vm::redo,
                onReset = vm::resetProject,
                onExport = { vm.openSheet(ActiveStudioSheet.EXPORT_PRO) }
            )
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                state.statusBanner?.let { banner ->
                    Surface(
                        color = SlateElevated,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(banner, style = MaterialTheme.typography.labelSmall, color = ElectricCyan, modifier = Modifier.weight(1f))
                            IconButton(onClick = vm::clearStatusBanner, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = TextMuted)
                            }
                        }
                    }
                }

                VerticalPreviewStage(
                    project = state.project,
                    playheadMs = state.playheadMs,
                    selectedClip = selectedClip,
                    isMotionTrackerMode = state.activeSheet == ActiveStudioSheet.MOTION_TRACKER,
                    onTrackerTap = { x, y -> vm.runMotionTracking(x, y) },
                    modifier = Modifier.weight(1f)
                )

                TransportControlsBar(
                    isPlaying = state.isPlaying,
                    aspectLabel = state.project.aspectRatio.label,
                    safeZoneVisible = state.project.safeZoneVisible,
                    onStepFrame = vm::stepFrames,
                    onStepSecond = vm::stepSeconds,
                    onTogglePlay = vm::togglePlayPause,
                    onOpenRatio = { vm.openSheet(ActiveStudioSheet.CANVAS_REFRAME) },
                    onToggleSafeZone = vm::toggleSafeZone
                )

                MultiTrackTimeline(
                    project = state.project,
                    playheadMs = state.playheadMs,
                    selectedVideoIndex = state.selectedVideoIndex,
                    onSelectVideo = vm::selectVideoClip,
                    onSeekMs = vm::seekTo,
                    onToggleTrack = vm::updateTrackState,
                    onOpenSheet = vm::openSheet,
                    onSplitClip = vm::splitSelectedClipAtPlayhead,
                    onRippleDelete = vm::rippleDeleteSelectedClip,
                    onMoveClip = vm::moveSelectedClip
                )

                if (!isExpandedLayout) {
                    // Compact Handheld Docked AI Copilot Command Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SlateBase, RoundedCornerShape(12.dp))
                            .border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(onClick = { vm.toggleAiDrawer() }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "AI Drawer", tint = ElectricCyan)
                        }
                        OutlinedTextField(
                            value = copilotInput,
                            onValueChange = { copilotInput = it },
                            placeholder = { Text("AI Copilot: e.g. Teal Orange + Flash In", style = MaterialTheme.typography.labelSmall) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                if (copilotInput.isNotBlank()) {
                                    vm.runAiCopilot(copilotInput)
                                    copilotInput = ""
                                }
                            }
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Run AI", tint = ElectricCyan)
                        }
                    }
                }
            }

            if (isExpandedLayout) {
                AiSidePanel(
                    statusBanner = state.statusBanner,
                    onRunCopilot = vm::runAiCopilot,
                    onOpenAutoCreator = { vm.openSheet(ActiveStudioSheet.AUTO_CREATOR) },
                    modifier = Modifier.width(310.dp)
                )
            }
        }

        if (state.activeSheet != ActiveStudioSheet.NONE) {
            ModalBottomSheet(
                onDismissRequest = { vm.openSheet(ActiveStudioSheet.NONE) },
                containerColor = SlateBase
            ) {
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    when (state.activeSheet) {
                        ActiveStudioSheet.COLOR_WHEELS -> selectedClip?.let { clip ->
                            ColorWheelsPanel(
                                grade = clip.colorGrade,
                                onUpdateGrade = { g -> vm.updateSelectedClip { it.copy(colorGrade = g) } },
                                onAiColorGrade = vm::runAiColorGrade
                            )
                        }
                        ActiveStudioSheet.SPEED_RAMP -> selectedClip?.let { clip ->
                            SpeedRampSheet(
                                clip = clip,
                                onUpdateClip = { updated -> vm.updateSelectedClip { updated } }
                            )
                        }
                        ActiveStudioSheet.VFX_CHROMA_MASK -> selectedClip?.let { clip ->
                            VfxChromaMaskSheet(
                                clip = clip,
                                onUpdateClip = { updated -> vm.updateSelectedClip { updated } }
                            )
                        }
                        ActiveStudioSheet.MOTION_TRACKER -> MotionTrackerPanel(
                            pointCount = selectedClip?.motionTrackPoints?.size ?: 0,
                            onRunTrack = vm::runMotionTracking
                        )
                        ActiveStudioSheet.PIP_OVERLAY -> PipOverlaySheet(
                            onPickPipMedia = {
                                pipPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                            },
                            onAddOpticalPreset = { preset, blend ->
                                vm.importPipOverlay(uri = null, opticalPreset = preset, blendMode = blend)
                            }
                        )
                        ActiveStudioSheet.CAPTION_3D -> Caption3DSheet(
                            onAddCaption = { txt, anim ->
                                vm.addOrUpdateCaption(txt, anim, selectedClip?.id)
                                vm.openSheet(ActiveStudioSheet.NONE)
                            }
                        )
                        ActiveStudioSheet.AUDIO_PRO -> AudioProSheet(
                            audioClip = state.project.audioClips.firstOrNull(),
                            onExtractAudio = vm::extractAudioFromSelectedClip,
                            onUpdateDsp = vm::updateAudioDsp,
                            onDetectBeats = vm::detectBeatsOnAudio,
                            onGenerateVoiceover = vm::generateVoiceover
                        )
                        ActiveStudioSheet.AUTO_CREATOR -> AutoCreatorSheet(
                            onRunAutoCreator = vm::runAiAutoCreator,
                            onGenerateAiBroll = vm::generateAiBroll
                        )
                        ActiveStudioSheet.EXPORT_PRO -> ExportProSheet(
                            settings = state.project.exportSettings,
                            exportProgress = state.exportProgress,
                            lastExportPath = state.lastExportPath,
                            onUpdateSettings = vm::updateExportSettings,
                            onStartExport = vm::startExport
                        )
                        ActiveStudioSheet.CANVAS_REFRAME -> CanvasReframeSheet(
                            project = state.project,
                            onUpdateCanvas = vm::updateCanvasSettings,
                            onSmartAutoReframe = vm::runSmartAutoReframe
                        )
                        ActiveStudioSheet.NONE -> Unit
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun StudioTopBar(
    canUndo: Boolean,
    canRedo: Boolean,
    isBusy: Boolean,
    onImport: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onReset: () -> Unit,
    onExport: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("KB EDITOR", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
            if (isBusy) {
                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = WarmAmber)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            IconButton(onClick = onImport) {
                Icon(Icons.Default.AddCircleOutline, contentDescription = "Import Video", tint = ElectricCyan)
            }
            IconButton(onClick = onUndo, enabled = canUndo) {
                Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo", tint = if (canUndo) TextPrimary else TextMuted)
            }
            IconButton(onClick = onRedo, enabled = canRedo) {
                Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo", tint = if (canRedo) TextPrimary else TextMuted)
            }
            IconButton(onClick = onReset) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = TextMuted)
            }
            Button(
                onClick = onExport,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Text("Export", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun TransportControlsBar(
    isPlaying: Boolean,
    aspectLabel: String,
    safeZoneVisible: Boolean,
    onStepFrame: (Int) -> Unit,
    onStepSecond: (Int) -> Unit,
    onTogglePlay: () -> Unit,
    onOpenRatio: () -> Unit,
    onToggleSafeZone: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(onClick = { onStepSecond(-1) }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.height(30.dp)) {
                Text("-1s", style = MaterialTheme.typography.labelSmall)
            }
            FilledTonalButton(onClick = { onStepFrame(-1) }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.height(30.dp)) {
                Text("-1f", style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onTogglePlay, modifier = Modifier.size(34.dp)) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                    contentDescription = "Play/Pause",
                    tint = ElectricCyan,
                    modifier = Modifier.size(30.dp)
                )
            }
            FilledTonalButton(onClick = { onStepFrame(1) }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.height(30.dp)) {
                Text("+1f", style = MaterialTheme.typography.labelSmall)
            }
            FilledTonalButton(onClick = { onStepSecond(1) }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.height(30.dp)) {
                Text("+1s", style = MaterialTheme.typography.labelSmall)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(
                onClick = onOpenRatio,
                contentPadding = PaddingValues(horizontal = 10.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(aspectLabel, style = MaterialTheme.typography.labelSmall, color = ElectricCyan)
            }
            IconButton(onClick = onToggleSafeZone, modifier = Modifier.size(30.dp)) {
                Icon(
                    Icons.Default.GridOn,
                    contentDescription = "Safe Zone",
                    tint = if (safeZoneVisible) WarmAmber else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
