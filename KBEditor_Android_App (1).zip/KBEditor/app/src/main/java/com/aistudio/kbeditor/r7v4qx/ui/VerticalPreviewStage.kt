package com.aistudio.kbeditor.r7v4qx.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aistudio.kbeditor.r7v4qx.model.*
import com.aistudio.kbeditor.r7v4qx.ui.theme.*
import com.aistudio.kbeditor.r7v4qx.vfx.CurveEvaluators
import kotlin.math.sin

@Composable
fun VerticalPreviewStage(
    project: KbEditorProject,
    playheadMs: Long,
    selectedClip: VideoClip?,
    isMotionTrackerMode: Boolean = false,
    onTrackerTap: (Float, Float) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val ratio = project.aspectRatio.widthRatio / project.aspectRatio.heightRatio
    val colorMatrix = selectedClip?.let { CurveEvaluators.buildGradeColorMatrix(it.colorGrade) }

    val clipNormT = if (selectedClip != null && selectedClip.activeDurationMs > 0L) {
        ((playheadMs % selectedClip.activeDurationMs).toFloat() / selectedClip.activeDurationMs).coerceIn(0f, 1f)
    } else 0f

    val kf = selectedClip?.let { CurveEvaluators.interpolateKeyframes(it.keyframes, clipNormT) }
    val trackPt = selectedClip?.motionTrackPoints?.takeIf { it.isNotEmpty() }?.let {
        CurveEvaluators.interpolateKeyframes(it, clipNormT)
    }

    val maskShape = when (selectedClip?.maskType) {
        MaskType.CIRCLE -> CircleShape
        MaskType.ROUNDED_RECT -> RoundedCornerShape(28.dp)
        else -> RoundedCornerShape(14.dp)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(SlateVoid, RoundedCornerShape(16.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .aspectRatio(ratio)
                .fillMaxHeight()
                .clip(maskShape)
                .background(
                    when (project.canvasFillMode) {
                        CanvasFillMode.SOLID_COLOR -> Color(project.canvasSolidColorHex)
                        else -> SlateBase
                    }
                )
                .border(1.dp, SlateBorder, maskShape)
                .pointerInput(isMotionTrackerMode) {
                    if (isMotionTrackerMode) {
                        detectTapGestures { offset ->
                            onTrackerTap(
                                (offset.x / size.width.toFloat()).coerceIn(0.05f, 0.95f),
                                (offset.y / size.height.toFloat()).coerceIn(0.05f, 0.95f)
                            )
                        }
                    }
                }
        ) {
            if (project.tracks.v1Visible && selectedClip != null) {
                if (project.canvasFillMode == CanvasFillMode.BLUR_CANVAS && selectedClip.mediaUri.isNotBlank()) {
                    AsyncImage(
                        model = selectedClip.mediaUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .blur(project.canvasBlurRadius.dp)
                            .alpha(0.55f)
                    )
                }

                if (selectedClip.mediaUri.isNotBlank()) {
                    AsyncImage(
                        model = selectedClip.mediaUri,
                        contentDescription = selectedClip.title,
                        contentScale = ContentScale.Crop,
                        colorFilter = colorMatrix?.let { ColorFilter.colorMatrix(it) },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                translationX = selectedClip.reframeOffsetX * 120f + ((kf?.x ?: 0.5f) - 0.5f) * 140f
                                translationY = ((kf?.y ?: 0.5f) - 0.5f) * 140f
                                scaleX = kf?.scale ?: 1f
                                scaleY = kf?.scale ?: 1f
                                rotationZ = kf?.rotationDeg ?: 0f
                                alpha = kf?.opacity ?: 1f
                            }
                    )
                } else {
                    // Studio Preview Slate when no media URI is loaded yet
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    listOf(SlateVoid, Color(0xFF162238), SlateBase)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = selectedClip.title.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = ElectricCyan
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "LUT: ${selectedClip.colorGrade.lutName} • ${selectedClip.speedRamp.label}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }

                // Anamorphic 2.39:1 bars
                if (selectedClip.maskType == MaskType.ANAMORPHIC_BARS) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.12f)
                            .align(Alignment.TopCenter)
                            .background(Color.Black)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.12f)
                            .align(Alignment.BottomCenter)
                            .background(Color.Black)
                    )
                }
            }

            // Track O1: PiP & Optical FX Overlays with Compose BlendMode
            if (project.tracks.o1Visible) {
                project.pipClips.filter { playheadMs in it.startMs..(it.startMs + it.durationMs) }.forEach { pip ->
                    val composeBlend = when (pip.blendMode) {
                        BlendModePreset.NORMAL -> BlendMode.SrcOver
                        BlendModePreset.SCREEN -> BlendMode.Screen
                        BlendModePreset.MULTIPLY -> BlendMode.Multiply
                        BlendModePreset.ADD -> BlendMode.Plus
                        BlendModePreset.OVERLAY -> BlendMode.Overlay
                    }
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                    ) {
                        val center = Offset(size.width * pip.posX, size.height * pip.posY)
                        val radius = size.minDimension * 0.28f * pip.scale
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(ElectricCyan.copy(alpha = pip.opacity), WarmAmber.copy(alpha = 0.25f), Color.Transparent),
                                center = center,
                                radius = radius
                            ),
                            center = center,
                            radius = radius,
                            blendMode = composeBlend
                        )
                    }
                }
            }

            // Track T1: 3D Motion Text Captions
            if (project.tracks.t1Visible) {
                project.captionClips.filter { playheadMs in it.startMs..(it.startMs + it.durationMs) }.forEach { cap ->
                    val capProgress = ((playheadMs - cap.startMs).toFloat() / cap.durationMs.coerceAtLeast(1L)).coerceIn(0f, 1f)
                    val animScale = when (cap.animation3D) {
                        MotionAnimation3D.POP_3D -> if (capProgress < 0.2f) 0.6f + capProgress * 2.2f else 1f
                        MotionAnimation3D.FLOAT_NEON -> 1f + 0.04f * sin(capProgress * 12f)
                        else -> 1f
                    }
                    val rotY = if (cap.animation3D == MotionAnimation3D.FLIP_3D && capProgress < 0.3f) {
                        (1f - capProgress / 0.3f) * 75f
                    } else 0f

                    val anchorX = trackPt?.x ?: cap.posX
                    val anchorY = trackPt?.y ?: cap.posY

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = if (cap.animation3D == MotionAnimation3D.TYPEWRITER) {
                                cap.text.take((cap.text.length * (capProgress * 2f).coerceAtMost(1f)).toInt().coerceAtLeast(1))
                            } else cap.text,
                            color = Color(cap.colorHex),
                            fontSize = cap.fontSizeSp.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .offset(
                                    x = ((anchorX - 0.5f) * 140).dp,
                                    y = ((anchorY - 0.8f) * 180).dp
                                )
                                .graphicsLayer {
                                    scaleX = animScale
                                    scaleY = animScale
                                    rotationY = rotY
                                    cameraDistance = 12f * density
                                }
                                .background(SlateVoid.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Motion Tracker HUD Target Lock Badge
            if (trackPt != null) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cx = size.width * trackPt.x
                    val cy = size.height * trackPt.y
                    drawCircle(
                        color = ElectricCyan,
                        radius = 22f,
                        center = Offset(cx, cy),
                        style = Stroke(width = 2.5f)
                    )
                    drawLine(ElectricCyan, Offset(cx - 30f, cy), Offset(cx + 30f, cy), strokeWidth = 2f)
                    drawLine(ElectricCyan, Offset(cx, cy - 30f), Offset(cx, cy + 30f), strokeWidth = 2f)
                }
            }

            // Safe Zone Guide Overlay
            if (project.safeZoneVisible) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val insetX = size.width * 0.08f
                    val insetY = size.height * 0.10f
                    drawRect(
                        color = WarmAmber.copy(alpha = 0.65f),
                        topLeft = Offset(insetX, insetY),
                        size = androidx.compose.ui.geometry.Size(size.width - insetX * 2, size.height - insetY * 2),
                        style = Stroke(width = 1.5f)
                    )
                }
            }
        }
    }
}
