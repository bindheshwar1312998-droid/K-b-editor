package com.aistudio.kbeditor.r7v4qx.vfx

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import com.aistudio.kbeditor.r7v4qx.model.KeyframePoint

/**
 * Time-dependent Keyframe Transform GL Effect for Media3 Transformer Export.
 * Smoothly animates Zoom/Scale, Pan X/Y, Rotation, and Opacity across the exported clip
 * matching VerticalPreviewStage's CurveEvaluators interpolation.
 */
@UnstableApi
class KeyframeTransformGlEffect(
    private val keyframes: List<KeyframePoint>,
    private val clipDurationMs: Long,
    private val baseScaleMultiplier: Float = 1.0f,
    private val baseRotationDeg: Float = 0f,
    private val flipHorizontal: Boolean = false
) : GlEffect {

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return KeyframeTransformShaderProgram(
            useHdr = useHdr,
            keyframes = keyframes,
            clipDurationMs = clipDurationMs,
            baseScaleMultiplier = baseScaleMultiplier,
            baseRotationDeg = baseRotationDeg,
            flipHorizontal = flipHorizontal
        )
    }

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean {
        return keyframes.isEmpty()
    }
}

@UnstableApi
private class KeyframeTransformShaderProgram(
    useHdr: Boolean,
    private val keyframes: List<KeyframePoint>,
    private val clipDurationMs: Long,
    private val baseScaleMultiplier: Float,
    private val baseRotationDeg: Float,
    private val flipHorizontal: Boolean
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram: GlProgram
    private var outputAspect = 9f / 16f

    init {
        try {
            glProgram = GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }

        glProgram.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
        )
        val identity = GlUtil.create4x4IdentityMatrix()
        glProgram.setFloatsUniform("uTransformationMatrix", identity)
        glProgram.setFloatsUniform("uTexTransformationMatrix", identity)
        glProgram.setFloatUniform("uFlipX", if (flipHorizontal) 1.0f else 0.0f)
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        val w = inputWidth.coerceAtLeast(1)
        val h = inputHeight.coerceAtLeast(1)
        outputAspect = w.toFloat() / h.toFloat()
        return Size(w, h)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        val durMs = clipDurationMs.coerceAtLeast(1L).toFloat()
        val timeMs = (presentationTimeUs / 1000.0).toFloat()
        val normT = (timeMs / durMs).coerceIn(0f, 1f)
        val kf = CurveEvaluators.interpolateKeyframes(keyframes, normT)

        val scale = (kf.scale * baseScaleMultiplier).coerceIn(0.05f, 10.0f)
        val panX = (kf.x - 0.5f).coerceIn(-2.0f, 2.0f)
        val panY = (kf.y - 0.5f).coerceIn(-2.0f, 2.0f)
        val rotRad = Math.toRadians((baseRotationDeg + kf.rotationDeg).toDouble()).toFloat()
        val alpha = kf.opacity.coerceIn(0f, 1f)

        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.setFloatUniform("uScale", scale)
            glProgram.setFloatUniform("uPanX", panX)
            glProgram.setFloatUniform("uPanY", panY)
            glProgram.setFloatUniform("uRotRad", rotRad)
            glProgram.setFloatUniform("uAlpha", alpha)
            glProgram.setFloatUniform("uAspect", outputAspect)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    companion object {
        private const val VERTEX_SHADER = """
            #version 100
            attribute vec4 aFramePosition;
            uniform mat4 uTransformationMatrix;
            uniform mat4 uTexTransformationMatrix;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = uTransformationMatrix * aFramePosition;
                vec4 texCoord = vec4(aFramePosition.x * 0.5 + 0.5, aFramePosition.y * 0.5 + 0.5, 0.0, 1.0);
                vTexSamplingCoord = (uTexTransformationMatrix * texCoord).xy;
            }
        """

        private const val FRAGMENT_SHADER = """
            #version 100
            precision mediump float;
            uniform sampler2D uTexSampler;
            varying vec2 vTexSamplingCoord;
            uniform float uScale;
            uniform float uPanX;
            uniform float uPanY;
            uniform float uRotRad;
            uniform float uAlpha;
            uniform float uAspect;
            uniform float uFlipX;

            void main() {
                vec2 uv = vTexSamplingCoord;
                vec2 centered = uv - vec2(0.5 + uPanX, 0.5 - uPanY);
                centered.x *= uAspect;
                float c = cos(-uRotRad);
                float s = sin(-uRotRad);
                vec2 rot = vec2(centered.x * c - centered.y * s, centered.x * s + centered.y * c);
                rot.x /= uAspect;
                vec2 src = (rot / max(uScale, 0.05)) + vec2(0.5);
                if (uFlipX > 0.5) {
                    src.x = 1.0 - src.x;
                }
                if (src.x < 0.0 || src.x > 1.0 || src.y < 0.0 || src.y > 1.0) {
                    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
                    return;
                }
                vec4 col = texture2D(uTexSampler, src);
                gl_FragColor = vec4(col.rgb * uAlpha, col.a);
            }
        """
    }
}
