package com.aistudio.kbeditor.r7v4qx.ui

import android.content.Context
import androidx.compose.runtime.compositionLocalOf

enum class AppUiLanguage(val code: String, val nativeName: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "हिन्दी (Hindi)"),
    BENGALI("bn", "বাংলা (Bengali)"),
    MARATHI("mr", "मराठी (Marathi)"),
    TELUGU("te", "తెలుగు (Telugu)"),
    TAMIL("ta", "தமிழ் (Tamil)"),
    GUJARATI("gu", "ગુજરાતી (Gujarati)"),
    URDU("ur", "اردو (Urdu)"),
    KANNADA("kn", "ಕನ್ನಡ (Kannada)"),
    ODIA("or", "ଓଡ଼ିଆ (Odia)"),
    MALAYALAM("ml", "മലയാളം (Malayalam)"),
    PUNJABI("pa", "ਪੰਜਾਬੀ (Punjabi)"),
    ASSAMESE("as", "অসমীয়া (Assamese)"),
    MAITHILI("mai", "मैथिली (Maithili)"),
    SANTALI("sat", "संताली (Santali)"),
    KASHMIRI("ks", "कॉशुर (Kashmiri)"),
    NEPALI("ne", "नेपाली (Nepali)"),
    KONKANI("kok", "कोंकणी (Konkani)"),
    SINDHI("sd", "سنڌي (Sindhi)"),
    DOGRI("doi", "डोगरी (Dogri)"),
    MANIPURI("mni", "মৈতৈলোন্ (Manipuri)"),
    BODO("brx", "बड़ो (Bodo)"),
    SANSKRIT("sa", "संस्कृतम् (Sanskrit)")
}

data class LocalizedLabels(
    val exportBtn: String,
    val editTab: String,
    val audioTab: String,
    val textTab: String,
    val stickersTab: String,
    val effectsTab: String,
    val overlayTab: String,
    val maskTab: String,
    val aiDubTab: String,
    val enhanceTab: String,
    val splitBtn: String,
    val deleteBtn: String,
    val keyframeBtn: String,
    val languageTitle: String
)

object AppLocalization {
    private const val PREF_NAME = "kb_app_ui_lang"
    private const val KEY_CODE = "ui_lang_code"

    fun loadSaved(context: Context): AppUiLanguage {
        val code = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CODE, "en").orEmpty()
        return AppUiLanguage.entries.firstOrNull { it.code == code } ?: AppUiLanguage.ENGLISH
    }

    fun save(context: Context, lang: AppUiLanguage) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_CODE, lang.code).apply()
    }

    fun labelsFor(lang: AppUiLanguage): LocalizedLabels = when (lang) {
        AppUiLanguage.HINDI, AppUiLanguage.MAITHILI, AppUiLanguage.DOGRI, AppUiLanguage.SANSKRIT -> LocalizedLabels(
            exportBtn = "एक्सपोर्ट", editTab = "एडिट", audioTab = "ऑडियो", textTab = "टेक्स्ट",
            stickersTab = "स्टिकर", effectsTab = "इफ़ेक्ट्स", overlayTab = "ओवरले", maskTab = "मास्क",
            aiDubTab = "ऑटो डब", enhanceTab = "एनहांस", splitBtn = "कट", deleteBtn = "हटाएँ",
            keyframeBtn = "कीफ़्रेम", languageTitle = "ऐप भाषा (23 भाषाएँ)"
        )
        AppUiLanguage.PUNJABI -> LocalizedLabels(
            exportBtn = "ਐਕਸਪੋਰਟ", editTab = "ਐਡਿਟ", audioTab = "ਆਡੀਓ", textTab = "ਟੈਕਸਟ",
            stickersTab = "ਸਟਿੱਕਰ", effectsTab = "ਇਫੈਕਟਸ", overlayTab = "ਓਵਰਲੇ", maskTab = "ਮਾਸਕ",
            aiDubTab = "ਆਟੋ ਡੱਬ", enhanceTab = "ਐਨਹਾਂਸ", splitBtn = "ਕੱਟ", deleteBtn = "ਹਟਾਓ",
            keyframeBtn = "ਕੀਫ੍ਰੇਮ", languageTitle = "ਐਪ ਭਾਸ਼ਾ (23)"
        )
        AppUiLanguage.BENGALI, AppUiLanguage.ASSAMESE, AppUiLanguage.MANIPURI -> LocalizedLabels(
            exportBtn = "এক্সপোর্ট", editTab = "এডিট", audioTab = "অডিও", textTab = "টেক্সট",
            stickersTab = "স্টিকার", effectsTab = "ইফেক্টস", overlayTab = "ওভারলে", maskTab = "মাস্ক",
            aiDubTab = "অটো ডাব", enhanceTab = "এনহ্যান্স", splitBtn = "কাট", deleteBtn = "মুছুন",
            keyframeBtn = "কি-ফ্রেম", languageTitle = "অ্যাপ ভাষা (23)"
        )
        AppUiLanguage.MARATHI, AppUiLanguage.KONKANI, AppUiLanguage.NEPALI -> LocalizedLabels(
            exportBtn = "एक्सपोर्ट", editTab = "एडिट", audioTab = "ऑडिओ", textTab = "टेक्स्ट",
            stickersTab = "स्टिकर", effectsTab = "इफेक्ट्स", overlayTab = "ओव्हरले", maskTab = "मास्क",
            aiDubTab = "ऑटो डब", enhanceTab = "एनहान्स", splitBtn = "कट", deleteBtn = "काढा",
            keyframeBtn = "कीफ्रेम", languageTitle = "अॅप भाषा (23)"
        )
        AppUiLanguage.GUJARATI -> LocalizedLabels(
            exportBtn = "એક્સપોર્ટ", editTab = "એડિટ", audioTab = "ઓડિયો", textTab = "ટેક્સ્ટ",
            stickersTab = "સ્ટિકર", effectsTab = "ઇફેક્ટ્સ", overlayTab = "ઓવરલે", maskTab = "માસ્ક",
            aiDubTab = "ઓટો ડબ", enhanceTab = "એનહાન્સ", splitBtn = "કટ", deleteBtn = "કાઢો",
            keyframeBtn = "કીફ્રેમ", languageTitle = "એપ ભાષા (23)"
        )
        AppUiLanguage.TAMIL -> LocalizedLabels(
            exportBtn = "ஏற்றுமதி", editTab = "திருத்து", audioTab = "ஆடியோ", textTab = "உரை",
            stickersTab = "ஸ்டிக்கர்", effectsTab = "விளைவுகள்", overlayTab = "மேலடுக்கு", maskTab = "மாஸ்க்",
            aiDubTab = "ஆட்டோ டப்", enhanceTab = "மேம்படுத்து", splitBtn = "பிரி", deleteBtn = "நீக்கு",
            keyframeBtn = "கீஃபிரேம்", languageTitle = "ஆப் மொழி (23)"
        )
        AppUiLanguage.TELUGU -> LocalizedLabels(
            exportBtn = "ఎక్స్‌పోర్ట్", editTab = "ఎడిట్", audioTab = "ఆడియో", textTab = "టెక్స్ట్",
            stickersTab = "స్టిక్కర్", effectsTab = "ఎఫెక్ట్స్", overlayTab = "ఓవర్‌లే", maskTab = "మాస్క్",
            aiDubTab = "ఆటో డబ్", enhanceTab = "ఎన్‌హాన్స్", splitBtn = "కట్", deleteBtn = "తొలగించు",
            keyframeBtn = "కీఫ్రేమ్", languageTitle = "యాప్ భాష (23)"
        )
        AppUiLanguage.KANNADA -> LocalizedLabels(
            exportBtn = "ಎಕ್ಸ್‌ಪೋರ್ಟ್", editTab = "ಎಡಿಟ್", audioTab = "ಆಡಿಯೋ", textTab = "ಪಠ್ಯ",
            stickersTab = "ಸ್ಟಿಕ್ಕರ್", effectsTab = "ಎಫೆಕ್ಟ್ಸ್", overlayTab = "ಓವರ್‌ಲೇ", maskTab = "ಮಾಸ್ಕ್",
            aiDubTab = "ಆಟೋ ಡಬ್", enhanceTab = "ಎನ್‌ಹ್ಯಾನ್ಸ್", splitBtn = "ಕಟ್", deleteBtn = "ಅಳಿಸಿ",
            keyframeBtn = "ಕೀಫ್ರೇಮ್", languageTitle = "ಆ್ಯಪ್ ಭಾಷೆ (23)"
        )
        AppUiLanguage.MALAYALAM -> LocalizedLabels(
            exportBtn = "എക്സ്പോർട്ട്", editTab = "എഡിറ്റ്", audioTab = "ഓഡിയോ", textTab = "ടെക്സ്റ്റ്",
            stickersTab = "സ്റ്റിക്കർ", effectsTab = "ഇഫക്റ്റുകൾ", overlayTab = "ഓവർലേ", maskTab = "മാസ്ക്",
            aiDubTab = "ഓട്ടോ ഡബ്", enhanceTab = "എൻഹാൻസ്", splitBtn = "മുറിക്കുക", deleteBtn = "നീക്കുക",
            keyframeBtn = "കീഫ്രെയിം", languageTitle = "ആപ്പ് ഭാഷ (23)"
        )
        AppUiLanguage.ODIA -> LocalizedLabels(
            exportBtn = "ଏକ୍ସପୋର୍ଟ", editTab = "ଏଡିଟ୍", audioTab = "ଅଡିଓ", textTab = "ଟେକ୍ସଟ୍",
            stickersTab = "ଷ୍ଟିକର୍", effectsTab = "ଇଫେକ୍ଟସ୍", overlayTab = "ଓଭରଲେ", maskTab = "ମାସ୍କ",
            aiDubTab = "ଅଟୋ ଡବ୍", enhanceTab = "ଏନହାନ୍ସ", splitBtn = "କଟ୍", deleteBtn = "ଲିଭାନ୍ତୁ",
            keyframeBtn = "କିଫ୍ରେମ୍", languageTitle = "ଆପ୍ ଭାଷା (23)"
        )
        AppUiLanguage.URDU, AppUiLanguage.SINDHI, AppUiLanguage.KASHMIRI -> LocalizedLabels(
            exportBtn = "ایکسپورٹ", editTab = "ایڈٹ", audioTab = "آڈیو", textTab = "ٹیکسٹ",
            stickersTab = "اسٹیکر", effectsTab = "افیکٹس", overlayTab = "اوورلے", maskTab = "ماسک",
            aiDubTab = "آٹو ڈب", enhanceTab = "انہینس", splitBtn = "کٹ", deleteBtn = "حذف کریں",
            keyframeBtn = "کی فریم", languageTitle = "ایپ کی زبان (23)"
        )
        else -> LocalizedLabels(
            exportBtn = "Export", editTab = "Edit", audioTab = "Audio", textTab = "Text",
            stickersTab = "Stickers", effectsTab = "Effects", overlayTab = "Overlay", maskTab = "Mask",
            aiDubTab = "Auto-Dub", enhanceTab = "Enhance", splitBtn = "Split", deleteBtn = "Delete",
            keyframeBtn = "Keyframe", languageTitle = "App Language (23 Official)"
        )
    }
}

val LocalAppLabels = compositionLocalOf { AppLocalization.labelsFor(AppUiLanguage.ENGLISH) }
