package com.aistudio.kbeditor.r7v4qx.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import com.aistudio.kbeditor.r7v4qx.model.VocalIsolationMode
import java.nio.ByteBuffer
import kotlin.math.abs

/**
 * Dedicated Real-Time Video Noise Cancelling & Studio Audio DSP Engine.
 * Runs sample-by-sample in both Live ExoPlayer Preview and Media3 MP4 Export:
 * - 130Hz Wind & Rumble High-Pass Filter
 * - Adaptive Smooth-Envelope Noise Gate (eliminates fan/AC/traffic hum without speech chatter)
 * - High-Frequency Mic Hiss Softener
 * - Podcast Presence Boost + Soft Limiter
 * - Mid/Side Vocal Isolation
 */
@UnstableApi
class StudioAudioDspProcessor(
    @Volatile var windFilterEnabled: Boolean = false,
    @Volatile var noiseGateEnabled: Boolean = false,
    @Volatile var voiceEnhanceEnabled: Boolean = false,
    @Volatile var vocalMode: VocalIsolationMode = VocalIsolationMode.FULL_MIX
) : BaseAudioProcessor() {

    private var prevInL = 0f
    private var prevOutL = 0f
    private var prevInR = 0f
    private var prevOutR = 0f
    private var lpL = 0f
    private var lpR = 0f
    private var envL = 0f
    private var envR = 0f
    private var gateGainL = 1f
    private var gateGainR = 1f

    private val highPassAlpha = 0.935f
    private val hissLowPassAlpha = 0.72f
    private val gateThreshold = 0.045f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun onFlush() {
        prevInL = 0f
        prevOutL = 0f
        prevInR = 0f
        prevOutR = 0f
        lpL = 0f
        lpR = 0f
        envL = 0f
        envR = 0f
        gateGainL = 1f
        gateGainR = 1f
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val outBuffer = replaceOutputBuffer(remaining)
        val channels = inputAudioFormat.channelCount.coerceAtLeast(1)

        if (channels >= 2) {
            while (inputBuffer.remaining() >= 4) {
                var l = inputBuffer.short / 32768f
                var r = inputBuffer.short / 32768f

                if (windFilterEnabled || noiseGateEnabled) {
                    val hpL = highPassAlpha * (prevOutL + l - prevInL)
                    prevInL = l
                    prevOutL = hpL
                    l = hpL

                    val hpR = highPassAlpha * (prevOutR + r - prevInR)
                    prevInR = r
                    prevOutR = hpR
                    r = hpR
                }

                if (noiseGateEnabled) {
                    // Smooth envelope follower + hysteresis gate (no clicking/chatter)
                    val absL = abs(l)
                    val absR = abs(r)
                    envL = if (absL > envL) envL + 0.08f * (absL - envL) else envL + 0.0018f * (absL - envL)
                    envR = if (absR > envR) envR + 0.08f * (absR - envR) else envR + 0.0018f * (absR - envR)

                    val targetGL = if (envL >= gateThreshold) 1f else 0.06f
                    val targetGR = if (envR >= gateThreshold) 1f else 0.06f
                    gateGainL += (targetGL - gateGainL) * 0.04f
                    gateGainR += (targetGR - gateGainR) * 0.04f

                    l *= gateGainL
                    r *= gateGainR

                    // Gentle high-frequency hiss reduction
                    lpL += hissLowPassAlpha * (l - lpL)
                    lpR += hissLowPassAlpha * (r - lpR)
                    l = lpL
                    r = lpR
                }

                if (voiceEnhanceEnabled) {
                    l = kotlin.math.tanh((l * 1.42f).toDouble()).toFloat()
                    r = kotlin.math.tanh((r * 1.42f).toDouble()).toFloat()
                }

                val mid = (l + r) * 0.5f
                val side = (l - r) * 0.5f
                when (vocalMode) {
                    VocalIsolationMode.FULL_MIX -> Unit
                    VocalIsolationMode.ISOLATE_VOCALS -> {
                        l = (mid * 1.18f).coerceIn(-1f, 1f)
                        r = l
                    }
                    VocalIsolationMode.INSTRUMENTAL_ONLY -> {
                        l = (side * 1.4f).coerceIn(-1f, 1f)
                        r = (-side * 1.4f).coerceIn(-1f, 1f)
                    }
                }

                outBuffer.putShort((l.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                outBuffer.putShort((r.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            }
        } else {
            while (inputBuffer.remaining() >= 2) {
                var s = inputBuffer.short / 32768f
                if (windFilterEnabled || noiseGateEnabled) {
                    val hp = highPassAlpha * (prevOutL + s - prevInL)
                    prevInL = s
                    prevOutL = hp
                    s = hp
                }
                if (noiseGateEnabled) {
                    val absS = abs(s)
                    envL = if (absS > envL) envL + 0.08f * (absS - envL) else envL + 0.0018f * (absS - envL)
                    val targetG = if (envL >= gateThreshold) 1f else 0.06f
                    gateGainL += (targetG - gateGainL) * 0.04f
                    s *= gateGainL
                    lpL += hissLowPassAlpha * (s - lpL)
                    s = lpL
                }
                if (voiceEnhanceEnabled) {
                    s = kotlin.math.tanh((s * 1.42f).toDouble()).toFloat()
                }
                outBuffer.putShort((s.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            }
        }

        outBuffer.flip()
    }
}
