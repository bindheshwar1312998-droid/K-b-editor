package com.aistudio.kbeditor.r7v4qx.vfx

import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.aistudio.kbeditor.r7v4qx.model.ColorGradeSpec
import com.aistudio.kbeditor.r7v4qx.model.VideoClip
import com.aistudio.kbeditor.r7v4qx.model.VideoFxPreset
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

data class LiveGlParams(
    val exposure: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val warmth: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val vignette: Float = 0f,
    val filterIntensity: Float = 1f,
    val chromaEnabled: Boolean = false,
    val keyR: Float = 0f,
    val keyG: Float = 1f,
    val keyB: Float = 0f,
    val chromaSim: Float = 0.35f,
    val fxMode: Float = 0f,
    val fxIntensity: Float = 1f,
    val fxTexture: Float = 0.45f,
    val fxColorShift: Float = 0f,
    val waterReflection: Boolean = false,
    val motionBlur: Float = 0f,
    val beautyGlow: Float = 0f,
    val sharpen: Float = 0f,
    val timeSec: Float = 0f
)

fun VideoClip.toLiveGlParams(timeSec: Float, fxActive: Boolean): LiveGlParams {
    val g: ColorGradeSpec = colorGrade
    val fi = filterIntensity.coerceIn(0f, 1.5f)
    val fxMode = if (!fxActive) 0f else when (videoFx) {
        VideoFxPreset.NONE -> 0f
        VideoFxPreset.GLITCH_RGB, VideoFxPreset.TEAR_APART, VideoFxPreset.CYBER_GLITCH -> 1f
        VideoFxPreset.VHS_RETRO, VideoFxPreset.OLD_TV, VideoFxPreset.RETRO_FLICKER,
        VideoFxPreset.PC_MONITOR, VideoFxPreset.WINDOWS_XP, VideoFxPreset.TERMINAL_HUD -> 2f
        VideoFxPreset.CAM_SHAKE, VideoFxPreset.EARTHQUAKE, VideoFxPreset.IMPACT_SHAKE -> 3f
        VideoFxPreset.FLASH_STROBE, VideoFxPreset.ACTION_FLASH, VideoFxPreset.WHITE_FLASH -> 4f
        VideoFxPreset.CHROMATIC, VideoFxPreset.PRISM_SHIMMER, VideoFxPreset.SHARDS_LIGHT -> 6f
        VideoFxPreset.ZOOM_PULSE, VideoFxPreset.ZOOM_LENS, VideoFxPreset.HEARTBEAT -> 7f
        VideoFxPreset.CINEMA_GRAIN, VideoFxPreset.BW_GRAIN, VideoFxPreset.BW_SCANNER,
        VideoFxPreset.MONOCHROME_PRO, VideoFxPreset.NOIR_SHADOW -> 8f
        VideoFxPreset.SPLIT_2X, VideoFxPreset.MIRROR_SPLIT -> 9f
        VideoFxPreset.SPLIT_3X, VideoFxPreset.SPLIT_4X, VideoFxPreset.SPLIT_6X, VideoFxPreset.SPLIT_9X -> 10f
        VideoFxPreset.NEON_EDGE, VideoFxPreset.NEON_FLOW, VideoFxPreset.SKETCH_OUTLINE -> 11f
        else -> when (videoFx.category) {
            "Split & Glitch" -> 6f
            "Retro & Film" -> 2f
            "Cinema & Moody" -> 8f
            else -> 5f
        }
    }
    val isWater = fxActive && videoFx in listOf(
        VideoFxPreset.WATER_REFLECTION,
        VideoFxPreset.WATER_RIPPLE,
        VideoFxPreset.RAIN_PUDDLE,
        VideoFxPreset.MIRROR_LAKE
    )
    val kc = chromaKey.keyColorHex
    val kr = ((kc shr 16) and 0xFF) / 255f
    val kg = ((kc shr 8) and 0xFF) / 255f
    val kb = (kc and 0xFF) / 255f
    return LiveGlParams(
        exposure = g.exposure * fi,
        contrast = 1f + (g.contrast - 1f) * fi,
        saturation = 1f + (g.saturation - 1f) * fi,
        warmth = g.warmth * fi,
        highlights = g.highlights * fi,
        shadows = g.shadows * fi,
        vignette = g.vignette * fi,
        filterIntensity = fi,
        chromaEnabled = chromaKey.enabled,
        keyR = kr,
        keyG = kg,
        keyB = kb,
        chromaSim = chromaKey.similarity.coerceIn(0.05f, 0.8f),
        fxMode = fxMode,
        fxIntensity = videoFxIntensity.coerceIn(0.1f, 2f),
        fxTexture = videoFxTexture.coerceIn(0f, 1f),
        fxColorShift = videoFxColorShift.coerceIn(-1f, 1f),
        waterReflection = isWater,
        motionBlur = if (fxActive && videoFx in listOf(
                VideoFxPreset.MOTION_BLUR, VideoFxPreset.RADIAL_BLUR,
                VideoFxPreset.TURBO_BLUR, VideoFxPreset.HALO_BLUR
            )
        ) 0.012f * videoFxIntensity.coerceIn(0.1f, 2f) else 0f,
        beautyGlow = (g.beautyGlow + g.beautySmooth * 0.4f + if (fxActive && videoFx in listOf(
                VideoFxPreset.SOFT_GLOW, VideoFxPreset.DREAM_BLOOM,
                VideoFxPreset.PEARL_GLOW, VideoFxPreset.PORTRAIT_FOCUS
            )
        ) 0.35f * videoFxIntensity.coerceIn(0.1f, 2f) else 0f).coerceIn(0f, 0.85f),
        sharpen = when (g.lutName) {
            "4K Ultra Crisp" -> 0.55f
            "HD Crisp" -> 0.38f
            else -> if (fxActive && videoFx in listOf(VideoFxPreset.SILK_SHARPEN, VideoFxPreset.CRISP_HDR, VideoFxPreset.MACRO_SHARPEN)) 0.48f else 0f
        },
        timeSec = timeSec
    )
}

@Composable
fun KbLiveGlPreviewView(
    exoPlayer: ExoPlayer,
    params: LiveGlParams,
    modifier: Modifier = Modifier
) {
    val renderer = remember { KbLiveGlRenderer() }
    var glViewRef: GLSurfaceView? = remember { null }

    LaunchedEffect(params) {
        renderer.params = params
        glViewRef?.requestRender()
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    renderer.setVideoSize(videoSize.width, videoSize.height)
                    glViewRef?.requestRender()
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            renderer.detachFromPlayer(exoPlayer)
        }
    }

    AndroidView(
        factory = { ctx: Context ->
            GLSurfaceView(ctx).apply {
                setEGLContextClientVersion(2)
                preserveEGLContextOnPause = true
                setRenderer(renderer)
                renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
                renderer.onSurfaceReady = { surface ->
                    post {
                        exoPlayer.setVideoSurface(surface)
                        requestRender()
                    }
                }
                renderer.onFrameArrived = {
                    requestRender()
                }
                glViewRef = this
            }
        },
        update = { view ->
            glViewRef = view
            renderer.params = params
            view.requestRender()
        },
        modifier = modifier
    )
}

private class KbLiveGlRenderer : GLSurfaceView.Renderer {

    @Volatile
    var params: LiveGlParams = LiveGlParams()

    var onSurfaceReady: ((Surface) -> Unit)? = null
    var onFrameArrived: (() -> Unit)? = null

    private var programId = 0
    private var oesTexId = 0
    private var surfaceTexture: SurfaceTexture? = null
    private var videoSurface: Surface? = null

    @Volatile private var viewW = 1
    @Volatile private var viewH = 1
    @Volatile private var vidW = 16
    @Volatile private var vidH = 9
    @Volatile private var frameAvailable = false

    private val stMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    private val quadCoords = floatArrayOf(
        -1f, -1f, 0f, 0f,
         1f, -1f, 1f, 0f,
        -1f,  1f, 0f, 1f,
         1f,  1f, 1f, 1f
    )
    private val vertexBuffer: FloatBuffer = ByteBuffer
        .allocateDirect(quadCoords.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .put(quadCoords)
        .apply { position(0) }

    fun setVideoSize(w: Int, h: Int) {
        vidW = w.coerceAtLeast(1)
        vidH = h.coerceAtLeast(1)
    }

    fun detachFromPlayer(player: ExoPlayer) {
        videoSurface?.let { s ->
            runCatching { player.clearVideoSurface(s) }
            runCatching { s.release() }
        }
        runCatching { surfaceTexture?.release() }
        videoSurface = null
        surfaceTexture = null
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        oesTexId = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        programId = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)

        val st = SurfaceTexture(oesTexId)
        st.setOnFrameAvailableListener {
            frameAvailable = true
            onFrameArrived?.invoke()
        }
        surfaceTexture = st
        val surf = Surface(st)
        videoSurface = surf
        onSurfaceReady?.invoke(surf)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewW = width.coerceAtLeast(1)
        viewH = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, viewW, viewH)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (frameAvailable) {
            runCatching { surfaceTexture?.updateTexImage() }
            frameAvailable = false
        }
        runCatching { surfaceTexture?.getTransformMatrix(stMatrix) }
            ?: Matrix.setIdentityM(stMatrix, 0)

        // Compute aspect-fill (center crop) MVP matrix
        Matrix.setIdentityM(mvpMatrix, 0)
        val viewAspect = viewW.toFloat() / viewH.toFloat()
        val vidAspect = vidW.toFloat() / vidH.toFloat()
        if (vidAspect > viewAspect) {
            Matrix.scaleM(mvpMatrix, 0, vidAspect / viewAspect, 1f, 1f)
        } else {
            Matrix.scaleM(mvpMatrix, 0, 1f, viewAspect / vidAspect, 1f)
        }

        GLES20.glClearColor(0.04f, 0.05f, 0.08f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(programId)

        val aPos = GLES20.glGetAttribLocation(programId, "aPos")
        val aTex = GLES20.glGetAttribLocation(programId, "aTex")
        vertexBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)
        vertexBuffer.position(2)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)

        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(programId, "uMvpMatrix"), 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(programId, "uStMatrix"), 1, false, stMatrix, 0)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(programId, "uTex"), 0)

        val p = params
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uExposure"), p.exposure)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uContrast"), p.contrast)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uSaturation"), p.saturation)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uWarmth"), p.warmth)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uHighlights"), p.highlights)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uShadows"), p.shadows)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uVignette"), p.vignette)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uChromaEnabled"), if (p.chromaEnabled) 1f else 0f)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(programId, "uKeyColor"), p.keyR, p.keyG, p.keyB)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uChromaSim"), p.chromaSim)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uFxMode"), p.fxMode)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uFxIntensity"), p.fxIntensity)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uFxTexture"), p.fxTexture)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uFxColorShift"), p.fxColorShift)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uWaterMode"), if (p.waterReflection) 1f else 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uMotionBlur"), p.motionBlur)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uBeautyGlow"), p.beautyGlow)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uSharpen"), p.sharpen)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uTime"), p.timeSec)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aTex)
    }

    private fun buildProgram(vs: String, fs: String): Int {
        val vShader = compileShader(GLES20.GL_VERTEX_SHADER, vs)
        val fShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fs)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vShader)
        GLES20.glAttachShader(prog, fShader)
        GLES20.glLinkProgram(prog)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aPos;
            attribute vec4 aTex;
            uniform mat4 uMvpMatrix;
            uniform mat4 uStMatrix;
            varying vec2 vTexCoord;
            varying vec2 vScreenUv;
            void main() {
                gl_Position = uMvpMatrix * aPos;
                vTexCoord = (uStMatrix * vec4(aTex.xy, 0.0, 1.0)).xy;
                vScreenUv = aTex.xy;
            }
        """

        private const val FRAGMENT_SHADER = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            uniform samplerExternalOES uTex;
            varying vec2 vTexCoord;
            varying vec2 vScreenUv;

            uniform float uExposure;
            uniform float uContrast;
            uniform float uSaturation;
            uniform float uWarmth;
            uniform float uHighlights;
            uniform float uShadows;
            uniform float uVignette;

            uniform float uChromaEnabled;
            uniform vec3 uKeyColor;
            uniform float uChromaSim;

            uniform float uFxMode;
            uniform float uFxIntensity;
            uniform float uFxTexture;
            uniform float uFxColorShift;
            uniform float uWaterMode;
            uniform float uMotionBlur;
            uniform float uBeautyGlow;
            uniform float uSharpen;
            uniform float uTime;

            float rand2(vec2 co) {
                return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
            }

            void main() {
                vec2 uv = vTexCoord;

                // GPU Water Reflection & Ripple
                if (uWaterMode > 0.5 && vScreenUv.y < 0.38) {
                    float wave = sin(vScreenUv.y * 55.0 + uTime * 6.0) * 0.012 * uFxIntensity;
                    uv.x = clamp(uv.x + wave, 0.0, 1.0);
                    uv.y = clamp(1.0 - uv.y, 0.0, 1.0);
                }

                // Split FX (2-Split / Multi-Split)
                if (uFxMode > 8.5 && uFxMode < 9.5) {
                    uv.y = fract(uv.y * 2.0);
                } else if (uFxMode > 9.5 && uFxMode < 10.5) {
                    uv = fract(uv * 2.0);
                }

                // Shake / Glitch UV offsets
                if (uFxMode > 0.5 && uFxMode < 1.5) {
                    float slice = floor(uv.y * 18.0);
                    float glitch = (rand2(vec2(slice, floor(uTime * 15.0))) - 0.5) * 0.05 * uFxIntensity;
                    uv.x = clamp(uv.x + glitch, 0.0, 1.0);
                } else if (uFxMode > 2.5 && uFxMode < 3.5) {
                    uv.x = clamp(uv.x + sin(uTime * 35.0) * 0.015 * uFxIntensity, 0.0, 1.0);
                    uv.y = clamp(uv.y + cos(uTime * 29.0) * 0.012 * uFxIntensity, 0.0, 1.0);
                } else if (uFxMode > 6.5 && uFxMode < 7.5) {
                    float z = 1.0 - (0.08 * abs(sin(uTime * 8.0)) * uFxIntensity);
                    uv = (uv - 0.5) * z + 0.5;
                }

                vec4 col = texture2D(uTex, uv);
                if (uMotionBlur > 0.001) {
                    vec4 b1 = texture2D(uTex, clamp(uv + vec2(uMotionBlur, 0.0), 0.0, 1.0));
                    vec4 b2 = texture2D(uTex, clamp(uv - vec2(uMotionBlur, 0.0), 0.0, 1.0));
                    col = (col + b1 + b2) / 3.0;
                }
                if (uBeautyGlow > 0.01) {
                    vec3 g1 = texture2D(uTex, clamp(uv + vec2(0.004, 0.004), 0.0, 1.0)).rgb;
                    vec3 g2 = texture2D(uTex, clamp(uv - vec2(0.004, 0.004), 0.0, 1.0)).rgb;
                    col.rgb = mix(col.rgb, (col.rgb + g1 + g2) / 3.0 + vec3(0.04), uBeautyGlow);
                }
                if (uSharpen > 0.01) {
                    vec3 n1 = texture2D(uTex, clamp(uv + vec2(0.0025, 0.0), 0.0, 1.0)).rgb;
                    vec3 n2 = texture2D(uTex, clamp(uv - vec2(0.0025, 0.0), 0.0, 1.0)).rgb;
                    vec3 n3 = texture2D(uTex, clamp(uv + vec2(0.0, 0.0025), 0.0, 1.0)).rgb;
                    vec3 n4 = texture2D(uTex, clamp(uv - vec2(0.0, 0.0025), 0.0, 1.0)).rgb;
                    vec3 avg = (n1 + n2 + n3 + n4) * 0.25;
                    col.rgb = clamp(col.rgb + (col.rgb - avg) * uSharpen, 0.0, 1.0);
                }

                // Chromatic Aberration / RGB Glitch
                if ((uFxMode > 0.5 && uFxMode < 1.5) || (uFxMode > 5.5 && uFxMode < 6.5)) {
                    float off = 0.012 * uFxIntensity;
                    col.r = texture2D(uTex, clamp(uv + vec2(off, 0.0), 0.0, 1.0)).r;
                    col.b = texture2D(uTex, clamp(uv - vec2(off, 0.0), 0.0, 1.0)).b;
                }

                // Neon Edge
                if (uFxMode > 10.5) {
                    vec3 cR = texture2D(uTex, clamp(uv + vec2(0.004, 0.0), 0.0, 1.0)).rgb;
                    vec3 cU = texture2D(uTex, clamp(uv + vec2(0.0, 0.004), 0.0, 1.0)).rgb;
                    float edge = length(col.rgb - cR) + length(col.rgb - cU);
                    col.rgb = mix(col.rgb * 0.45, vec3(0.13, 0.83, 0.93) * edge * 4.0 * uFxIntensity, 0.75);
                }

                // Chroma Key
                if (uChromaEnabled > 0.5) {
                    float d = distance(col.rgb, uKeyColor);
                    if (d < uChromaSim) {
                        col.rgb = vec3(0.05, 0.07, 0.11);
                    }
                }

                // Color Grading (Exposure, Contrast, Saturation, Warmth, Shadows/Highlights)
                col.rgb *= pow(2.0, uExposure);
                col.rgb = (col.rgb - 0.5) * uContrast + 0.5;
                float luma = dot(col.rgb, vec3(0.299, 0.587, 0.114));
                col.rgb = mix(vec3(luma), col.rgb, uSaturation);
                col.r += uWarmth * 0.18;
                col.b -= uWarmth * 0.18;
                col.rgb += (1.0 - luma) * uShadows * 0.25;
                col.rgb += luma * uHighlights * 0.25;

                // B&W / Cinema Grain
                if (uFxMode > 7.5 && uFxMode < 8.5) {
                    float gLuma = dot(col.rgb, vec3(0.299, 0.587, 0.114));
                    col.rgb = mix(col.rgb, vec3(gLuma), 0.65 * uFxIntensity);
                }

                // VHS Scanlines & FX Texture Grain
                if (uFxMode > 1.5 && uFxMode < 2.5) {
                    float scan = sin(vScreenUv.y * 240.0) * 0.08 * uFxIntensity;
                    col.rgb -= scan;
                }
                if (uFxMode > 0.5 && uFxTexture > 0.05) {
                    float grain = (rand2(vScreenUv + fract(uTime)) - 0.5) * 0.18 * uFxTexture;
                    col.rgb += grain;
                }

                // FX Color Shift
                if (uFxMode > 0.5 && abs(uFxColorShift) > 0.04) {
                    vec3 tint = uFxColorShift > 0.0 ? vec3(1.0, 0.45, 0.15) : vec3(0.15, 0.85, 1.0);
                    col.rgb = mix(col.rgb, tint * max(luma, 0.2), abs(uFxColorShift) * 0.35);
                }

                // Water blue tint on lower reflection
                if (uWaterMode > 0.5 && vScreenUv.y < 0.38) {
                    col.rgb = mix(col.rgb, vec3(0.12, 0.68, 0.85), 0.28);
                }

                // Vignette
                if (uVignette > 0.01) {
                    float dist = distance(vScreenUv, vec2(0.5, 0.5));
                    col.rgb *= smoothstep(0.95, 0.35 - uVignette * 0.2, dist);
                }

                gl_FragColor = vec4(clamp(col.rgb, 0.0, 1.0), 1.0);
            }
        """
    }
}
