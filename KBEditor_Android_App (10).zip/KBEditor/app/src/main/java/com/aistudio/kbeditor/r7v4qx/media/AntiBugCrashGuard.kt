package com.aistudio.kbeditor.r7v4qx.media

import android.content.Context
import android.os.Looper
import android.util.Log
import com.aistudio.kbeditor.r7v4qx.model.KbEditorProject
import java.io.File

/**
 * Runtime Anti-Bug & Self-Healing Guard:
 * 1. Catches background-thread uncaught exceptions without crashing the UI.
 * 2. Logs any fatal main-thread exception cleanly to kb_last_crash.txt before delegating.
 * 3. Sanitizes project timelines (NaN, invalid trim ranges, out-of-bounds zoom/speed) automatically.
 */
object AntiBugCrashGuard {

    @Volatile
    private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val appCtx = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val logFile = File(appCtx.filesDir, "kb_last_crash.txt")
                logFile.writeText("${thread.name}: ${throwable.stackTraceToString().take(3000)}")
            }
            Log.e("KBEditorGuard", "Intercepted uncaught error on ${thread.name}", throwable)
            if (thread.id != Looper.getMainLooper().thread.id) {
                // Absorb non-main-thread crashes so background AI/vision glitches never kill the editor
                return@setDefaultUncaughtExceptionHandler
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    private fun safeFloat(v: Float, fallback: Float, min: Float, max: Float): Float {
        return if (v.isNaN() || v.isInfinite()) fallback else v.coerceIn(min, max)
    }

    fun sanitizeProject(project: KbEditorProject): KbEditorProject {
        val cleanClips = project.videoClips.map { clip ->
            val start = clip.trimStartMs.coerceAtLeast(0L)
            val srcDur = clip.sourceDurationMs.coerceAtLeast(300L)
            val end = clip.trimEndMs.coerceAtLeast(start + 300L)
            clip.copy(
                sourceDurationMs = srcDur,
                trimStartMs = start,
                trimEndMs = end,
                speedMultiplier = safeFloat(clip.speedMultiplier, 1f, 0.25f, 4f),
                zoomScale = safeFloat(clip.zoomScale, 1f, 0.25f, 4f),
                panX = safeFloat(clip.panX, 0f, -1500f, 1500f),
                panY = safeFloat(clip.panY, 0f, -1500f, 1500f),
                rotationDeg = safeFloat(clip.rotationDeg, 0f, -3600f, 3600f),
                maskScale = safeFloat(clip.maskScale, 0.85f, 0.25f, 1.4f),
                maskOffsetX = safeFloat(clip.maskOffsetX, 0f, -0.45f, 0.45f),
                maskOffsetY = safeFloat(clip.maskOffsetY, 0f, -0.45f, 0.45f),
                videoFxIntensity = safeFloat(clip.videoFxIntensity, 1f, 0.1f, 2f),
                videoFxSpeed = safeFloat(clip.videoFxSpeed, 1f, 0.25f, 3f),
                animIntensity = safeFloat(clip.animIntensity, 1f, 0.2f, 2f),
                animSpeed = safeFloat(clip.animSpeed, 1f, 0.25f, 3f)
            )
        }
        return project.copy(videoClips = cleanClips)
    }
}
