package com.aistudio.kbeditor.r7v4qx.audio

import android.content.Context
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

class VoiceoverTtsEngine(private val context: Context) {

    suspend fun synthesizeVoiceover(
        scriptText: String,
        languageTag: String = "en-US",
        pitch: Float = 1.0f,
        speechRate: Float = 1.0f
    ): Result<Pair<String, Long>> = suspendCancellableCoroutine { cont ->
        if (scriptText.isBlank()) {
            cont.resume(Result.failure(IllegalArgumentException("Voiceover script cannot be empty")))
            return@suspendCancellableCoroutine
        }

        var tts: TextToSpeech? = null
        val outFile = File(context.cacheDir, "kb_vo_${System.currentTimeMillis()}.wav")
        val utteranceId = "vo_${System.currentTimeMillis()}"

        tts = TextToSpeech(context) { status ->
            if (status != TextToSpeech.SUCCESS) {
                if (cont.isActive) cont.resume(Result.failure(IllegalStateException("TTS initialization failed")))
                tts?.shutdown()
                return@TextToSpeech
            }
            val desired = Locale.forLanguageTag(languageTag)
            val res = tts?.setLanguage(desired) ?: TextToSpeech.LANG_NOT_SUPPORTED
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                val hiRes = tts?.setLanguage(Locale("hi", "IN")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (hiRes == TextToSpeech.LANG_MISSING_DATA || hiRes == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale("en", "IN"))
                }
            }
            tts?.setPitch(pitch.coerceIn(0.5f, 1.8f))
            tts?.setSpeechRate(speechRate.coerceIn(0.6f, 1.6f))
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) = Unit
                override fun onDone(id: String?) {
                    val estDurationMs = (scriptText.split(Regex("\\s+")).size * 420L).coerceAtLeast(1500L)
                    if (cont.isActive) {
                        cont.resume(Result.success(Uri.fromFile(outFile).toString() to estDurationMs))
                    }
                    tts?.shutdown()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    if (cont.isActive) cont.resume(Result.failure(IllegalStateException("TTS synthesis failed")))
                    tts?.shutdown()
                }
            })
            tts?.synthesizeToFile(scriptText, null, outFile, utteranceId)
        }

        cont.invokeOnCancellation {
            tts?.stop()
            tts?.shutdown()
        }
    }

    suspend fun synthesizeElevenLabsVoice(
        scriptText: String,
        apiKey: String,
        voiceId: String
    ): Result<Pair<String, Long>> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanKey = apiKey.trim()
            val cleanVoice = voiceId.trim()
            require(cleanKey.isNotBlank() && cleanVoice.isNotBlank()) {
                "Enter both ElevenLabs API Key and Voice ID"
            }
            val url = URL("https://api.elevenlabs.io/v1/text-to-speech/$cleanVoice")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 20000
                doOutput = true
                setRequestProperty("xi-api-key", cleanKey)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "audio/mpeg")
            }
            val payload = JSONObject().apply {
                put("text", scriptText)
                put("model_id", "eleven_multilingual_v2")
            }.toString()
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) {
                error("ElevenLabs HTTP ${conn.responseCode}")
            }
            val outFile = File(context.cacheDir, "kb_clone_${System.currentTimeMillis()}.mp3")
            conn.inputStream.use { input ->
                FileOutputStream(outFile).use { output -> input.copyTo(output) }
            }
            val estDur = (scriptText.split(Regex("\\s+")).size * 420L).coerceAtLeast(1500L)
            Uri.fromFile(outFile).toString() to estDur
        }
    }

}
