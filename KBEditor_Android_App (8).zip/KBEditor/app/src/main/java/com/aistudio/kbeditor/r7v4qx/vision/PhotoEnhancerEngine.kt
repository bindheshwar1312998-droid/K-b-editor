package com.aistudio.kbeditor.r7v4qx.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class PhotoEnhancerEngine(private val context: Context) {

    suspend fun enhancePhotoToFile(
        sourceUri: String,
        sharpness: Float = 0.45f,
        clarityBoost: Float = 1.15f
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val raw = context.contentResolver.openInputStream(Uri.parse(sourceUri))?.use {
                BitmapFactory.decodeStream(it)
            } ?: error("Could not decode photo")

            // Upscale up to 1440px width for crisp HD/2K output without OOM
            val targetW = (raw.width * 1.5f).toInt().coerceIn(720, 1440)
            val targetH = (targetW * (raw.height.toFloat() / raw.width.coerceAtLeast(1))).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(raw, targetW, targetH, true)
            if (scaled !== raw) raw.recycle()

            val w = scaled.width
            val h = scaled.height
            val pixels = IntArray(w * h)
            val outPixels = IntArray(w * h)
            scaled.getPixels(pixels, 0, w, 0, 0, w, h)
            scaled.recycle()

            val k = sharpness.coerceIn(0f, 0.9f)
            for (y in 0 until h) {
                for (x in 0 until w) {
                    val idx = y * w + x
                    val c = pixels[idx]
                    var r = Color.red(c).toFloat()
                    var g = Color.green(c).toFloat()
                    var b = Color.blue(c).toFloat()

                    if (x in 1 until (w - 1) && y in 1 until (h - 1)) {
                        val up = pixels[(y - 1) * w + x]
                        val dn = pixels[(y + 1) * w + x]
                        val lf = pixels[y * w + (x - 1)]
                        val rt = pixels[y * w + (x + 1)]

                        val avgR = (Color.red(up) + Color.red(dn) + Color.red(lf) + Color.red(rt)) * 0.25f
                        val avgG = (Color.green(up) + Color.green(dn) + Color.green(lf) + Color.green(rt)) * 0.25f
                        val avgB = (Color.blue(up) + Color.blue(dn) + Color.blue(lf) + Color.blue(rt)) * 0.25f

                        r += (r - avgR) * k
                        g += (g - avgG) * k
                        b += (b - avgB) * k
                    }

                    // Subtle S-curve contrast & vibrance boost
                    r = ((r - 128f) * clarityBoost + 128f).coerceIn(0f, 255f)
                    g = ((g - 128f) * clarityBoost + 128f).coerceIn(0f, 255f)
                    b = ((b - 128f) * clarityBoost + 128f).coerceIn(0f, 255f)

                    outPixels[idx] = Color.rgb(r.toInt(), g.toInt(), b.toInt())
                }
            }

            val outBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            outBmp.setPixels(outPixels, 0, w, 0, 0, w, h)

            val outFile = File(context.cacheDir, "kb_enhanced_${System.currentTimeMillis()}.png")
            FileOutputStream(outFile).use { fos ->
                outBmp.compress(Bitmap.CompressFormat.PNG, 95, fos)
            }
            outBmp.recycle()
            Uri.fromFile(outFile).toString()
        }
    }
}
