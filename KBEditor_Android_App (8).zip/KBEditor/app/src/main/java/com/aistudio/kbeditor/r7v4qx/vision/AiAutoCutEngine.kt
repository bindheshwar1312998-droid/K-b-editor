package com.aistudio.kbeditor.r7v4qx.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

class AiAutoCutEngine {

    private val segmenter by lazy {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
            .build()
        Segmentation.getClient(options)
    }

    suspend fun segmentForeground(
        sourceBitmap: Bitmap,
        backdropColorHex: Long
    ): Bitmap? = withContext(Dispatchers.Default) {
        val inputImage = InputImage.fromBitmap(sourceBitmap, 0)
        val maskResult = suspendCancellableCoroutine<SegmentationMask?> { cont ->
            segmenter.process(inputImage)
                .addOnSuccessListener { mask ->
                    if (cont.isActive) cont.resume(mask)
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume(null)
                }
        } ?: return@withContext null

        val maskW = maskResult.width
        val maskH = maskResult.height
        val buffer = maskResult.buffer
        buffer.rewind()

        val scaled = if (sourceBitmap.width != maskW || sourceBitmap.height != maskH) {
            Bitmap.createScaledBitmap(sourceBitmap, maskW, maskH, true)
        } else {
            sourceBitmap
        }

        val pixels = IntArray(maskW * maskH)
        scaled.getPixels(pixels, 0, maskW, 0, 0, maskW, maskH)

        val bgColor = backdropColorHex.toInt()
        val bgR = Color.red(bgColor)
        val bgG = Color.green(bgColor)
        val bgB = Color.blue(bgColor)

        for (i in pixels.indices) {
            val confidence = buffer.float.coerceIn(0f, 1f)
            if (confidence < 0.85f) {
                val px = pixels[i]
                val fgR = Color.red(px)
                val fgG = Color.green(px)
                val fgB = Color.blue(px)
                val alpha = ((confidence - 0.35f) / 0.50f).coerceIn(0f, 1f)
                val r = (fgR * alpha + bgR * (1f - alpha)).toInt()
                val g = (fgG * alpha + bgG * (1f - alpha)).toInt()
                val b = (fgB * alpha + bgB * (1f - alpha)).toInt()
                pixels[i] = Color.argb(255, r, g, b)
            }
        }

        val out = Bitmap.createBitmap(maskW, maskH, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, maskW, 0, 0, maskW, maskH)
        if (scaled !== sourceBitmap) scaled.recycle()
        out
    }

    fun close() {
        runCatching { segmenter.close() }
    }
}
