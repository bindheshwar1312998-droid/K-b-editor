package com.aistudio.kbeditor.r7v4qx.ui

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import com.aistudio.kbeditor.r7v4qx.ai.GeminiStudioEngine
import com.aistudio.kbeditor.r7v4qx.ai.ViralExportKit
import com.aistudio.kbeditor.r7v4qx.audio.AudioBeatDetector
import com.aistudio.kbeditor.r7v4qx.audio.AudioExtractorEngine
import com.aistudio.kbeditor.r7v4qx.audio.CapCutSfxPreset
import com.aistudio.kbeditor.r7v4qx.audio.MicRecorderEngine
import com.aistudio.kbeditor.r7v4qx.audio.StudioSfxEngine
import com.aistudio.kbeditor.r7v4qx.audio.VoiceoverTtsEngine
import com.aistudio.kbeditor.r7v4qx.media.VideoExportEngine
import com.aistudio.kbeditor.r7v4qx.model.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import com.aistudio.kbeditor.r7v4qx.storage.AccountCoinManager
import com.aistudio.kbeditor.r7v4qx.storage.ProAccountState
import com.aistudio.kbeditor.r7v4qx.storage.ProjectStorage
import com.aistudio.kbeditor.r7v4qx.vision.PhotoEnhancerEngine
import com.aistudio.kbeditor.r7v4qx.vision.SmartVisionEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ActiveStudioSheet {
    NONE,
    COLOR_WHEELS,
    SPEED_RAMP,
    VFX_CHROMA_MASK,
    MOTION_TRACKER,
    PIP_OVERLAY,
    CAPTION_3D,
    AUDIO_PRO,
    AUDIO_DUBBING,
    AUTO_CREATOR,
    EXPORT_PRO,
    CANVAS_REFRAME,
    KEYFRAME_GRAPH,
    TRANSITION_FX,
    FACE_SWAP,
    STICKERS,
    ENHANCER,
    VOICE_CLONE,
    CLIP_EDIT,
    WATERMARK_REMOVER
}

data class StudioUiState(
    val project: KbEditorProject = KbEditorProject(),
    val playheadMs: Long = 0L,
    val isPlaying: Boolean = false,
    val selectedVideoIndex: Int = 0,
    val selectedPipId: String? = null,
    val selectedCaptionId: String? = null,
    val selectedAudioId: String? = null,
    val activeSheet: ActiveStudioSheet = ActiveStudioSheet.NONE,
    val aiDrawerExpanded: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isBusy: Boolean = false,
    val statusBanner: String? = null,
    val lastCorrectionReport: String? = null,
    val generatedVoiceScript: String = "",
    val isRecordingMic: Boolean = false,
    val isRecordingVoiceSample: Boolean = false,
    val matchedPitch: Float? = null,
    val matchedSpeed: Float? = null,
    val matchedLangTag: String? = null,
    val voiceProfileSummary: String? = null,
    val savedProjects: List<KbEditorProject> = emptyList(),
    val viralExportKit: ViralExportKit? = null,
    val exportProgress: Float? = null,
    val lastExportPath: String? = null,
    val account: ProAccountState = ProAccountState(),
    val showLoginDialog: Boolean = false
)

@UnstableApi
class KbEditorViewModel(application: Application) : AndroidViewModel(application) {

    private val storage = ProjectStorage(application)
    private val accountManager = AccountCoinManager(application)
    private val visionEngine = SmartVisionEngine(application)
    private val photoEnhancer = PhotoEnhancerEngine(application)
    private val audioExtractor = AudioExtractorEngine(application)
    private val beatDetector = AudioBeatDetector(application)
    private val ttsEngine = VoiceoverTtsEngine(application)
    private val sfxEngine = StudioSfxEngine(application)
    private val micRecorder = MicRecorderEngine(application)
    private val exportEngine = VideoExportEngine(application)
    private val geminiEngine = GeminiStudioEngine(application)

    private val _uiState = MutableStateFlow(
        accountManager.loadState().let { acc ->
            StudioUiState(
                project = storage.loadProject(),
                savedProjects = storage.loadAllProjects(),
                account = acc,
                showLoginDialog = !acc.isLoggedIn
            )
        }
    )
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private var playbackJob: Job? = null

    private fun updateProject(recordUndo: Boolean = true, transform: (KbEditorProject) -> KbEditorProject) {
        _uiState.update { state ->
            if (recordUndo) {
                storage.pushUndoSnapshot(state.project)
            }
            val next = transform(state.project)
            storage.saveProject(next)
            state.copy(
                project = next,
                savedProjects = storage.loadAllProjects(),
                canUndo = storage.canUndo(),
                canRedo = storage.canRedo()
            )
        }
    }

    fun undo() {
        val prev = storage.undo(_uiState.value.project) ?: return
        _uiState.update {
            it.copy(
                project = prev,
                canUndo = storage.canUndo(),
                canRedo = storage.canRedo(),
                statusBanner = "Undid last edit"
            )
        }
    }

    fun redo() {
        val next = storage.redo(_uiState.value.project) ?: return
        _uiState.update {
            it.copy(
                project = next,
                canUndo = storage.canUndo(),
                canRedo = storage.canRedo(),
                statusBanner = "Redid edit"
            )
        }
    }

    fun createNewDraftProject() {
        storage.clearHistory()
        val count = (_uiState.value.savedProjects.size + 1)
        val fresh = KbEditorProject(projectName = "KB Draft #$count")
        storage.saveProject(fresh)
        _uiState.update {
            it.copy(
                project = fresh,
                savedProjects = storage.loadAllProjects(),
                selectedVideoIndex = 0,
                playheadMs = 0L,
                viralExportKit = null,
                statusBanner = "Created ${fresh.projectName}"
            )
        }
    }

    fun openSavedProject(projectId: String) {
        val target = _uiState.value.savedProjects.firstOrNull { it.projectId == projectId } ?: return
        storage.clearHistory()
        storage.saveProject(target)
        _uiState.update {
            it.copy(
                project = target,
                selectedVideoIndex = 0,
                playheadMs = 0L,
                viralExportKit = null,
                statusBanner = "Opened '${target.projectName}'"
            )
        }
    }

    fun deleteSavedProject(projectId: String) {
        val nextList = storage.deleteProjectFromLibrary(projectId)
        val active = if (_uiState.value.project.projectId == projectId) nextList.first() else _uiState.value.project
        storage.saveProject(active)
        _uiState.update {
            it.copy(
                project = active,
                savedProjects = nextList,
                statusBanner = "Deleted draft project"
            )
        }
    }

    fun generateViralExportKit() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Generating AI Title, Hashtags & HD Thumbnail...") }
            val res = geminiEngine.generateViralExportKit(_uiState.value.project)
            res.onSuccess { kit ->
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        viralExportKit = kit,
                        statusBanner = "Viral Title, Hashtags & Thumbnail Ready!"
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "Viral kit failed") }
            }
        }
    }

    fun copyViralKitText(text: String) {
        val cb = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("KB Viral Kit", text))
        _uiState.update { it.copy(statusBanner = "Copied Title & Hashtags!") }
    }

    fun resetProject() {
        storage.clearHistory()
        val fresh = KbEditorProject()
        storage.saveProject(fresh)
        _uiState.update {
            StudioUiState(
                project = fresh,
                statusBanner = "Reset studio sequence"
            )
        }
    }

    fun togglePlayPause() {
        val currentlyPlaying = _uiState.value.isPlaying
        if (currentlyPlaying) {
            playbackJob?.cancel()
            _uiState.update { it.copy(isPlaying = false) }
        } else {
            _uiState.update { it.copy(isPlaying = true) }
            playbackJob = viewModelScope.launch {
                while (true) {
                    delay(33L)
                    _uiState.update { s ->
                        val total = s.project.totalDurationMs.coerceAtLeast(1000L)
                        val nextMs = s.playheadMs + 33L
                        s.copy(playheadMs = if (nextMs >= total) 0L else nextMs)
                    }
                }
            }
        }
    }

    fun seekTo(ms: Long) {
        _uiState.update {
            it.copy(playheadMs = ms.coerceIn(0L, it.project.totalDurationMs))
        }
    }

    fun stepFrames(frameDelta: Int) {
        val frameMs = (1000L / _uiState.value.project.exportSettings.fps.value.coerceAtLeast(24))
        seekTo(_uiState.value.playheadMs + frameDelta * frameMs)
    }

    fun stepSeconds(secDelta: Int) {
        seekTo(_uiState.value.playheadMs + secDelta * 1000L)
    }

    fun selectVideoClip(index: Int) {
        _uiState.update { it.copy(selectedVideoIndex = index.coerceIn(0, (it.project.videoClips.size - 1).coerceAtLeast(0))) }
    }

    fun openSheet(sheet: ActiveStudioSheet) {
        _uiState.update { it.copy(activeSheet = sheet) }
    }

    fun toggleAiDrawer(expanded: Boolean? = null) {
        _uiState.update { it.copy(aiDrawerExpanded = expanded ?: !it.aiDrawerExpanded) }
    }

    fun toggleSafeZone() {
        updateProject(recordUndo = false) { it.copy(safeZoneVisible = !it.safeZoneVisible) }
    }

    fun cycleAspectRatio() {
        val all = AspectRatioPreset.entries
        val current = _uiState.value.project.aspectRatio
        val next = all[(all.indexOf(current) + 1) % all.size]
        updateProject { it.copy(aspectRatio = next) }
    }

    fun updateCanvasSettings(
        ratio: AspectRatioPreset = _uiState.value.project.aspectRatio,
        fillMode: CanvasFillMode = _uiState.value.project.canvasFillMode,
        blurRadius: Float = _uiState.value.project.canvasBlurRadius
    ) {
        updateProject {
            it.copy(
                aspectRatio = ratio,
                canvasFillMode = fillMode,
                canvasBlurRadius = blurRadius
            )
        }
    }

    fun updateTrackState(transform: (TrackState) -> TrackState) {
        updateProject(recordUndo = false) { it.copy(tracks = transform(it.tracks)) }
    }

    fun createPhotoToVideoReel(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val app = getApplication<Application>()
        val transitions = listOf(
            TransitionType.CROSS_DISSOLVE,
            TransitionType.ZOOM_THROUGH,
            TransitionType.WHIP_PAN,
            TransitionType.FLASH_CUT
        )
        val photoClips = uris.mapIndexed { idx, uri ->
            runCatching {
                app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val name = queryDisplayName(uri) ?: "Photo ${idx + 1}"
            val zoomIn = idx % 2 == 0
            VideoClip(
                title = name,
                mediaUri = uri.toString(),
                isAiGeneratedBroll = true,
                sourceDurationMs = 2500L,
                trimStartMs = 0L,
                trimEndMs = 2500L,
                transitionOut = if (idx < uris.lastIndex) transitions[idx % transitions.size] else TransitionType.NONE,
                transitionDurationMs = 450L,
                videoFx = if (idx % 3 == 0) VideoFxPreset.ZOOM_PULSE else VideoFxPreset.NONE,
                colorGrade = ColorGradeSpec(
                    contrast = 1.14f,
                    saturation = 1.12f,
                    warmth = 0.06f,
                    vignette = 0.14f,
                    lutName = "iPhone Cinema"
                ),
                keyframes = listOf(
                    KeyframePoint(normalizedTime = 0f, scale = if (zoomIn) 1.0f else 1.15f),
                    KeyframePoint(normalizedTime = 1f, scale = if (zoomIn) 1.15f else 1.0f)
                )
            )
        }
        updateProject { proj ->
            proj.copy(
                videoClips = photoClips,
                tracks = proj.tracks.copy(v1Visible = true)
            )
        }
        _uiState.update {
            it.copy(
                selectedVideoIndex = 0,
                playheadMs = 0L,
                statusBanner = "Created Photo-to-Video Reel from ${photoClips.size} photos!"
            )
        }
    }

    fun importMultipleClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val app = getApplication<Application>()
        val added = uris.mapIndexed { idx, uri ->
            runCatching {
                app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val mime = app.contentResolver.getType(uri).orEmpty()
            val isImg = mime.startsWith("image/")
            val name = queryDisplayName(uri) ?: "Clip ${idx + 1}"
            val durMs = if (isImg) 3000L else queryMediaDurationMs(uri).coerceAtLeast(3000L)
            VideoClip(
                title = name,
                mediaUri = uri.toString(),
                isAiGeneratedBroll = isImg,
                sourceDurationMs = durMs,
                trimStartMs = 0L,
                trimEndMs = durMs
            )
        }
        updateProject { proj ->
            val base = proj.videoClips.filter { it.mediaUri.isNotBlank() }
            val nextClips = base + added
            proj.copy(videoClips = nextClips, tracks = proj.tracks.copy(v1Visible = true))
        }
        _uiState.update {
            it.copy(
                selectedVideoIndex = (_uiState.value.project.videoClips.size - 1).coerceAtLeast(0),
                statusBanner = "Added ${added.size} clip(s) to Timeline V1"
            )
        }
    }

    fun importVideoClip(uri: Uri, title: String = "Imported Clip") {
        val app = getApplication<Application>()
        runCatching {
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        val resolvedTitle = runCatching {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.substringBeforeLast('.') else null
            }
        }.getOrNull()?.takeIf { it.isNotBlank() } ?: title

        val realDurationMs = runCatching {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(app, uri)
            val dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            retriever.release()
            dur
        }.getOrNull()?.coerceAtLeast(1000L) ?: 8000L

        var newIndex = 0
        updateProject { proj ->
            val clip = VideoClip(
                title = resolvedTitle,
                mediaUri = uri.toString(),
                sourceDurationMs = realDurationMs,
                trimStartMs = 0L,
                trimEndMs = realDurationMs
            )
            val baseList = if (proj.videoClips.all { it.mediaUri.isBlank() }) emptyList() else proj.videoClips
            newIndex = baseList.size
            proj.copy(videoClips = baseList + clip)
        }
        _uiState.update {
            it.copy(
                selectedVideoIndex = newIndex,
                playheadMs = 0L,
                statusBanner = "Loaded '$resolvedTitle' (${realDurationMs / 1000}s) on V1"
            )
        }
    }

    fun importPipOverlay(uri: Uri?, opticalPreset: String? = null, blendMode: BlendModePreset = BlendModePreset.SCREEN) {
        if (uri != null) {
            runCatching {
                getApplication<Application>().contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
        updateProject { proj ->
            val pip = OverlayPipClip(
                title = opticalPreset ?: "PiP Media",
                mediaUri = uri?.toString() ?: "",
                opticalFxPreset = opticalPreset,
                startMs = _uiState.value.playheadMs,
                blendMode = blendMode
            )
            proj.copy(pipClips = proj.pipClips + pip)
        }
        _uiState.update { it.copy(statusBanner = "Added PiP overlay to O1") }
    }

    fun updateSelectedClip(transform: (VideoClip) -> VideoClip) {
        val idx = _uiState.value.selectedVideoIndex
        updateProject { proj ->
            if (idx !in proj.videoClips.indices) return@updateProject proj
            val updated = proj.videoClips.toMutableList()
            updated[idx] = transform(updated[idx])
            proj.copy(videoClips = updated)
        }
    }

    fun currentClipNormalizedTime(): Float {
        val clip = _uiState.value.project.videoClips.getOrNull(_uiState.value.selectedVideoIndex) ?: return 0f
        if (clip.activeDurationMs <= 0L) return 0f
        return ((_uiState.value.playheadMs % clip.activeDurationMs).toFloat() / clip.activeDurationMs).coerceIn(0f, 1f)
    }

    fun toggleKeyframeAtPlayhead() {
        val normT = currentClipNormalizedTime()
        var added = false
        updateSelectedClip { clip ->
            val existing = clip.keyframes.indexOfFirst { kotlin.math.abs(it.normalizedTime - normT) < 0.04f }
            val nextList = if (existing >= 0) {
                clip.keyframes.toMutableList().apply { removeAt(existing) }
            } else {
                added = true
                (clip.keyframes + KeyframePoint(normalizedTime = normT)).sortedBy { it.normalizedTime }
            }
            clip.copy(keyframes = nextList)
        }
        _uiState.update {
            it.copy(statusBanner = if (added) "Added Keyframe ◆ at ${(normT * 100).toInt()}%" else "Removed Keyframe ◆")
        }
    }

    fun updateKeyframeAtPlayhead(scale: Float, rotationDeg: Float, x: Float, y: Float, opacity: Float) {
        val normT = currentClipNormalizedTime()
        updateSelectedClip { clip ->
            val idx = clip.keyframes.indexOfFirst { kotlin.math.abs(it.normalizedTime - normT) < 0.05f }
            val pt = KeyframePoint(
                normalizedTime = normT,
                x = x,
                y = y,
                scale = scale,
                rotationDeg = rotationDeg,
                opacity = opacity
            )
            val nextList = if (idx >= 0) {
                clip.keyframes.toMutableList().apply { this[idx] = pt }
            } else {
                (clip.keyframes + pt).sortedBy { it.normalizedTime }
            }
            clip.copy(keyframes = nextList)
        }
    }

    fun clearAllKeyframes() {
        updateSelectedClip { it.copy(keyframes = emptyList()) }
        _uiState.update { it.copy(statusBanner = "Cleared clip keyframes") }
    }

    fun splitSelectedClipAtPlayhead() {
        val proj = _uiState.value.project
        if (proj.tracks.v1Locked) {
            _uiState.update { it.copy(statusBanner = "V1 track is locked") }
            return
        }
        val idx = _uiState.value.selectedVideoIndex
        if (idx !in proj.videoClips.indices) return
        val clip = proj.videoClips[idx]
        if (clip.activeDurationMs < 800L) return
        val normT = currentClipNormalizedTime().coerceIn(0.15f, 0.85f)
        val splitPoint = clip.trimStartMs + ((clip.trimEndMs - clip.trimStartMs) * normT).toLong()
        val first = clip.copy(title = "${clip.title} A", trimEndMs = splitPoint)
        val second = clip.copy(id = java.util.UUID.randomUUID().toString(), title = "${clip.title} B", trimStartMs = splitPoint)
        updateProject {
            val list = it.videoClips.toMutableList()
            list[idx] = first
            list.add(idx + 1, second)
            it.copy(videoClips = list)
        }
    }

    fun addStickerOverlay(stickerText: String) {
        val atMs = _uiState.value.playheadMs
        updateProject { proj ->
            proj.copy(
                pipClips = proj.pipClips + OverlayPipClip(
                    title = stickerText,
                    opticalFxPreset = "STICKER:$stickerText",
                    startMs = atMs,
                    durationMs = 3000L,
                    blendMode = BlendModePreset.NORMAL,
                    opacity = 1f,
                    posX = 0.5f,
                    posY = 0.35f,
                    scale = 0.6f
                ),
                tracks = proj.tracks.copy(o1Visible = true)
            )
        }
        _uiState.update { it.copy(statusBanner = "Added Sticker '$stickerText' at ${atMs}ms") }
    }

    fun duplicatePipClip(pipId: String) {
        updateProject { proj ->
            val src = proj.pipClips.firstOrNull { it.id == pipId } ?: return@updateProject proj
            val copy = src.copy(
                id = java.util.UUID.randomUUID().toString(),
                title = "${src.title} Copy",
                posX = (src.posX + 0.06f).coerceAtMost(0.9f),
                posY = (src.posY + 0.06f).coerceAtMost(0.9f)
            )
            proj.copy(pipClips = proj.pipClips + copy)
        }
        _uiState.update { it.copy(statusBanner = "Duplicated Overlay on Track O1") }
    }

    fun replacePipClip(pipId: String, uri: Uri) {
        val app = getApplication<Application>()
        runCatching {
            app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val name = queryDisplayName(uri) ?: "Replaced Overlay"
        updateProject { proj ->
            proj.copy(
                pipClips = proj.pipClips.map { p ->
                    if (p.id == pipId) p.copy(title = name, mediaUri = uri.toString(), opticalFxPreset = null) else p
                }
            )
        }
        _uiState.update { it.copy(statusBanner = "Replaced Overlay media with '$name'") }
    }

    fun deletePipClip(pipId: String) {
        updateProject { proj ->
            proj.copy(pipClips = proj.pipClips.filterNot { it.id == pipId })
        }
    }

    fun transformPipOverlay(pipId: String, zoomFactor: Float, panDxPx: Float, panDyPx: Float, rotDeg: Float) {
        updateProject(recordUndo = false) { proj ->
            proj.copy(
                pipClips = proj.pipClips.map { pip ->
                    if (pip.id == pipId) {
                        pip.copy(
                            posX = (pip.posX + panDxPx / 300f).coerceIn(0.08f, 0.92f),
                            posY = (pip.posY + panDyPx / 420f).coerceIn(0.08f, 0.92f),
                            scale = (pip.scale * zoomFactor).coerceIn(0.2f, 1.5f),
                            rotationDeg = (pip.rotationDeg + rotDeg) % 360f
                        )
                    } else pip
                }
            )
        }
    }

    fun movePipPosition(pipId: String, dxNorm: Float, dyNorm: Float) {
        updateProject(recordUndo = false) { proj ->
            proj.copy(
                pipClips = proj.pipClips.map { p ->
                    if (p.id == pipId) {
                        p.copy(
                            posX = (p.posX + dxNorm).coerceIn(0.1f, 0.9f),
                            posY = (p.posY + dyNorm).coerceIn(0.1f, 0.9f)
                        )
                    } else p
                }
            )
        }
    }

    fun freezeFrameAtPlayhead() {
        val proj = _uiState.value.project
        if (proj.tracks.v1Locked) return
        val idx = _uiState.value.selectedVideoIndex
        val clip = proj.videoClips.getOrNull(idx) ?: return
        if (clip.mediaUri.isBlank()) {
            _uiState.update { it.copy(statusBanner = "Import a video first to Freeze Frame") }
            return
        }
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Capturing Freeze Frame...") }
            val retriever = MediaMetadataRetriever()
            val outFile = java.io.File(getApplication<Application>().cacheDir, "freeze_${System.currentTimeMillis()}.png")
            val ok = try {
                retriever.setDataSource(getApplication<Application>(), Uri.parse(clip.mediaUri))
                val frame = retriever.getFrameAtTime(_uiState.value.playheadMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (frame != null) {
                    java.io.FileOutputStream(outFile).use { fos ->
                        frame.compress(android.graphics.Bitmap.CompressFormat.PNG, 95, fos)
                    }
                    frame.recycle()
                    true
                } else false
            } catch (_: Exception) {
                false
            } finally {
                runCatching { retriever.release() }
            }
            if (ok) {
                val freezeClip = VideoClip(
                    title = "Freeze 2.5s",
                    mediaUri = Uri.fromFile(outFile).toString(),
                    isAiGeneratedBroll = true,
                    sourceDurationMs = 2500L,
                    trimStartMs = 0L,
                    trimEndMs = 2500L
                )
                updateProject { p ->
                    val mutable = p.videoClips.toMutableList()
                    mutable.add((idx + 1).coerceAtMost(mutable.size), freezeClip)
                    p.copy(videoClips = mutable)
                }
                _uiState.update { it.copy(isBusy = false, statusBanner = "Inserted 2.5s Freeze Frame on V1") }
            } else {
                _uiState.update { it.copy(isBusy = false, statusBanner = "Could not capture frame for Freeze") }
            }
        }
    }

    fun moveSelectedClipToOverlay(blendMode: BlendModePreset = BlendModePreset.NORMAL) {
        val proj = _uiState.value.project
        val idx = _uiState.value.selectedVideoIndex
        val clip = proj.videoClips.getOrNull(idx) ?: return
        if (clip.mediaUri.isBlank()) {
            _uiState.update { it.copy(statusBanner = "Import a clip first to move to Overlay") }
            return
        }
        val atMs = _uiState.value.playheadMs
        val pip = OverlayPipClip(
            title = "Overlay: ${clip.title}",
            mediaUri = clip.mediaUri,
            startMs = atMs,
            durationMs = clip.activeDurationMs.coerceAtLeast(1500L),
            blendMode = blendMode,
            opacity = 0.95f,
            posX = 0.5f,
            posY = 0.5f,
            scale = 0.55f
        )
        updateProject { p ->
            val remaining = if (p.videoClips.size > 1) {
                p.videoClips.filterIndexed { i, _ -> i != idx }
            } else p.videoClips
            p.copy(
                videoClips = remaining,
                pipClips = p.pipClips + pip,
                tracks = p.tracks.copy(o1Visible = true)
            )
        }
        _uiState.update {
            it.copy(
                selectedVideoIndex = 0,
                statusBanner = "Moved '${clip.title}' to Overlay Track O1"
            )
        }
    }

    fun duplicateSelectedClip() {
        val idx = _uiState.value.selectedVideoIndex
        val clips = _uiState.value.project.videoClips
        if (idx !in clips.indices) return
        val copy = clips[idx].copy(id = java.util.UUID.randomUUID().toString(), title = "${clips[idx].title} Copy")
        updateProject { p ->
            val list = p.videoClips.toMutableList()
            list.add(idx + 1, copy)
            p.copy(videoClips = list)
        }
        _uiState.update { it.copy(selectedVideoIndex = idx + 1, statusBanner = "Duplicated clip") }
    }

    fun setFaceSwapSourcePhoto(uri: Uri) {
        val app = getApplication<Application>()
        runCatching {
            app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        updateSelectedClip {
            it.copy(faceSwap = it.faceSwap.copy(enabled = true, sourceFaceUri = uri.toString()))
        }
        _uiState.update { it.copy(statusBanner = "Face Swap photo locked with ML Kit tracking") }
    }

    fun moveWatermarkBox(dxNorm: Float, dyNorm: Float) {
        updateSelectedClip { clip ->
            val wm = clip.watermarkRemover
            clip.copy(
                watermarkRemover = wm.copy(
                    posX = (wm.posX + dxNorm).coerceIn(0.08f, 0.92f),
                    posY = (wm.posY + dyNorm).coerceIn(0.06f, 0.94f)
                )
            )
        }
    }

    fun transformSelectedClip(zoomFactor: Float, panDxPx: Float, panDyPx: Float) {
        val idx = _uiState.value.selectedVideoIndex
        updateProject(recordUndo = false) { proj ->
            proj.copy(
                videoClips = proj.videoClips.mapIndexed { i, clip ->
                    if (i == idx) {
                        clip.copy(
                            zoomScale = (clip.zoomScale * zoomFactor).coerceIn(0.5f, 4.0f),
                            panX = (clip.panX + panDxPx).coerceIn(-420f, 420f),
                            panY = (clip.panY + panDyPx).coerceIn(-620f, 620f)
                        )
                    } else clip
                }
            )
        }
    }

    fun resetClipTransform() {
        updateSelectedClip { clip ->
            clip.copy(zoomScale = 1f, panX = 0f, panY = 0f, rotationDeg = 0f)
        }
        _uiState.update { it.copy(statusBanner = "Reset Zoom & Pan to 1x") }
    }

    fun rotateSelectedClip90() {
        updateSelectedClip { clip ->
            clip.copy(rotationDeg = (clip.rotationDeg + 90f) % 360f)
        }
        _uiState.update { it.copy(statusBanner = "Rotated clip 90°") }
    }

    fun replaceSelectedClip(uri: Uri) {
        val app = getApplication<Application>()
        runCatching {
            app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val name = queryDisplayName(uri) ?: "Replaced Clip"
        val durMs = queryMediaDurationMs(uri).coerceAtLeast(3000L)
        updateSelectedClip { clip ->
            clip.copy(
                title = name,
                mediaUri = uri.toString(),
                isAiGeneratedBroll = false,
                sourceDurationMs = durMs,
                trimStartMs = 0L,
                trimEndMs = durMs
            )
        }
        _uiState.update { it.copy(statusBanner = "Replaced clip with '$name'") }
    }

    fun flipSelectedClip() {
        updateSelectedClip { it.copy(flipHorizontal = !it.flipHorizontal) }
        _uiState.update { it.copy(statusBanner = "Flipped clip horizontally") }
    }

    fun rippleDeleteSelectedClip() {
        val proj = _uiState.value.project
        if (proj.tracks.v1Locked || proj.videoClips.size <= 1) return
        val idx = _uiState.value.selectedVideoIndex
        updateProject { p ->
            p.copy(videoClips = p.videoClips.filterIndexed { i, _ -> i != idx })
        }
        _uiState.update { it.copy(selectedVideoIndex = 0, statusBanner = "Magnetic ripple deleted clip") }
    }

    fun moveSelectedClip(delta: Int) {
        val idx = _uiState.value.selectedVideoIndex
        val clips = _uiState.value.project.videoClips
        val target = idx + delta
        if (idx !in clips.indices || target !in clips.indices) return
        updateProject { p ->
            val mutable = p.videoClips.toMutableList()
            val item = mutable.removeAt(idx)
            mutable.add(target, item)
            p.copy(videoClips = mutable)
        }
        _uiState.update { it.copy(selectedVideoIndex = target) }
    }

    fun addOrUpdateCaption(
        text: String,
        anim: MotionAnimation3D,
        trackedToClipId: String? = null,
        stylePreset: CaptionStylePreset = CaptionStylePreset.VIRAL_HORMOZI,
        colorHex: Long = 0xFFF8FAFC,
        accentHex: Long = 0xFFF59E0B,
        fontSizeSp: Float = 22f,
        posY: Float = 0.8f,
        fontStyle: CaptionFontStyle = CaptionFontStyle.SANS_BOLD
    ) {
        updateProject { proj ->
            val cap = CaptionClip(
                text = text.ifBlank { "KB STUDIO" },
                startMs = _uiState.value.playheadMs,
                durationMs = 3000L,
                animation3D = anim,
                stylePreset = stylePreset,
                fontStyle = fontStyle,
                posY = posY,
                fontSizeSp = fontSizeSp,
                colorHex = colorHex,
                accentHex = accentHex,
                trackedToClipId = trackedToClipId
            )
            proj.copy(captionClips = proj.captionClips + cap)
        }
    }

    fun applyCaptionDesignToAll(
        stylePreset: CaptionStylePreset,
        anim: MotionAnimation3D,
        colorHex: Long,
        accentHex: Long,
        fontSizeSp: Float,
        posY: Float,
        fontStyle: CaptionFontStyle = CaptionFontStyle.SANS_BOLD
    ) {
        updateProject { proj ->
            proj.copy(
                captionClips = proj.captionClips.map {
                    it.copy(
                        stylePreset = stylePreset,
                        fontStyle = fontStyle,
                        animation3D = anim,
                        colorHex = colorHex,
                        accentHex = accentHex,
                        fontSizeSp = fontSizeSp,
                        posY = posY
                    )
                }
            )
        }
        _uiState.update { it.copy(statusBanner = "Updated design for all ${uiState.value.project.captionClips.size} captions") }
    }

    fun deleteCaption(captionId: String) {
        updateProject { proj ->
            proj.copy(captionClips = proj.captionClips.filterNot { it.id == captionId })
        }
    }

    fun clearAllCaptions() {
        updateProject { proj -> proj.copy(captionClips = emptyList()) }
        _uiState.update { it.copy(statusBanner = "Cleared all captions") }
    }

    fun runAutoCaptions(
        language: CaptionLanguage,
        stylePreset: CaptionStylePreset,
        colorHex: Long,
        accentHex: Long,
        fontSizeSp: Float,
        posY: Float,
        customLanguageName: String = ""
    ) {
        if (!trySpendProCoins(5)) return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Generating ${language.label} Auto-Captions...") }
            val res = geminiEngine.generateAutoCaptions(
                project = _uiState.value.project,
                language = language,
                style = stylePreset,
                colorHex = colorHex,
                accentHex = accentHex,
                fontSizeSp = fontSizeSp,
                posY = posY,
                customLanguageName = customLanguageName
            )
            res.onSuccess { caps ->
                updateProject { proj ->
                    proj.copy(
                        captionClips = caps,
                        tracks = proj.tracks.copy(t1Visible = true)
                    )
                }
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        statusBanner = "Generated ${caps.size} ${language.label} captions (${stylePreset.label})"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        statusBanner = err.message ?: "Auto-Caption failed"
                    )
                }
            }
        }
    }

    fun applyHomeTemplate(templateId: String) {
        updateProject { proj ->
            val clips = proj.videoClips.mapIndexed { idx, clip ->
                when (templateId) {
                    "REELS_BEAT" -> clip.copy(
                        speedRamp = SpeedRampPreset.HERO_DIP,
                        videoFx = VideoFxPreset.ZOOM_PULSE,
                        transitionOut = if (idx < proj.videoClips.lastIndex) TransitionType.WHIP_PAN else TransitionType.NONE,
                        colorGrade = clip.colorGrade.copy(contrast = 1.18f, saturation = 1.18f, lutName = "Teal & Orange Pro")
                    )
                    "VLOG_FILM" -> clip.copy(
                        speedRamp = SpeedRampPreset.CONSTANT,
                        videoFx = VideoFxPreset.CINEMA_GRAIN,
                        transitionOut = if (idx < proj.videoClips.lastIndex) TransitionType.CROSS_DISSOLVE else TransitionType.NONE,
                        colorGrade = clip.colorGrade.copy(warmth = 0.16f, vignette = 0.25f, lutName = "Kodak 2383")
                    )
                    "PODCAST_PRO" -> clip.copy(
                        speedRamp = SpeedRampPreset.CONSTANT,
                        videoFx = VideoFxPreset.NONE,
                        colorGrade = clip.colorGrade.copy(contrast = 1.10f, beautyGlow = 0.18f, lutName = "Studio Crisp")
                    )
                    else -> clip.copy(
                        speedRamp = SpeedRampPreset.FLASH_IN,
                        videoFx = VideoFxPreset.CHROMATIC,
                        transitionOut = if (idx < proj.videoClips.lastIndex) TransitionType.FLASH_CUT else TransitionType.NONE,
                        colorGrade = clip.colorGrade.copy(contrast = 1.22f, saturation = 1.25f, lutName = "Cyber Neon")
                    )
                }
            }
            val audio = if (templateId == "PODCAST_PRO") {
                val base = proj.audioClips.ifEmpty { listOf(AudioClip(title = "Podcast Bus")) }
                base.map { it.copy(voiceEnhanceEnabled = true, noiseGateEnabled = true, windFilterEnabled = true) }
            } else proj.audioClips
            proj.copy(videoClips = clips, audioClips = audio)
        }
        _uiState.update { it.copy(statusBanner = "Applied Studio Template: $templateId") }
    }

    fun extractAudioFromSelectedClip() {
        val clip = _uiState.value.project.videoClips.getOrNull(_uiState.value.selectedVideoIndex) ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Extracting audio stream...") }
            val res = audioExtractor.extractAudioToM4a(clip.mediaUri, clip.title)
            res.onSuccess { (uriStr, durMs) ->
                updateProject { proj ->
                    proj.copy(
                        audioClips = proj.audioClips + AudioClip(
                            title = "${clip.title} Audio",
                            mediaUri = uriStr,
                            durationMs = durMs
                        )
                    )
                }
                _uiState.update { it.copy(isBusy = false, statusBanner = "Extracted audio to Track A1") }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "No embedded audio stream") }
            }
        }
    }

    fun updateAudioDsp(windFilter: Boolean, noiseGate: Boolean, voiceEnhance: Boolean, vocalMode: VocalIsolationMode) {
        updateProject { proj ->
            val list = if (proj.audioClips.isEmpty()) {
                listOf(
                    AudioClip(
                        title = "Master Audio Bus",
                        windFilterEnabled = windFilter,
                        noiseGateEnabled = noiseGate,
                        voiceEnhanceEnabled = voiceEnhance,
                        vocalMode = vocalMode
                    )
                )
            } else {
                proj.audioClips.map {
                    it.copy(
                        windFilterEnabled = windFilter,
                        noiseGateEnabled = noiseGate,
                        voiceEnhanceEnabled = voiceEnhance,
                        vocalMode = vocalMode
                    )
                }
            }
            proj.copy(audioClips = list)
        }
    }

    fun addCapCutSfx(preset: CapCutSfxPreset) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Adding SFX: ${preset.label}...") }
            val res = sfxEngine.generateSfxWav(preset)
            res.onSuccess { (uriStr, durMs) ->
                val atMs = _uiState.value.playheadMs
                updateProject { proj ->
                    proj.copy(
                        audioClips = proj.audioClips + AudioClip(
                            title = "SFX: ${preset.label}",
                            mediaUri = uriStr,
                            startMs = atMs,
                            durationMs = durMs
                        ),
                        tracks = proj.tracks.copy(a1Muted = false)
                    )
                }
                _uiState.update { it.copy(isBusy = false, statusBanner = "Added SFX '${preset.label}' at ${atMs}ms on A1") }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "SFX error") }
            }
        }
    }

    fun importOnlineAudioUrl(url: String) {
        val clean = url.trim()
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
            _uiState.update { it.copy(statusBanner = "Enter a valid https:// audio/SFX URL") }
            return
        }
        val atMs = _uiState.value.playheadMs
        updateProject { proj ->
            proj.copy(
                audioClips = proj.audioClips + AudioClip(
                    title = "Online: ${clean.substringAfterLast('/').take(18).ifBlank { "Audio" }}",
                    mediaUri = clean,
                    startMs = atMs,
                    durationMs = 6000L
                ),
                tracks = proj.tracks.copy(a1Muted = false)
            )
        }
        _uiState.update { it.copy(statusBanner = "Added Online Audio/SFX to Track A1") }
    }

    fun importLocalAudioUri(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        val name = queryDisplayName(uri) ?: "Music Track"
        val atMs = _uiState.value.playheadMs
        updateProject { proj ->
            proj.copy(
                audioClips = proj.audioClips + AudioClip(
                    title = name,
                    mediaUri = uri.toString(),
                    startMs = atMs,
                    durationMs = 8000L
                ),
                tracks = proj.tracks.copy(a1Muted = false)
            )
        }
        _uiState.update { it.copy(statusBanner = "Imported '$name' to Track A1") }
    }

    fun deleteAudioClip(audioId: String) {
        updateProject { proj ->
            proj.copy(audioClips = proj.audioClips.filterNot { it.id == audioId })
        }
    }

    fun transformCaption(captionId: String, zoomFactor: Float, panDxPx: Float, panDyPx: Float, rotDeg: Float) {
        updateProject(recordUndo = false) { proj ->
            proj.copy(
                captionClips = proj.captionClips.map { c ->
                    if (c.id == captionId) {
                        c.copy(
                            posX = (c.posX + panDxPx / 260f).coerceIn(0.08f, 0.92f),
                            posY = (c.posY + panDyPx / 360f).coerceIn(0.08f, 0.92f),
                            fontSizeSp = (c.fontSizeSp * zoomFactor).coerceIn(12f, 52f),
                            rotationDeg = (c.rotationDeg + rotDeg) % 360f
                        )
                    } else c
                }
            )
        }
    }

    fun moveCaptionPosition(captionId: String, dxNorm: Float, dyNorm: Float) {
        updateProject(recordUndo = false) { proj ->
            proj.copy(
                captionClips = proj.captionClips.map { c ->
                    if (c.id == captionId) {
                        c.copy(
                            posX = (c.posX + dxNorm).coerceIn(0.1f, 0.9f),
                            posY = (c.posY + dyNorm).coerceIn(0.1f, 0.92f)
                        )
                    } else c
                }
            )
        }
    }

    fun runAutoBeatCutAi() {
        val proj = _uiState.value.project
        val baseClips = proj.videoClips.filter { it.mediaUri.isNotBlank() }
        if (baseClips.isEmpty()) {
            _uiState.update { it.copy(statusBanner = "Import video/photo clips first for Auto Beat-Cut") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Detecting music beats & auto-cutting clips...") }
            val audioUri = proj.audioClips.firstOrNull { it.mediaUri.isNotBlank() }?.mediaUri ?: ""
            val totalDur = proj.totalDurationMs.coerceAtLeast(6000L)
            val beats = beatDetector.detectBeatTimestampsMs(audioUri, totalDur)
                .distinct()
                .sorted()
                .filter { it in 400L..(totalDur - 400L) }
                .take(12)

            val cutPoints = (listOf(0L) + beats + listOf(totalDur)).distinct().sorted()
            val transitions = listOf(TransitionType.FLASH_CUT, TransitionType.WHIP_PAN, TransitionType.ZOOM_THROUGH)
            val newClips = mutableListOf<VideoClip>()

            for (i in 0 until cutPoints.lastIndex) {
                val segDur = (cutPoints[i + 1] - cutPoints[i]).coerceAtLeast(450L)
                val src = baseClips[i % baseClips.size]
                val maxStart = (src.sourceDurationMs - segDur).coerceAtLeast(0L)
                val start = ((i * 700L) % (maxStart + 1L)).coerceAtLeast(0L)
                val end = (start + segDur).coerceAtMost(src.sourceDurationMs.coerceAtLeast(start + 450L))
                newClips.add(
                    src.copy(
                        id = java.util.UUID.randomUUID().toString(),
                        title = "Beat ${i + 1}",
                        trimStartMs = start,
                        trimEndMs = end,
                        videoFx = if (i % 2 == 0) VideoFxPreset.ZOOM_PULSE else VideoFxPreset.ACTION_FLASH,
                        transitionOut = if (i < cutPoints.lastIndex - 1) transitions[i % transitions.size] else TransitionType.NONE,
                        transitionDurationMs = 250L
                    )
                )
            }

            updateProject { p ->
                val updatedAudio = if (p.audioClips.isEmpty()) {
                    listOf(AudioClip(title = "Beat Sync Track", beatMarkersMs = beats))
                } else {
                    p.audioClips.mapIndexed { idx, a -> if (idx == 0) a.copy(beatMarkersMs = beats) else a }
                }
                p.copy(videoClips = newClips, audioClips = updatedAudio)
            }
            _uiState.update {
                it.copy(
                    isBusy = false,
                    selectedVideoIndex = 0,
                    playheadMs = 0L,
                    statusBanner = "Auto Beat-Cut AI: Synced ${newClips.size} cuts to music beats!"
                )
            }
        }
    }

    fun detectBeatsOnAudio() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Analyzing audio beats...") }
            val audioUri = _uiState.value.project.audioClips.firstOrNull()?.mediaUri ?: ""
            val beats = beatDetector.detectBeatTimestampsMs(audioUri, _uiState.value.project.totalDurationMs)
            updateProject { proj ->
                val clips = if (proj.audioClips.isEmpty()) {
                    listOf(AudioClip(title = "Beat Track", beatMarkersMs = beats))
                } else {
                    proj.audioClips.mapIndexed { idx, c -> if (idx == 0) c.copy(beatMarkersMs = beats) else c }
                }
                proj.copy(audioClips = clips)
            }
            _uiState.update { it.copy(isBusy = false, statusBanner = "Synced ${beats.size} beat markers on A1") }
        }
    }

    fun runAutoDubbing(
        targetLanguage: CaptionLanguage,
        muteOriginalVideo: Boolean,
        alsoAddCaptions: Boolean,
        customLanguageName: String = ""
    ) {
        if (!trySpendProCoins(5)) return
        val langTitle = customLanguageName.trim().ifBlank { targetLanguage.label }
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Translating & Dubbing into $langTitle...") }
            val capRes = geminiEngine.generateAutoCaptions(
                project = _uiState.value.project,
                language = targetLanguage,
                style = CaptionStylePreset.CINEMA_SUB,
                colorHex = 0xFFF8FAFC,
                accentHex = 0xFFF59E0B,
                fontSizeSp = 20f,
                posY = 0.82f,
                customLanguageName = customLanguageName
            )
            val segments = capRes.getOrNull()
            if (segments.isNullOrEmpty()) {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        statusBanner = capRes.exceptionOrNull()?.message ?: "Could not extract speech for dubbing"
                    )
                }
                return@launch
            }
            val fullScript = segments.joinToString(". ") { it.text.trim() }
            val ttsTag = when (targetLanguage.code) {
                "hi", "bho", "bgc", "raj", "mwr", "awa", "hne", "gbm", "mag", "mai", "sa" -> "hi-IN"
                "en", "hi-Latn" -> "en-US"
                "pa" -> "pa-IN"
                "ta" -> "ta-IN"
                "te" -> "te-IN"
                "mr" -> "mr-IN"
                "bn" -> "bn-IN"
                "gu" -> "gu-IN"
                "kn" -> "kn-IN"
                "ml" -> "ml-IN"
                "ur" -> "ur-PK"
                "es" -> "es-ES"
                "fr" -> "fr-FR"
                "de" -> "de-DE"
                "ja" -> "ja-JP"
                "ko" -> "ko-KR"
                "zh" -> "zh-CN"
                "ar" -> "ar-SA"
                else -> targetLanguage.code
            }
            val ttsRes = ttsEngine.synthesizeVoiceover(fullScript, ttsTag)
            ttsRes.onSuccess { (uriStr, durMs) ->
                updateProject { proj ->
                    val updatedVideos = if (muteOriginalVideo) {
                        proj.videoClips.mapIndexed { idx, c ->
                            if (idx == _uiState.value.selectedVideoIndex) c.copy(muted = true) else c
                        }
                    } else proj.videoClips
                    proj.copy(
                        videoClips = updatedVideos,
                        audioClips = proj.audioClips + AudioClip(
                            title = "Dub: $langTitle",
                            mediaUri = uriStr,
                            startMs = 0L,
                            durationMs = durMs,
                            isVoiceover = true,
                            voiceEnhanceEnabled = true
                        ),
                        captionClips = if (alsoAddCaptions) segments else proj.captionClips,
                        tracks = proj.tracks.copy(a1Muted = false, t1Visible = if (alsoAddCaptions) true else proj.tracks.t1Visible)
                    )
                }
                _uiState.update {
                    it.copy(isBusy = false, statusBanner = "Auto-Dubbed into $langTitle on Track A1")
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(isBusy = false, statusBanner = err.message ?: "Dubbing TTS failed")
                }
            }
        }
    }

    fun toggleVoiceSampleMatcher() {
        if (!_uiState.value.isRecordingVoiceSample) {
            val res = micRecorder.startRecording()
            res.onSuccess {
                _uiState.update {
                    it.copy(
                        isRecordingVoiceSample = true,
                        statusBanner = "Speak for 5 seconds... Tap Stop to Match Voice"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(statusBanner = err.message ?: "Mic permission required for Voice Matcher")
                }
            }
        } else {
            val res = micRecorder.stopRecording()
            res.onSuccess { (uriStr, _) ->
                viewModelScope.launch {
                    _uiState.update {
                        it.copy(
                            isRecordingVoiceSample = false,
                            isBusy = true,
                            statusBanner = "Analyzing your voice Pitch, Speed & Language..."
                        )
                    }
                    val matchRes = geminiEngine.analyzeVoiceSample(uriStr)
                    matchRes.onSuccess { m ->
                        _uiState.update {
                            it.copy(
                                isBusy = false,
                                matchedPitch = m.pitch,
                                matchedSpeed = m.speed,
                                matchedLangTag = m.languageTag,
                                voiceProfileSummary = m.summary,
                                statusBanner = "Voice Profile Saved: ${m.summary}"
                            )
                        }
                    }.onFailure { err ->
                        _uiState.update {
                            it.copy(isBusy = false, statusBanner = err.message ?: "Voice match failed")
                        }
                    }
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(isRecordingVoiceSample = false, statusBanner = err.message ?: "Sample failed")
                }
            }
        }
    }

    fun generateAiVoiceScript(topic: String, languageLabel: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Writing AI Voiceover Script...") }
            val res = geminiEngine.generateVoiceoverScript(topic, languageLabel)
            res.onSuccess { script ->
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        generatedVoiceScript = script,
                        statusBanner = "AI Script Ready!"
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "Script error") }
            }
        }
    }

    fun synthesizeProVoiceover(
        script: String,
        languageTag: String,
        pitch: Float,
        speechRate: Float,
        elevenApiKey: String,
        elevenVoiceId: String
    ) {
        if (script.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Generating AI Voiceover...") }
            val res = if (elevenApiKey.isNotBlank() && elevenVoiceId.isNotBlank()) {
                ttsEngine.synthesizeElevenLabsVoice(script, elevenApiKey, elevenVoiceId)
            } else {
                ttsEngine.synthesizeVoiceover(script, languageTag, pitch, speechRate)
            }
            res.onSuccess { (uriStr, durMs) ->
                val atMs = _uiState.value.playheadMs
                updateProject { proj ->
                    proj.copy(
                        audioClips = proj.audioClips + AudioClip(
                            title = if (elevenApiKey.isNotBlank()) "AI Clone VO" else "AI Voice (${languageTag})",
                            mediaUri = uriStr,
                            startMs = atMs,
                            durationMs = durMs,
                            isVoiceover = true,
                            voiceEnhanceEnabled = true
                        ),
                        tracks = proj.tracks.copy(a1Muted = false)
                    )
                }
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        statusBanner = "Added AI Voiceover to Track A1 at ${atMs}ms"
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "Voiceover failed") }
            }
        }
    }

    fun toggleMicRecording() {
        if (!_uiState.value.isRecordingMic) {
            val res = micRecorder.startRecording()
            res.onSuccess {
                _uiState.update {
                    it.copy(
                        isRecordingMic = true,
                        statusBanner = "Recording Mic Voiceover... Tap Stop when done"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(statusBanner = err.message ?: "Mic permission required to record")
                }
            }
        } else {
            val res = micRecorder.stopRecording()
            res.onSuccess { (uriStr, durMs) ->
                val atMs = _uiState.value.playheadMs
                updateProject { proj ->
                    proj.copy(
                        audioClips = proj.audioClips + AudioClip(
                            title = "Mic Voiceover",
                            mediaUri = uriStr,
                            startMs = atMs,
                            durationMs = durMs,
                            isVoiceover = true,
                            voiceEnhanceEnabled = true
                        ),
                        tracks = proj.tracks.copy(a1Muted = false)
                    )
                }
                _uiState.update {
                    it.copy(
                        isRecordingMic = false,
                        statusBanner = "Saved Mic Voiceover (${durMs / 1000}s) on Track A1"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(isRecordingMic = false, statusBanner = err.message ?: "Recording save failed")
                }
            }
        }
    }

    fun generateVoiceover(script: String, languageTag: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Synthesizing AI voiceover...") }
            val res = ttsEngine.synthesizeVoiceover(script, languageTag)
            res.onSuccess { (uriStr, durMs) ->
                updateProject { proj ->
                    proj.copy(
                        audioClips = proj.audioClips + AudioClip(
                            title = "VO ($languageTag)",
                            mediaUri = uriStr,
                            startMs = _uiState.value.playheadMs,
                            durationMs = durMs,
                            isVoiceover = true
                        )
                    )
                }
                _uiState.update { it.copy(isBusy = false, statusBanner = "Added AI Voiceover to A1") }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "TTS error") }
            }
        }
    }

    fun runMotionTracking(targetNormX: Float, targetNormY: Float) {
        val clip = _uiState.value.project.videoClips.getOrNull(_uiState.value.selectedVideoIndex) ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Tracking 2D motion across frames...") }
            val points = visionEngine.trackMotionAcrossClip(
                mediaUri = clip.mediaUri,
                startMs = clip.trimStartMs,
                endMs = clip.trimEndMs,
                targetNormX = targetNormX,
                targetNormY = targetNormY
            )
            updateSelectedClip { it.copy(motionTrackPoints = points) }
            _uiState.update { it.copy(isBusy = false, statusBanner = "Locked ${points.size} motion keyframes") }
        }
    }

    fun runSmartAutoReframe() {
        val clip = _uiState.value.project.videoClips.getOrNull(_uiState.value.selectedVideoIndex) ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Computing Smart Auto-Reframe...") }
            val offset = visionEngine.computeSmartReframeOffset(clip.mediaUri, clip.trimStartMs + 500L)
            updateSelectedClip { it.copy(reframeOffsetX = offset) }
            _uiState.update { it.copy(isBusy = false, statusBanner = "Smart Auto-Reframe applied (${(offset * 100).toInt()}%)") }
        }
    }

    fun openLoginDialog(show: Boolean) {
        _uiState.update { it.copy(showLoginDialog = show) }
    }

    fun loginProAccount(name: String, email: String) {
        val nextAcc = accountManager.login(name, email)
        _uiState.update {
            it.copy(
                account = nextAcc,
                showLoginDialog = false,
                statusBanner = "Welcome ${nextAcc.userName}! ${nextAcc.dailyCoins} Pro Coins credited today."
            )
        }
    }

    fun logoutProAccount() {
        val nextAcc = accountManager.logout()
        _uiState.update {
            it.copy(
                account = nextAcc,
                showLoginDialog = false,
                statusBanner = "Signed out of Pro Account"
            )
        }
    }

    private fun trySpendProCoins(cost: Int = 5): Boolean {
        val (ok, updatedAcc) = accountManager.spendCoins(cost)
        _uiState.update { it.copy(account = updatedAcc) }
        if (!ok) {
            _uiState.update {
                it.copy(
                    showLoginDialog = !updatedAcc.isLoggedIn,
                    statusBanner = if (!updatedAcc.isLoggedIn) {
                        "Login to claim 50 daily Pro Coins!"
                    } else {
                        "Daily 50 Coins used up — resets tomorrow!"
                    }
                )
            }
        }
        return ok
    }

    fun openFlowAiInBrowser(prompt: String) {
        if (!trySpendProCoins(5)) return
        val app = getApplication<Application>()
        val clipboard = app.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText("Flow AI Prompt", prompt))
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://labs.google/fx/tools/flow")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { app.startActivity(intent) }
        _uiState.update {
            it.copy(statusBanner = "Prompt copied! Opening Google Flow AI (-5 Coins)")
        }
    }

    fun runAiAutoCreator(prompt: String) {
        if (!trySpendProCoins(5)) return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Gemini 2.5 Flash analyzing sequence...") }
            val summary = geminiEngine.runAutoCreator(prompt, _uiState.value.project)
            updateProject { summary.updatedProject }
            _uiState.update { it.copy(isBusy = false, statusBanner = "${summary.message} (-5 Coins)") }
        }
    }

    fun enhancePhotoUri(uri: Uri? = null, sharpness: Float = 0.5f) {
        val targetUri = uri?.toString()
            ?: _uiState.value.project.videoClips.getOrNull(_uiState.value.selectedVideoIndex)?.mediaUri
        if (targetUri.isNullOrBlank()) {
            _uiState.update { it.copy(statusBanner = "Pick a photo to enhance") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Enhancing Photo Clarity & Upscaling...") }
            val res = photoEnhancer.enhancePhotoToFile(targetUri, sharpness = sharpness)
            res.onSuccess { enhancedUri ->
                if (uri != null) {
                    val clip = VideoClip(
                        title = "Enhanced Photo HD",
                        mediaUri = enhancedUri,
                        isAiGeneratedBroll = true,
                        sourceDurationMs = 3500L,
                        trimStartMs = 0L,
                        trimEndMs = 3500L
                    )
                    updateProject { proj ->
                        proj.copy(videoClips = proj.videoClips + clip)
                    }
                } else {
                    updateSelectedClip { it.copy(mediaUri = enhancedUri, isAiGeneratedBroll = true, title = "Enhanced HD") }
                }
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        statusBanner = "Photo Enhanced (HD Upscale + Unsharp Clarity)",
                        lastCorrectionReport = "Photo Enhanced: 1.5x HD Upscale + Unsharp Clarity + Contrast Boost"
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "Photo enhance failed") }
            }
        }
    }

    fun enhanceVideoPreset(level: String) {
        updateSelectedClip { clip ->
            when (level) {
                "4K_ULTRA" -> clip.copy(
                    colorGrade = clip.colorGrade.copy(
                        contrast = 1.22f,
                        saturation = 1.16f,
                        shadows = 0.14f,
                        highlights = -0.10f,
                        beautyGlow = 0.18f,
                        lutName = "4K Ultra Crisp"
                    )
                )
                "SKIN_RETOUCH" -> clip.copy(
                    colorGrade = clip.colorGrade.copy(
                        contrast = 1.10f,
                        saturation = 1.08f,
                        warmth = 0.08f,
                        beautySmooth = 0.45f,
                        beautyGlow = 0.35f,
                        lutName = "Skin Retouch Pro"
                    )
                )
                else -> clip.copy(
                    colorGrade = clip.colorGrade.copy(
                        contrast = 1.16f,
                        saturation = 1.12f,
                        shadows = 0.10f,
                        highlights = -0.06f,
                        lutName = "HD Crisp"
                    )
                )
            }
        }
        if (level == "4K_ULTRA") {
            updateProject(recordUndo = false) { p ->
                p.copy(exportSettings = p.exportSettings.copy(resolution = ExportResolution.UHD_4K))
            }
        }
        _uiState.update {
            it.copy(
                statusBanner = "Video Enhancer Applied: $level",
                lastCorrectionReport = "Video Enhanced ($level): Dynamic Range + Clarity + Crispness Boost"
            )
        }
    }

    fun enhanceVoiceOneTap(enable: Boolean) {
        updateAudioDsp(
            windFilter = enable,
            noiseGate = enable,
            voiceEnhance = enable,
            vocalMode = if (enable) VocalIsolationMode.ISOLATE_VOCALS else VocalIsolationMode.FULL_MIX
        )
        _uiState.update {
            it.copy(
                statusBanner = if (enable) "Voice Enhancer ON (Studio Mic + Noise Gate)" else "Voice Enhancer OFF",
                lastCorrectionReport = if (enable) "Voice Enhanced: Noise Gate + Wind Filter + Podcast Clarity EQ" else null
            )
        }
    }

    fun runAutoColorCorrection() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Analyzing exposure & white balance...") }
            val summary = geminiEngine.runAutoColorCorrection(_uiState.value.project, _uiState.value.selectedVideoIndex)
            updateProject { summary.updatedProject }
            _uiState.update {
                it.copy(
                    isBusy = false,
                    statusBanner = summary.message,
                    lastCorrectionReport = summary.message
                )
            }
        }
    }

    fun runAiColorGrade(stylePrompt: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Grading with Gemini LUT...") }
            val summary = geminiEngine.runAiColorGrade(stylePrompt, _uiState.value.project, _uiState.value.selectedVideoIndex)
            updateProject { summary.updatedProject }
            _uiState.update { it.copy(isBusy = false, statusBanner = summary.message, lastCorrectionReport = summary.message) }
        }
    }

    fun runAiCopilot(command: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "AI Copilot executing...") }
            val summary = geminiEngine.runAiCopilotCommand(command, _uiState.value.project, _uiState.value.selectedVideoIndex)
            updateProject { summary.updatedProject }
            _uiState.update { it.copy(isBusy = false, statusBanner = summary.message, lastCorrectionReport = summary.message) }
        }
    }

    fun generateAiBroll(prompt: String) {
        if (!trySpendProCoins(5)) return
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, statusBanner = "Generating AI B-Roll...") }
            val res = geminiEngine.generateAiBrollImage(prompt)
            res.onSuccess { combined ->
                val uriStr = combined.substringBefore("|")
                updateProject { proj ->
                    proj.copy(
                        videoClips = proj.videoClips + VideoClip(
                            title = "AI: ${prompt.take(14)}",
                            mediaUri = uriStr,
                            isAiGeneratedBroll = true,
                            sourceDurationMs = 4000L,
                            trimEndMs = 4000L
                        )
                    )
                }
                _uiState.update { it.copy(isBusy = false, statusBanner = "Inserted AI B-Roll onto V1") }
            }.onFailure { err ->
                _uiState.update { it.copy(isBusy = false, statusBanner = err.message ?: "B-Roll failed") }
            }
        }
    }

    fun updateExportSettings(settings: ExportSettings) {
        updateProject(recordUndo = false) { it.copy(exportSettings = settings) }
    }

    fun startExport() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, exportProgress = 0.05f, statusBanner = "Exporting zero-watermark master...") }
            val res = exportEngine.exportProject(_uiState.value.project) { progress ->
                _uiState.update { it.copy(exportProgress = progress) }
            }
            res.onSuccess { path ->
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        exportProgress = null,
                        lastExportPath = path,
                        statusBanner = "Saved to $path"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        exportProgress = null,
                        statusBanner = err.message ?: "Export failed"
                    )
                }
            }
        }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }
}
