package com.aistudio.kbeditor.r7v4qx

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.aistudio.kbeditor.r7v4qx.ui.KbEditorScreen
import com.aistudio.kbeditor.r7v4qx.ui.theme.KbEditorTheme
import com.aistudio.kbeditor.r7v4qx.ui.theme.SlateVoid

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KbEditorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SlateVoid
                ) {
                    KbEditorScreen()
                }
            }
        }
    }
}
