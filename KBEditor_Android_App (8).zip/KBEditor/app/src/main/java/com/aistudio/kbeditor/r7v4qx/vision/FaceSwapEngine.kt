package com.aistudio.kbeditor.r7v4qx.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

data class DetectedFaceBox(
    val normCenterX: Float,
    val normCenterY: Float,
    val normWidth: Float,
    val normHeight: Float,
    val headEulerZ: Float
)

class FaceSwapEngine(private val context: Context) {

    private val detector by lazy {
        val opts = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .build()
        FaceDetection.getClient(opts)
    }

    suspend fun detectPrimaryFace(bitmap: Bitmap): DetectedFaceBox? = withContext(Dispatchers.Default) {
        val image = InputImage.fromBitmap(bitmap, 0)
        val faces = suspendCancellableCoroutine { cont ->
            detector.process(image)
                .addOnSuccessListener { list ->
                    if (cont.isActive) cont.resume(list)
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume(emptyList())
                }
        }
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return@withContext null
        val box = face.boundingBox
        val w = bitmap.width.toFloat().coerceAtLeast(1f)
        val h = bitmap.height.toFloat().coerceAtLeast(1f)
        DetectedFaceBox(
            normCenterX = (box.exactCenterX() / w).coerceIn(0.1f, 0.9f),
            normCenterY = (box.exactCenterY() / h).coerceIn(0.1f, 0.9f),
            normWidth = (box.width() / w).coerceIn(0.12f, 0.85f),
            normHeight = (box.height() / h).coerceIn(0.12f, 0.85f),
            headEulerZ = face.headEulerAngleZ
        )
    }

    suspend fun prepareFeatheredFaceBitmap(faceUriStr: String): Bitmap? = withContext(Dispatchers.IO) {
        if (faceUriStr.isBlank()) return@withContext null
        val raw = runCatching {
            context.contentResolver.openInputStream(Uri.parse(faceUriStr))?.use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        }.getOrNull() ?: return@withContext null

        val faceBox = detectPrimaryFace(raw)
        val cropX: Int
        val cropY: Int
        val cropW: Int
        val cropH: Int
        if (faceBox != null) {
            cropW = (raw.width * faceBox.normWidth * 1.15f).toInt().coerceIn(48, raw.width)
            cropH = (raw.height * faceBox.normHeight * 1.2f).toInt().coerceIn(48, raw.height)
            cropX = ((raw.width * faceBox.normCenterX) - cropW / 2f).toInt().coerceIn(0, (raw.width - cropW).coerceAtLeast(0))
            cropY = ((raw.height * faceBox.normCenterY) - cropH / 2f).toInt().coerceIn(0, (raw.height - cropH).coerceAtLeast(0))
        } else {
            val side = minOf(raw.width, raw.height)
            cropX = (raw.width - side) / 2
            cropY = (raw.height - side) / 2
            cropW = side
            cropH = side
        }

        val cropped = Bitmap.createBitmap(raw, cropX, cropY, cropW, cropH)
        val outSize = 256
        val scaled = Bitmap.createScaledBitmap(cropped, outSize, outSize, true)
        if (cropped !== raw) cropped.recycle()
        raw.recycle()

        val result = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawBitmap(scaled, 0f, 0f, paint)
        scaled.recycle()

        // Smooth radial oval feather mask for seamless blending
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            shader = RadialGradient(
                outSize / 2f,
                outSize / 2f,
                outSize * 0.48f,
                intArrayOf(0xFFFFFFFF.toInt(), 0xEEFFFFFF.toInt(), 0x00FFFFFF),
                floatArrayOf(0f, 0.62f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, outSize.toFloat(), outSize.toFloat(), maskPaint)
        result
    }

    fun close() {
        runCatching { detector.close() }
    }
}
