#include <jni.h>
#include <android/bitmap.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#ifdef HAVE_RNNOISE
extern "C" {
#include "rnnoise.h"
}
#endif

namespace {

constexpr float kPi = 3.14159265358979323846f;

struct Biquad {
    float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f;
    float a1 = 0.0f, a2 = 0.0f;
    float x1 = 0.0f, x2 = 0.0f;
    float y1 = 0.0f, y2 = 0.0f;

    void reset() { x1 = x2 = y1 = y2 = 0.0f; }

    void configurePeaking(float sr, float freq, float q, float gainDb) {
        float a = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * kPi * std::min(freq, sr * 0.45f) / sr;
        float cosW0 = std::cos(w0);
        float alpha = std::sin(w0) / (2.0f * std::max(q, 0.2f));
        float a0 = 1.0f + alpha / a;
        b0 = (1.0f + alpha * a) / a0;
        b1 = (-2.0f * cosW0) / a0;
        b2 = (1.0f - alpha * a) / a0;
        a1 = (-2.0f * cosW0) / a0;
        a2 = (1.0f - alpha / a) / a0;
    }

    void configureHighPass(float sr, float freq, float q = 0.707f) {
        float w0 = 2.0f * kPi * std::min(freq, sr * 0.45f) / sr;
        float cosW0 = std::cos(w0);
        float alpha = std::sin(w0) / (2.0f * std::max(q, 0.2f));
        float a0 = 1.0f + alpha;
        b0 = ((1.0f + cosW0) * 0.5f) / a0;
        b1 = -(1.0f + cosW0) / a0;
        b2 = ((1.0f + cosW0) * 0.5f) / a0;
        a1 = (-2.0f * cosW0) / a0;
        a2 = (1.0f - alpha) / a0;
    }

    void configureHighShelf(float sr, float freq, float gainDb) {
        float a = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * kPi * std::min(freq, sr * 0.45f) / sr;
        float cosW0 = std::cos(w0);
        float sinW0 = std::sin(w0);
        float alpha = sinW0 * 0.5f * std::sqrt(2.0f);
        float twoSqrtAAlpha = 2.0f * std::sqrt(a) * alpha;
        float a0 = (a + 1.0f) - (a - 1.0f) * cosW0 + twoSqrtAAlpha;
        b0 = (a * ((a + 1.0f) + (a - 1.0f) * cosW0 + twoSqrtAAlpha)) / a0;
        b1 = (-2.0f * a * ((a - 1.0f) + (a + 1.0f) * cosW0)) / a0;
        b2 = (a * ((a + 1.0f) + (a - 1.0f) * cosW0 - twoSqrtAAlpha)) / a0;
        a1 = (2.0f * ((a - 1.0f) - (a + 1.0f) * cosW0)) / a0;
        a2 = ((a + 1.0f) - (a - 1.0f) * cosW0 - twoSqrtAAlpha) / a0;
    }

    inline float process(float x) {
        float y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
        x2 = x1; x1 = x;
        y2 = y1; y1 = y;
        return y;
    }
};

struct NativeDspState {
    float sampleRate = 48000.0f;
    float hpAlpha = 0.985f;
    float prevInL = 0.0f, prevOutL = 0.0f;
    float prevInR = 0.0f, prevOutR = 0.0f;

    float envL = 0.0f, envR = 0.0f;
    float noiseFloor = 0.008f;
    float gateGainL = 1.0f, gateGainR = 1.0f;
    int holdSamplesL = 0, holdSamplesR = 0;
    int holdDurationSamples = 8640;
    float attackCoeff = 0.12f;
    float releaseCoeff = 0.0005f;
    float gateSmoothUp = 0.03f;
    float gateSmoothDown = 0.0012f;

    float lpL = 0.0f, lpR = 0.0f;
    bool echoRemoval = false;
    float noiseStrength = 0.80f;
    float rnnVadL = 1.0f, rnnVadR = 1.0f;
    float postGateL = 1.0f, postGateR = 1.0f;
    float directEnvL = 0.0f, reverbEnvL = 0.0f;
    float directEnvR = 0.0f, reverbEnvR = 0.0f;
    float voicePeakL = 0.0f, voiceFastL = 0.0f, chatterGateL = 1.0f;
    float voicePeakDecay = 0.99992f, voiceFastAttack = 0.006f, voiceFastRelease = 0.0005f;

    Biquad hpRumbleL, hpRumbleR;
    Biquad mudCutL, mudCutR;
#ifdef HAVE_RNNOISE
    DenoiseState* rnnL = nullptr;
    DenoiseState* rnnR = nullptr;
    float rnnInL[480]{};
    float rnnOutL[480]{};
    float rnnInR[480]{};
    float rnnOutR[480]{};
    int rnnPos = 0;

    void ensureRnnoise() {
        if (!rnnL) rnnL = rnnoise_create(nullptr);
        if (!rnnR) rnnR = rnnoise_create(nullptr);
    }

    ~NativeDspState() {
        if (rnnL) { rnnoise_destroy(rnnL); rnnL = nullptr; }
        if (rnnR) { rnnoise_destroy(rnnR); rnnR = nullptr; }
    }
#endif
    Biquad presenceL, presenceR;
    Biquad airL, airR;

    float compEnv = 0.0f;
    float deEssPrevL = 0.0f, deEssPrevR = 0.0f;
    float compGain = 1.0f;
    int voiceEffectId = 0;
    float echoBuf[8000]{};
    int echoPos = 0;
    float robotPhase = 0.0f;
    float bassLpL = 0.0f, bassLpR = 0.0f;

    void configure(float sr) {
        sampleRate = std::max(sr, 8000.0f);
        float dt = 1.0f / sampleRate;
        float hpRc = 1.0f / (2.0f * kPi * 110.0f);
        hpAlpha = hpRc / (hpRc + dt);

        holdDurationSamples = std::max(1, static_cast<int>(sampleRate * 0.22f));
        attackCoeff = 1.0f - std::exp(-1.0f / (sampleRate * 0.004f));
        releaseCoeff = 1.0f - std::exp(-1.0f / (sampleRate * 0.090f));
        gateSmoothUp = 1.0f - std::exp(-1.0f / (sampleRate * 0.004f));
        gateSmoothDown = 1.0f - std::exp(-1.0f / (sampleRate * 0.065f));
        voicePeakDecay = std::exp(-1.0f / (sampleRate * 1.2f));
        voiceFastAttack = 1.0f - std::exp(-1.0f / (sampleRate * 0.008f));
        voiceFastRelease = 1.0f - std::exp(-1.0f / (sampleRate * 0.075f));

        hpRumbleL.configureHighPass(sampleRate, 180.0f, 0.707f);
        hpRumbleR.configureHighPass(sampleRate, 180.0f, 0.707f);
        mudCutL.configurePeaking(sampleRate, 285.0f, 1.2f, -4.2f);
        mudCutR.configurePeaking(sampleRate, 285.0f, 1.2f, -4.2f);
        presenceL.configurePeaking(sampleRate, 3100.0f, 1.1f, 4.8f);
        presenceR.configurePeaking(sampleRate, 3100.0f, 1.1f, 4.8f);
        airL.configureHighShelf(sampleRate, 8500.0f, 3.2f);
        airR.configureHighShelf(sampleRate, 8500.0f, 3.2f);
    }

    void flush() {
        prevInL = prevOutL = prevInR = prevOutR = 0.0f;
        lpL = lpR = envL = envR = 0.0f;
        directEnvL = 0.0f; reverbEnvL = 0.0f;
        directEnvR = 0.0f; reverbEnvR = 0.0f;
        noiseFloor = 0.008f;
        gateGainL = gateGainR = 1.0f;
        holdSamplesL = holdSamplesR = 0;
        rnnVadL = rnnVadR = 1.0f;
        postGateL = postGateR = 1.0f;
        voicePeakL = 0.0f; voiceFastL = 0.0f; chatterGateL = 1.0f;
        compEnv = 0.0f;
        compGain = 1.0f;
        echoPos = 0;
        robotPhase = 0.0f;
        bassLpL = bassLpR = 0.0f;
        std::memset(echoBuf, 0, sizeof(echoBuf));
#ifdef HAVE_RNNOISE
        rnnPos = 0;
        std::memset(rnnInL, 0, sizeof(rnnInL));
        std::memset(rnnOutL, 0, sizeof(rnnOutL));
        std::memset(rnnInR, 0, sizeof(rnnInR));
        std::memset(rnnOutR, 0, sizeof(rnnOutR));
#endif
        hpRumbleL.reset(); hpRumbleR.reset();
        mudCutL.reset(); mudCutR.reset();
        presenceL.reset(); presenceR.reset();
        airL.reset(); airR.reset();
    }

    static inline float softLimit(float x) {
        float ax = std::fabs(x);
        if (ax <= 0.85f) return x;
        float sign = (x >= 0.0f) ? 1.0f : -1.0f;
        return sign * (0.85f + 0.14f * std::tanh((ax - 0.85f) / 0.14f));
    }

    static inline int16_t toInt16(float x) {
        float clamped = std::max(-1.0f, std::min(1.0f, x));
        return static_cast<int16_t>(clamped * 32767.0f);
    }
};

} // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeIsRnnoiseActive(JNIEnv*, jobject) {
#ifdef HAVE_RNNOISE
    return JNI_TRUE;
#else
    return JNI_FALSE;
#endif
}

JNIEXPORT jlong JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeCreateDsp(JNIEnv*, jobject) {
    auto* state = new NativeDspState();
    state->configure(48000.0f);
    return reinterpret_cast<jlong>(state);
}

JNIEXPORT void JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeDestroyDsp(JNIEnv*, jobject, jlong ptr) {
    auto* state = reinterpret_cast<NativeDspState*>(ptr);
    delete state;
}

JNIEXPORT void JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeConfigureDsp(JNIEnv*, jobject, jlong ptr, jint sampleRate) {
    auto* state = reinterpret_cast<NativeDspState*>(ptr);
    if (state) state->configure(static_cast<float>(sampleRate));
}

JNIEXPORT void JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeSetEchoRemoval(JNIEnv*, jobject, jlong ptr, jboolean enabled) {
    auto* state = reinterpret_cast<NativeDspState*>(ptr);
    if (state) state->echoRemoval = (enabled == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeSetVoiceEffect(JNIEnv*, jobject, jlong ptr, jint effectId) {
    auto* state = reinterpret_cast<NativeDspState*>(ptr);
    if (state) state->voiceEffectId = effectId;
}

JNIEXPORT void JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeSetNoiseStrength(JNIEnv*, jobject, jlong ptr, jfloat strength) {
    auto* state = reinterpret_cast<NativeDspState*>(ptr);
    if (state) state->noiseStrength = std::max(0.0f, std::min(1.0f, strength));
}

JNIEXPORT void JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeFlushDsp(JNIEnv*, jobject, jlong ptr) {
    auto* state = reinterpret_cast<NativeDspState*>(ptr);
    if (state) state->flush();
}

JNIEXPORT void JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeProcessPcm16(
    JNIEnv* env, jobject, jlong ptr,
    jshortArray samplesArr, jint sampleCount, jint channels,
    jboolean windFilter, jboolean noiseGate, jboolean voiceEnhance, jint vocalMode
) {
    auto* state = reinterpret_cast<NativeDspState*>(ptr);
    if (!state || !samplesArr || sampleCount <= 0) return;

    jshort* samples = env->GetShortArrayElements(samplesArr, nullptr);
    if (!samples) return;

    if (channels >= 2) {
        int pairs = sampleCount / 2;
        for (int i = 0; i < pairs; ++i) {
            float l = samples[i * 2] / 32768.0f;
            float r = samples[i * 2 + 1] / 32768.0f;

            if (windFilter || noiseGate) {
                l = state->hpRumbleL.process(l);
                r = state->hpRumbleR.process(r);
            }

            if (noiseGate) {
#ifdef HAVE_RNNOISE
                state->ensureRnnoise();
                float dryL = l, dryR = r;
                float mid = (l + r) * 0.5f;
                float side = (l - r) * 0.5f;
                state->rnnInL[state->rnnPos] = mid * 32767.0f;
                float rnnOutMid = state->rnnOutL[state->rnnPos] / 32768.0f;
                state->rnnPos++;
                if (state->rnnPos >= 480) {
                    if (state->rnnL) state->rnnVadL = rnnoise_process_frame(state->rnnL, state->rnnOutL, state->rnnInL);
                    state->rnnPos = 0;
                }
                float str = state->noiseStrength;
                // Second-stage spectral soft-knee suppression on residual noise when strength is high
                float floorGain = 1.0f - 0.9985f * str;
                float speechActive = state->rnnVadL;
                if (speechActive >= 0.45f) {
                    state->holdSamplesL = state->holdDurationSamples;
                    state->postGateL += state->gateSmoothUp * (1.0f - state->postGateL);
                } else if (state->holdSamplesL > 0) {
                    state->holdSamplesL--;
                    state->postGateL += state->gateSmoothUp * (1.0f - state->postGateL);
                } else {
                    float rVad = speechActive / 0.45f;
                    float targetG = floorGain + (1.0f - floorGain) * (rVad * rVad);
                    state->postGateL += state->gateSmoothDown * (targetG - state->postGateL);
                }
                float hissAlpha = 0.05f + 0.95f * state->postGateL;
                state->lpL += hissAlpha * (rnnOutMid - state->lpL);
                float cleanMid = state->lpL * state->postGateL;
                float cleanSide = side * state->postGateL * (1.0f - 0.96f * str);
                float wetL = cleanMid + cleanSide;
                float wetR = cleanMid - cleanSide;
                l = dryL + str * (wetL - dryL);
                r = dryR + str * (wetR - dryR);
#else
                float absL = std::fabs(l);
                float absR = std::fabs(r);
                state->envL += ((absL > state->envL) ? state->attackCoeff : state->releaseCoeff) * (absL - state->envL);
                state->envR += ((absR > state->envR) ? state->attackCoeff : state->releaseCoeff) * (absR - state->envR);

                float frameEnv = std::max(state->envL, state->envR);
                if (frameEnv < state->noiseFloor) {
                    state->noiseFloor += 0.002f * (frameEnv - state->noiseFloor);
                } else {
                    state->noiseFloor += 0.00003f * (frameEnv - state->noiseFloor);
                }
                state->noiseFloor = std::max(0.002f, std::min(0.12f, state->noiseFloor));

                float openThresh = std::max(0.010f, std::min(0.18f, state->noiseFloor * 2.2f));
                float closeThresh = openThresh * 0.60f;

                if (state->envL >= openThresh) {
                    state->holdSamplesL = state->holdDurationSamples;
                    state->gateGainL += state->gateSmoothUp * (1.0f - state->gateGainL);
                } else if (state->holdSamplesL > 0) {
                    state->holdSamplesL--;
                    state->gateGainL += state->gateSmoothUp * (1.0f - state->gateGainL);
                } else if (state->envL < closeThresh) {
                    float ratio = std::max(0.0f, std::min(1.0f, state->envL / closeThresh));
                    float target = std::max(0.04f, std::min(1.0f, 0.04f + 0.96f * ratio * ratio));
                    state->gateGainL += state->gateSmoothDown * (target - state->gateGainL);
                }

                if (state->envR >= openThresh) {
                    state->holdSamplesR = state->holdDurationSamples;
                    state->gateGainR += state->gateSmoothUp * (1.0f - state->gateGainR);
                } else if (state->holdSamplesR > 0) {
                    state->holdSamplesR--;
                    state->gateGainR += state->gateSmoothUp * (1.0f - state->gateGainR);
                } else if (state->envR < closeThresh) {
                    float ratio = std::max(0.0f, std::min(1.0f, state->envR / closeThresh));
                    float target = std::max(0.04f, std::min(1.0f, 0.04f + 0.96f * ratio * ratio));
                    state->gateGainR += state->gateSmoothDown * (target - state->gateGainR);
                }

                l *= state->gateGainL;
                r *= state->gateGainR;

                float hissAlphaL = 0.14f + 0.80f * state->gateGainL;
                float hissAlphaR = 0.14f + 0.80f * state->gateGainR;
                state->lpL += hissAlphaL * (l - state->lpL);
                state->lpR += hissAlphaR * (r - state->lpR);
                l = state->lpL;
                r = state->lpR;
#endif
            }

            if (state->echoRemoval) {
                float al = std::fabs(l);
                float ar = std::fabs(r);
                state->directEnvL += ((al > state->directEnvL) ? 0.15f : 0.002f) * (al - state->directEnvL);
                state->reverbEnvL += ((al > state->reverbEnvL) ? 0.02f : 0.00025f) * (al - state->reverbEnvL);
                float tailRatioL = (state->reverbEnvL > state->directEnvL * 1.25f) ? (state->directEnvL / std::max(state->reverbEnvL, 0.001f)) : 1.0f;
                l *= std::max(0.28f, std::min(1.0f, tailRatioL));

                state->directEnvR += ((ar > state->directEnvR) ? 0.15f : 0.002f) * (ar - state->directEnvR);
                state->reverbEnvR += ((ar > state->reverbEnvR) ? 0.02f : 0.00025f) * (ar - state->reverbEnvR);
                float tailRatioR = (state->reverbEnvR > state->directEnvR * 1.25f) ? (state->directEnvR / std::max(state->reverbEnvR, 0.001f)) : 1.0f;
                r *= std::max(0.28f, std::min(1.0f, tailRatioR));
            }

            if (voiceEnhance) {
                // [1] Sub-bass rumble cut + Studio Mic proximity chest warmth (130 Hz)
                if (!windFilter) {
                    l = state->hpRumbleL.process(l);
                    r = state->hpRumbleR.process(r);
                }
                state->bassLpL += 0.017f * (l - state->bassLpL);
                state->bassLpR += 0.017f * (r - state->bassLpR);
                l += state->bassLpL * 0.28f;
                r += state->bassLpR * 0.28f;

                // [2] Built-in subtle room-reverb tail tightening for untreated rooms
                if (!state->echoRemoval) {
                    float al = std::fabs(l);
                    state->directEnvL += ((al > state->directEnvL) ? 0.15f : 0.002f) * (al - state->directEnvL);
                    state->reverbEnvL += ((al > state->reverbEnvL) ? 0.02f : 0.00025f) * (al - state->reverbEnvL);
                    if (state->reverbEnvL > state->directEnvL * 1.28f) {
                        l *= std::max(0.42f, std::min(1.0f, state->directEnvL / std::max(state->reverbEnvL, 0.001f)));
                    }
                    float ar = std::fabs(r);
                    state->directEnvR += ((ar > state->directEnvR) ? 0.15f : 0.002f) * (ar - state->directEnvR);
                    state->reverbEnvR += ((ar > state->reverbEnvR) ? 0.02f : 0.00025f) * (ar - state->reverbEnvR);
                    if (state->reverbEnvR > state->directEnvR * 1.28f) {
                        r *= std::max(0.42f, std::min(1.0f, state->directEnvR / std::max(state->reverbEnvR, 0.001f)));
                    }
                }

                // [3] Studio De-Esser + Broadcast EQ (Mud Cut + Presence + Silky Air)
                float sibL = l - state->deEssPrevL; state->deEssPrevL = l;
                if (std::fabs(sibL) > 0.13f) l -= sibL * 0.48f;
                float sibR = r - state->deEssPrevR; state->deEssPrevR = r;
                if (std::fabs(sibR) > 0.13f) r -= sibR * 0.48f;
                l = state->airL.process(state->presenceL.process(state->mudCutL.process(l)));
                r = state->airR.process(state->presenceR.process(state->mudCutR.process(r)));

                // [4] Broadcast 4:1 Compressor + Auto-Leveler Makeup Gain
                float peak = std::max(std::fabs(l), std::fabs(r));
                state->compEnv += ((peak > state->compEnv) ? state->attackCoeff : state->releaseCoeff) * (peak - state->compEnv);
                float targetComp = (state->compEnv > 0.24f)
                    ? (0.24f + (state->compEnv - 0.24f) / 4.0f) / state->compEnv
                    : 1.0f;
                state->compGain += 0.025f * (targetComp - state->compGain);

                float agcGainSt = std::max(1.0f, std::min(1.90f, 0.28f / std::max(state->compEnv, 0.08f)));
                float masterGainSt = state->compGain * (1.18f + 0.22f * agcGainSt);
                l = NativeDspState::softLimit(l * masterGainSt);
                r = NativeDspState::softLimit(r * masterGainSt);
            }

            if (noiseGate || vocalMode == 1) {
                float midNow = (l + r) * 0.5f;
                float absSp = std::fabs(midNow);
                state->voiceFastL += ((absSp > state->voiceFastL) ? state->voiceFastAttack : state->voiceFastRelease) * (absSp - state->voiceFastL);
                float cappedSp = std::min(absSp, 0.55f);
                if (cappedSp > state->voicePeakL && state->rnnVadL >= 0.40f) {
                    state->voicePeakL += 0.02f * (cappedSp - state->voicePeakL);
                } else {
                    state->voicePeakL *= state->voicePeakDecay;
                }
                if (vocalMode == 1 || state->noiseStrength >= 0.35f) {
                    float ratioThresh = (vocalMode == 1) ? 0.30f : (0.18f + 0.14f * state->noiseStrength);
                    float fgThresh = std::max(0.014f, state->voicePeakL * ratioThresh);
                    float targetC = 1.0f;
                    if (state->voiceFastL < fgThresh && state->rnnVadL < 0.70f) {
                        float r = std::max(0.0f, std::min(1.0f, state->voiceFastL / fgThresh));
                        float minFloor = (vocalMode == 1) ? 0.015f : (1.0f - 0.985f * state->noiseStrength);
                        targetC = minFloor + (1.0f - minFloor) * (r * r * r);
                    }
                    state->chatterGateL += ((targetC > state->chatterGateL) ? state->gateSmoothUp : state->gateSmoothDown) * (targetC - state->chatterGateL);
                    if (vocalMode == 1) {
                        float sideNow = (l - r) * 0.5f;
                        float isoMid = midNow * state->chatterGateL;
                        float isoSide = sideNow * state->chatterGateL * 0.15f;
                        l = isoMid + isoSide;
                        r = isoMid - isoSide;
                    } else {
                        l *= state->chatterGateL;
                        r *= state->chatterGateL;
                    }
                }
            }

            if (vocalMode == 1) {
                float mid = (l + r) * 0.5f * 1.18f;
                l = mid;
                r = mid;
            } else if (vocalMode == 2) {
                float side = (l - r) * 0.5f * 1.4f;
                l = side;
                r = -side;
            }

            if (state->voiceEffectId == 1) {
                state->bassLpL += 0.045f * (l - state->bassLpL);
                state->bassLpR += 0.045f * (r - state->bassLpR);
                l = NativeDspState::softLimit(l * 0.85f + state->bassLpL * 0.85f);
                r = NativeDspState::softLimit(r * 0.85f + state->bassLpR * 0.85f);
            } else if (state->voiceEffectId == 2) {
                l = NativeDspState::softLimit(state->presenceL.process(l) * 1.15f);
                r = NativeDspState::softLimit(state->presenceR.process(r) * 1.15f);
            } else if (state->voiceEffectId == 3) {
                float monoEcho = state->echoBuf[state->echoPos];
                float cur = (l + r) * 0.5f;
                state->echoBuf[state->echoPos] = cur + monoEcho * 0.42f;
                state->echoPos = (state->echoPos + 1) % 8000;
                l = NativeDspState::softLimit(l + monoEcho * 0.48f);
                r = NativeDspState::softLimit(r + monoEcho * 0.48f);
            } else if (state->voiceEffectId == 4) {
                state->robotPhase += 2.0f * kPi * 52.0f / state->sampleRate;
                if (state->robotPhase > 2.0f * kPi) state->robotPhase -= 2.0f * kPi;
                float mod = 0.55f + 0.45f * std::sin(state->robotPhase);
                l *= mod; r *= mod;
            } else if (state->voiceEffectId == 5) {
                l = NativeDspState::softLimit(state->airL.process(l) * 1.25f);
                r = NativeDspState::softLimit(state->airR.process(r) * 1.25f);
            }
            samples[i * 2] = NativeDspState::toInt16(l);
            samples[i * 2 + 1] = NativeDspState::toInt16(r);
        }
    } else {
        for (int i = 0; i < sampleCount; ++i) {
            float s = samples[i] / 32768.0f;
            if (windFilter || noiseGate) {
                s = state->hpRumbleL.process(s);
            }
            if (noiseGate) {
#ifdef HAVE_RNNOISE
                state->ensureRnnoise();
                float dryS = s;
                state->rnnInL[state->rnnPos] = s * 32767.0f;
                float rnnOutSample = state->rnnOutL[state->rnnPos] / 32768.0f;
                state->rnnPos++;
                if (state->rnnPos >= 480) {
                    if (state->rnnL) state->rnnVadL = rnnoise_process_frame(state->rnnL, state->rnnOutL, state->rnnInL);
                    state->rnnPos = 0;
                }
                float str = state->noiseStrength;
                float floorGain = 1.0f - 0.992f * str;
                if (state->rnnVadL >= 0.38f) {
                    state->holdSamplesL = state->holdDurationSamples;
                    state->postGateL += state->gateSmoothUp * (1.0f - state->postGateL);
                } else if (state->holdSamplesL > 0) {
                    state->holdSamplesL--;
                    state->postGateL += state->gateSmoothUp * (1.0f - state->postGateL);
                } else {
                    float targetG = floorGain + (1.0f - floorGain) * (state->rnnVadL / 0.38f);
                    state->postGateL += state->gateSmoothDown * (targetG - state->postGateL);
                }
                float hissAlpha = 0.09f + 0.91f * state->postGateL;
                state->lpL += hissAlpha * (rnnOutSample - state->lpL);
                float wetS = state->lpL * state->postGateL;
                s = dryS + str * (wetS - dryS);
#else
                float absS = std::fabs(s);
                state->envL += ((absS > state->envL) ? state->attackCoeff : state->releaseCoeff) * (absS - state->envL);
                if (state->envL < state->noiseFloor) {
                    state->noiseFloor += 0.002f * (state->envL - state->noiseFloor);
                } else {
                    state->noiseFloor += 0.00003f * (state->envL - state->noiseFloor);
                }
                state->noiseFloor = std::max(0.002f, std::min(0.12f, state->noiseFloor));
                float openThresh = std::max(0.010f, std::min(0.18f, state->noiseFloor * 2.2f));
                float closeThresh = openThresh * 0.60f;
                if (state->envL >= openThresh) {
                    state->holdSamplesL = state->holdDurationSamples;
                    state->gateGainL += state->gateSmoothUp * (1.0f - state->gateGainL);
                } else if (state->holdSamplesL > 0) {
                    state->holdSamplesL--;
                    state->gateGainL += state->gateSmoothUp * (1.0f - state->gateGainL);
                } else if (state->envL < closeThresh) {
                    float ratio = std::max(0.0f, std::min(1.0f, state->envL / closeThresh));
                    float target = std::max(0.04f, std::min(1.0f, 0.04f + 0.96f * ratio * ratio));
                    state->gateGainL += state->gateSmoothDown * (target - state->gateGainL);
                }
                s *= state->gateGainL;
                float hissAlpha = 0.14f + 0.80f * state->gateGainL;
                state->lpL += hissAlpha * (s - state->lpL);
                s = state->lpL;
#endif
            }
            if (voiceEnhance) {
                if (!windFilter) s = state->hpRumbleL.process(s);
                state->bassLpL += 0.017f * (s - state->bassLpL);
                s += state->bassLpL * 0.28f;
                float sib = s - state->deEssPrevL; state->deEssPrevL = s;
                if (std::fabs(sib) > 0.13f) s -= sib * 0.48f;
                s = state->airL.process(state->presenceL.process(state->mudCutL.process(s)));
                float peak = std::fabs(s);
                state->compEnv += ((peak > state->compEnv) ? state->attackCoeff : state->releaseCoeff) * (peak - state->compEnv);
                float targetComp = (state->compEnv > 0.24f)
                    ? (0.24f + (state->compEnv - 0.24f) / 4.0f) / state->compEnv
                    : 1.0f;
                state->compGain += 0.025f * (targetComp - state->compGain);
                float agcGainMo = std::max(1.0f, std::min(1.90f, 0.28f / std::max(state->compEnv, 0.08f)));
                s = NativeDspState::softLimit(s * state->compGain * (1.18f + 0.22f * agcGainMo));
            }
            if (noiseGate || vocalMode == 1) {
                float absSp = std::fabs(s);
                state->voiceFastL += ((absSp > state->voiceFastL) ? state->voiceFastAttack : state->voiceFastRelease) * (absSp - state->voiceFastL);
                float cappedSp = std::min(absSp, 0.55f);
                if (cappedSp > state->voicePeakL && state->rnnVadL >= 0.40f) {
                    state->voicePeakL += 0.02f * (cappedSp - state->voicePeakL);
                } else {
                    state->voicePeakL *= state->voicePeakDecay;
                }
                if (vocalMode == 1 || state->noiseStrength >= 0.55f) {
                    float ratioThresh = (vocalMode == 1) ? 0.24f : (0.14f + 0.09f * state->noiseStrength);
                    float fgThresh = std::max(0.012f, state->voicePeakL * ratioThresh);
                    float targetC = 1.0f;
                    if (state->voiceFastL < fgThresh && state->rnnVadL < 0.62f) {
                        float r = std::max(0.0f, std::min(1.0f, state->voiceFastL / fgThresh));
                        float minFloor = (vocalMode == 1) ? 0.03f : (1.0f - 0.95f * state->noiseStrength);
                        targetC = minFloor + (1.0f - minFloor) * r * r;
                    }
                    state->chatterGateL += ((targetC > state->chatterGateL) ? state->gateSmoothUp : state->gateSmoothDown) * (targetC - state->chatterGateL);
                    s *= state->chatterGateL;
                }
            }
            if (vocalMode == 1) s *= 1.15f;
            // A mono stream has no side channel to extract.
            if (vocalMode == 2) s = 0.0f;
            if (state->voiceEffectId == 1) {
                state->bassLpL += 0.045f * (s - state->bassLpL);
                s = NativeDspState::softLimit(s * 0.85f + state->bassLpL * 0.85f);
            } else if (state->voiceEffectId == 2) {
                s = NativeDspState::softLimit(state->presenceL.process(s) * 1.15f);
            } else if (state->voiceEffectId == 3) {
                float monoEcho = state->echoBuf[state->echoPos];
                state->echoBuf[state->echoPos] = s + monoEcho * 0.42f;
                state->echoPos = (state->echoPos + 1) % 8000;
                s = NativeDspState::softLimit(s + monoEcho * 0.48f);
            } else if (state->voiceEffectId == 4) {
                state->robotPhase += 2.0f * kPi * 52.0f / state->sampleRate;
                if (state->robotPhase > 2.0f * kPi) state->robotPhase -= 2.0f * kPi;
                s *= (0.55f + 0.45f * std::sin(state->robotPhase));
            } else if (state->voiceEffectId == 5) {
                s = NativeDspState::softLimit(state->airL.process(s) * 1.25f);
            }
            samples[i] = NativeDspState::toInt16(s);
        }
    }

    env->ReleaseShortArrayElements(samplesArr, samples, 0);
}

JNIEXPORT jboolean JNICALL
Java_com_aistudio_kbeditor_r7v4qx_media_NativeMediaEngine_nativeEnhanceBitmap(
    JNIEnv* env, jobject, jobject bitmap, jfloat contrast, jfloat saturation, jfloat brightness
) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) return JNI_FALSE;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return JNI_FALSE;

    void* pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0 || !pixels) return JNI_FALSE;

    auto* data = static_cast<uint8_t*>(pixels);
    const float bShift = brightness * 255.0f;

    // Android bitmap rows may contain padding; use the reported row stride
    // instead of assuming tightly packed width * 4 bytes.
    for (uint32_t y = 0; y < info.height; ++y) {
      uint8_t* row = data + static_cast<size_t>(y) * info.stride;
      for (uint32_t x = 0; x < info.width; ++x) {
        uint8_t* px = row + static_cast<size_t>(x) * 4;
        float r = static_cast<float>(px[0]);
        float g = static_cast<float>(px[1]);
        float b = static_cast<float>(px[2]);

        float lumaIn = 0.299f * r + 0.587f * g + 0.114f * b;
        float shadowLift = (lumaIn < 90.0f) ? (90.0f - lumaIn) * 0.14f : 0.0f;

        r = (r + shadowLift - 128.0f) * contrast + 128.0f + bShift;
        g = (g + shadowLift - 128.0f) * contrast + 128.0f + bShift;
        b = (b + shadowLift - 128.0f) * contrast + 128.0f + bShift;

        float luma = 0.299f * r + 0.587f * g + 0.114f * b;
        r = luma + (r - luma) * saturation;
        g = luma + (g - luma) * saturation;
        b = luma + (b - luma) * saturation;

        px[0] = static_cast<uint8_t>(std::max(0.0f, std::min(255.0f, r)));
        px[1] = static_cast<uint8_t>(std::max(0.0f, std::min(255.0f, g)));
        px[2] = static_cast<uint8_t>(std::max(0.0f, std::min(255.0f, b)));
      }
    }

    AndroidBitmap_unlockPixels(env, bitmap);
    return JNI_TRUE;
}

} // extern "C"
