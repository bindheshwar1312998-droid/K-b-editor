package com.aistudio.kbeditor.r7v4qx.ui

import android.graphics.Bitmap
import android.net.Uri
import android.view.LayoutInflater
import android.view.TextureView
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbAdjustment
import android.content.Context
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.aistudio.kbeditor.r7v4qx.audio.StudioAudioDspProcessor
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.aistudio.kbeditor.r7v4qx.R
import com.aistudio.kbeditor.r7v4qx.model.*
import com.aistudio.kbeditor.r7v4qx.ui.theme.*
import com.aistudio.kbeditor.r7v4qx.vfx.ChromaKeyGlEffect
import com.aistudio.kbeditor.r7v4qx.vfx.CinematicGradeGlEffect
import com.aistudio.kbeditor.r7v4qx.vfx.VideoFxGlEffect
import com.aistudio.kbeditor.r7v4qx.vfx.CurveEvaluators
import com.aistudio.kbeditor.r7v4qx.vision.AiAutoCutEngine
import com.aistudio.kbeditor.r7v4qx.vision.DetectedFaceBox
import com.aistudio.kbeditor.r7v4qx.vision.FaceSwapEngine
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin

@OptIn(UnstableApi::class)
@Composable
fun VerticalPreviewStage(
    project: KbEditorProject,
    playheadMs: Long,
    isPlaying: Boolean,
    selectedClip: VideoClip?,
    clipLocalMs: Long = playheadMs,
    isMotionTrackerMode: Boolean = false,
    onTrackerTap: (Float, Float) -> Unit = { _, _ -> },
    onDragCaption: (String, Float, Float) -> Unit = { _, _, _ -> },
    onDragPip: (String, Float, Float) -> Unit = { _, _, _ -> },
    onDragWatermark: (Float, Float) -> Unit = { _, _ -> },
    onTransformVideo: (Float, Float, Float) -> Unit = { _, _, _ -> },
    onTransformPip: (String, Float, Float, Float, Float) -> Unit = { _, _, _, _, _ -> },
    onTransformCaption: (String, Float, Float, Float, Float) -> Unit = { _, _, _, _, _ -> },
    onResetTransform: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val ratio = project.aspectRatio.widthRatio / project.aspectRatio.heightRatio
    val colorMatrix = selectedClip?.let { CurveEvaluators.buildGradeColorMatrix(it.colorGrade) }

    val clipNormT = if (selectedClip != null && selectedClip.activeDurationMs > 0L) {
        ((playheadMs % selectedClip.activeDurationMs).toFloat() / selectedClip.activeDurationMs).coerceIn(0f, 1f)
    } else 0f

    val kf = selectedClip?.let { CurveEvaluators.interpolateKeyframes(it.keyframes, clipNormT) }
    val trackPt = selectedClip?.motionTrackPoints?.takeIf { it.isNotEmpty() }?.let {
        CurveEvaluators.interpolateKeyframes(it, clipNormT)
    }

    val maskRotDeg = selectedClip?.maskRotationDeg ?: 0f
    val maskShape = when (selectedClip?.maskType) {
        MaskType.CIRCLE -> CircleShape
        MaskType.ROUNDED_RECT -> RoundedCornerShape(28.dp)
        MaskType.SPLIT_WIPE -> GenericShape { size, _ ->
            val p = Path().apply {
                addRect(androidx.compose.ui.geometry.Rect(-size.width * 0.5f, -size.height * 0.5f, size.width * 0.55f, size.height * 1.5f))
            }
            if (maskRotDeg != 0f) {
                val ap = p.asAndroidPath()
                val m = android.graphics.Matrix().apply { postRotate(maskRotDeg, size.width / 2f, size.height / 2f) }
                ap.transform(m)
                addPath(ap.asComposePath())
            } else {
                addPath(p)
            }
        }
        MaskType.MIRROR -> GenericShape { size, _ ->
            val p = Path().apply {
                addRect(androidx.compose.ui.geometry.Rect(-size.width * 0.5f, size.height * 0.22f, size.width * 1.5f, size.height * 0.78f))
            }
            if (maskRotDeg != 0f) {
                val ap = p.asAndroidPath()
                val m = android.graphics.Matrix().apply { postRotate(maskRotDeg, size.width / 2f, size.height / 2f) }
                ap.transform(m)
                addPath(ap.asComposePath())
            } else {
                addPath(p)
            }
        }
        MaskType.HEART -> GenericShape { size, _ ->
            val w = size.width
            val h = size.height
            moveTo(w * 0.5f, h * 0.88f)
            cubicTo(w * 0.08f, h * 0.58f, w * 0.05f, h * 0.20f, w * 0.30f, h * 0.16f)
            cubicTo(w * 0.44f, h * 0.14f, w * 0.50f, h * 0.28f, w * 0.50f, h * 0.32f)
            cubicTo(w * 0.50f, h * 0.28f, w * 0.56f, h * 0.14f, w * 0.70f, h * 0.16f)
            cubicTo(w * 0.95f, h * 0.20f, w * 0.92f, h * 0.58f, w * 0.5f, h * 0.88f)
            close()
        }
        MaskType.STAR -> GenericShape { size, _ ->
            val cx = size.width / 2f
            val cy = size.height / 2f
            val outer = size.minDimension * 0.47f
            val inner = size.minDimension * 0.20f
            for (i in 0 until 10) {
                val r = if (i % 2 == 0) outer else inner
                val angle = Math.toRadians((i * 36 - 90).toDouble())
                val x = cx + (r * kotlin.math.cos(angle)).toFloat()
                val y = cy + (r * kotlin.math.sin(angle)).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
        else -> RoundedCornerShape(14.dp)
    }

    val mediaUri = selectedClip?.mediaUri.orEmpty()
    val isImageClip = mediaUri.endsWith(".png", ignoreCase = true) ||
        mediaUri.endsWith(".jpg", ignoreCase = true) ||
        mediaUri.endsWith(".jpeg", ignoreCase = true)

    val liveAudioDsp = remember { StudioAudioDspProcessor() }

    val renderersFactory = remember(context) {
        object : DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                ctx: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(ctx)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(arrayOf(liveAudioDsp))
                    .build()
            }
        }
    }

    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context, renderersFactory).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }
    }

    val audioPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }
    val sfxPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }
    var lastTriggeredSfxId by remember { mutableStateOf<String?>(null) }

    val aiAutoCutEngine = remember { AiAutoCutEngine() }
    val faceSwapEngine = remember(context) { FaceSwapEngine(context) }
    var sourceFaceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var detectedVideoFace by remember { mutableStateOf<DetectedFaceBox?>(null) }
    var playerViewRef by remember { mutableStateOf<PlayerView?>(null) }
    var cutoutBitmap by remember { mutableStateOf<Bitmap?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
            audioPlayer.release()
            sfxPlayer.release()
            aiAutoCutEngine.close()
            faceSwapEngine.close()
        }
    }

    LaunchedEffect(mediaUri, isImageClip) {
        if (mediaUri.isBlank() || isImageClip) {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
        }
    }

    LaunchedEffect(isPlaying, mediaUri) {
        if (mediaUri.isNotBlank() && !isImageClip) {
            exoPlayer.playWhenReady = isPlaying
        }
    }

    LaunchedEffect(clipLocalMs, isPlaying, mediaUri) {
        if (mediaUri.isNotBlank() && !isImageClip) {
            val targetPos = (selectedClip?.trimStartMs ?: 0L) + clipLocalMs
            if (!isPlaying && abs(exoPlayer.currentPosition - targetPos) > 120L) {
                exoPlayer.seekTo(targetPos)
            } else if (isPlaying && abs(exoPlayer.currentPosition - targetPos) > 1500L) {
                exoPlayer.seekTo(targetPos)
            }
        }
    }

    val effectiveSpeed = remember(selectedClip?.speedMultiplier, selectedClip?.speedRamp, clipNormT) {
        if (selectedClip == null) {
            1f
        } else if (selectedClip.speedRamp != SpeedRampPreset.CONSTANT) {
            CurveEvaluators.evaluateSpeedMultiplier(selectedClip.speedRamp, clipNormT).coerceIn(0.25f, 4.0f)
        } else {
            selectedClip.speedMultiplier.coerceIn(0.25f, 4.0f)
        }
    }

    LaunchedEffect(effectiveSpeed, mediaUri, isImageClip) {
        if (mediaUri.isNotBlank() && !isImageClip) {
            exoPlayer.setPlaybackSpeed(effectiveSpeed)
        }
    }

    LaunchedEffect(project.audioClips) {
        val masterAudio = project.audioClips.firstOrNull()
        liveAudioDsp.windFilterEnabled = masterAudio?.windFilterEnabled == true
        liveAudioDsp.noiseGateEnabled = masterAudio?.noiseGateEnabled == true
        liveAudioDsp.voiceEnhanceEnabled = masterAudio?.voiceEnhanceEnabled == true
        liveAudioDsp.vocalMode = masterAudio?.vocalMode ?: VocalIsolationMode.FULL_MIX
    }

    LaunchedEffect(selectedClip?.muted, selectedClip?.volume, project.tracks.a1Muted) {
        val vol = if (selectedClip?.muted == true || project.tracks.a1Muted) {
            0f
        } else {
            (selectedClip?.volume ?: 1f).coerceIn(0f, 1f)
        }
        exoPlayer.volume = vol
    }

    val activeAudioClip = project.audioClips.firstOrNull { it.mediaUri.isNotBlank() && !it.title.startsWith("SFX:") }
    val activeAudioUri = activeAudioClip?.mediaUri.orEmpty()

    LaunchedEffect(activeAudioUri) {
        if (activeAudioUri.isNotBlank()) {
            audioPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(activeAudioUri)))
            audioPlayer.prepare()
        } else {
            audioPlayer.stop()
            audioPlayer.clearMediaItems()
        }
    }

    LaunchedEffect(isPlaying, activeAudioUri, project.tracks.a1Muted, activeAudioClip?.volume) {
        if (activeAudioUri.isNotBlank()) {
            audioPlayer.volume = if (project.tracks.a1Muted) 0f else (activeAudioClip?.volume ?: 1f).coerceIn(0f, 1f)
            if (project.tracks.a1Muted) sfxPlayer.volume = 0f
            audioPlayer.playWhenReady = isPlaying
        }
    }

    LaunchedEffect(playheadMs, isPlaying, activeAudioUri) {
        if (activeAudioUri.isNotBlank() && !isPlaying) {
            val offsetMs = (playheadMs - (activeAudioClip?.startMs ?: 0L)).coerceAtLeast(0L)
            if (abs(audioPlayer.currentPosition - offsetMs) > 150L) {
                audioPlayer.seekTo(offsetMs)
            }
        }
        if (isPlaying && !project.tracks.a1Muted) {
            val activeSfx = project.audioClips.firstOrNull {
                it.title.startsWith("SFX:") && it.mediaUri.isNotBlank() && playheadMs in it.startMs..(it.startMs + it.durationMs)
            }
            if (activeSfx != null && lastTriggeredSfxId != activeSfx.id) {
                lastTriggeredSfxId = activeSfx.id
                sfxPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(activeSfx.mediaUri)))
                sfxPlayer.volume = activeSfx.volume.coerceIn(0f, 1f)
                sfxPlayer.prepare()
                sfxPlayer.seekTo((playheadMs - activeSfx.startMs).coerceAtLeast(0L))
                sfxPlayer.playWhenReady = true
            } else if (activeSfx == null) {
                lastTriggeredSfxId = null
            }
        } else {
            lastTriggeredSfxId = null
        }
    }

    LaunchedEffect(selectedClip?.colorGrade, selectedClip?.chromaKey, selectedClip?.videoFx, mediaUri, isImageClip) {
        if (mediaUri.isNotBlank() && !isImageClip && selectedClip != null) {
            delay(120L)
            val grade = selectedClip.colorGrade
            val rScale = (1f + grade.lift.dx * 0.2f + grade.gamma.dx * 0.25f + grade.gain.dx * 0.3f + grade.warmth * 0.25f).coerceIn(0.4f, 2.0f)
            val gScale = (1f + grade.lift.dy * 0.15f + grade.gamma.dy * 0.2f + grade.gain.dy * 0.25f).coerceIn(0.4f, 2.0f)
            val bScale = (1f - grade.lift.dx * 0.2f - grade.gamma.dx * 0.25f - grade.gain.dx * 0.3f - grade.warmth * 0.25f).coerceIn(0.4f, 2.0f)
            val effects = mutableListOf<Effect>(
                Contrast((grade.contrast - 1f).coerceIn(-0.9f, 0.9f)),
                HslAdjustment.Builder()
                    .adjustSaturation(((grade.saturation - 1f) * 100f).coerceIn(-100f, 100f))
                    .adjustLightness(((grade.brightness + grade.lift.luma * 0.25f) * 100f).coerceIn(-100f, 100f))
                    .build(),
                RgbAdjustment.Builder()
                    .setRedScale(rScale)
                    .setGreenScale(gScale)
                    .setBlueScale(bScale)
                    .build()
            )
            if (grade.vignette > 0.01f || kotlin.math.abs(grade.highlights) > 0.01f || kotlin.math.abs(grade.shadows) > 0.01f || grade.beautyGlow > 0.01f) {
                effects.add(
                    CinematicGradeGlEffect(
                        vignette = grade.vignette,
                        highlights = grade.highlights,
                        shadows = grade.shadows,
                        beautyGlow = grade.beautyGlow
                    )
                )
            }
            if (selectedClip.videoFx == VideoFxPreset.SPLIT_2X || selectedClip.videoFx == VideoFxPreset.SPLIT_3X) {
                effects.add(VideoFxGlEffect(selectedClip.videoFx))
            }
            if (selectedClip.chromaKey.enabled) {
                effects.add(
                    ChromaKeyGlEffect(
                        keyHue = selectedClip.chromaKey.keyHue,
                        tolerance = selectedClip.chromaKey.tolerance,
                        spillSuppression = selectedClip.chromaKey.spillSuppression,
                        backdropColorHex = selectedClip.chromaKey.studioBackdropHex
                    )
                )
            }
            val pos = (selectedClip.trimStartMs + clipLocalMs).coerceAtLeast(0L)
            exoPlayer.setVideoEffects(effects)
            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(mediaUri)))
            exoPlayer.prepare()
            exoPlayer.seekTo(pos)
            exoPlayer.playWhenReady = isPlaying
        }
    }

    val faceSwapSpec = selectedClip?.faceSwap
    LaunchedEffect(faceSwapSpec?.sourceFaceUri) {
        val uri = faceSwapSpec?.sourceFaceUri.orEmpty()
        sourceFaceBitmap = if (uri.isNotBlank()) faceSwapEngine.prepareFeatheredFaceBitmap(uri) else null
    }

    LaunchedEffect(faceSwapSpec?.enabled, sourceFaceBitmap, mediaUri, isImageClip, isPlaying, playheadMs) {
        if (faceSwapSpec?.enabled != true || sourceFaceBitmap == null || mediaUri.isBlank() || isImageClip) {
            detectedVideoFace = null
            return@LaunchedEffect
        }
        while (true) {
            val tv = playerViewRef?.videoSurfaceView as? TextureView
            val frame = tv?.getBitmap(240, 426)
            if (frame != null) {
                val box = faceSwapEngine.detectPrimaryFace(frame)
                frame.recycle()
                if (box != null) {
                    detectedVideoFace = box
                }
            }
            if (!isPlaying) break
            delay(100L)
        }
    }

    val aiAutoCutEnabled = selectedClip?.chromaKey?.aiAutoCut == true
    val aiBackdropHex = selectedClip?.chromaKey?.studioBackdropHex ?: 0xFF0F172A

    LaunchedEffect(aiAutoCutEnabled, aiBackdropHex, mediaUri, isImageClip, isPlaying, playheadMs) {
        if (!aiAutoCutEnabled || mediaUri.isBlank() || isImageClip) {
            cutoutBitmap = null
            return@LaunchedEffect
        }
        while (true) {
            val tv = playerViewRef?.videoSurfaceView as? TextureView
            val frame = tv?.getBitmap(270, 480)
            if (frame != null) {
                val seg = aiAutoCutEngine.segmentForeground(frame, aiBackdropHex)
                frame.recycle()
                if (seg != null) {
                    cutoutBitmap = seg
                }
            }
            if (!isPlaying) break
            delay(90L)
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(SlateVoid, RoundedCornerShape(16.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .aspectRatio(ratio)
                .fillMaxHeight()
                .clip(maskShape)
                .background(
                    when (project.canvasFillMode) {
                        CanvasFillMode.SOLID_COLOR -> Color(project.canvasSolidColorHex)
                        else -> SlateBase
                    }
                )
                .border(1.dp, SlateBorder, maskShape)
                .pointerInput(isMotionTrackerMode, selectedClip?.id) {
                    if (isMotionTrackerMode) {
                        detectTapGestures { offset ->
                            onTrackerTap(
                                (offset.x / size.width.toFloat()).coerceIn(0.05f, 0.95f),
                                (offset.y / size.height.toFloat()).coerceIn(0.05f, 0.95f)
                            )
                        }
                    } else {
                        detectTransformGestures { _, pan, zoom, _ ->
                            onTransformVideo(zoom, pan.x, pan.y)
                        }
                    }
                }
        ) {
            if (project.tracks.v1Visible && selectedClip != null) {
                if (project.canvasFillMode == CanvasFillMode.BLUR_CANVAS && mediaUri.isNotBlank() && isImageClip) {
                    AsyncImage(
                        model = mediaUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .blur(project.canvasBlurRadius.dp)
                            .alpha(0.55f)
                    )
                }

                if (mediaUri.isNotBlank() && !isImageClip) {
                    AndroidView(
                        factory = { ctx ->
                            (LayoutInflater.from(ctx).inflate(R.layout.view_exo_texture_player, null) as PlayerView).apply {
                                player = exoPlayer
                                useController = false
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                playerViewRef = this
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                val shakeX = if (selectedClip.videoFx == VideoFxPreset.CAM_SHAKE || selectedClip.videoFx == VideoFxPreset.GLITCH_RGB) {
                                    kotlin.math.sin(clipNormT * 48f) * 14f
                                } else 0f
                                val shakeY = if (selectedClip.videoFx == VideoFxPreset.CAM_SHAKE) {
                                    kotlin.math.cos(clipNormT * 36f) * 10f
                                } else 0f
                                val fxScale = when (selectedClip.videoFx) {
                                    VideoFxPreset.CAM_SHAKE -> 1.06f
                                    VideoFxPreset.ZOOM_PULSE -> 1f + 0.08f * kotlin.math.abs(sin(clipNormT * 18f))
                                    VideoFxPreset.HEARTBEAT -> 1f + 0.10f * kotlin.math.abs(sin(clipNormT * 10f)) * kotlin.math.abs(sin(clipNormT * 20f))
                                    else -> 1f
                                }
                                val transT = if (selectedClip.transitionOut != TransitionType.NONE && clipNormT > 0.85f) {
                                    ((clipNormT - 0.85f) / 0.15f).coerceIn(0f, 1f)
                                } else 0f
                                val transAlpha = when (selectedClip.transitionOut) {
                                    TransitionType.CROSS_DISSOLVE -> 1f - transT * 0.85f
                                    TransitionType.FLASH_CUT -> if (transT > 0.4f) 0.35f else 1f
                                    else -> 1f
                                }
                                val transPanX = if (selectedClip.transitionOut == TransitionType.WHIP_PAN) -transT * 260f else 0f
                                val wmCropZoom = if (selectedClip.watermarkRemover.enabled && selectedClip.watermarkRemover.cropMode) 1.14f else 1f
                                val transZoom = (if (selectedClip.transitionOut == TransitionType.ZOOM_THROUGH) 1f + transT * 0.65f else 1f) * wmCropZoom
                                val clipDurMs = selectedClip.activeDurationMs.coerceAtLeast(300L)
                                val clipPosMs = (clipNormT * clipDurMs).toLong()
                                val fadeInAlpha = if (selectedClip.fadeInMs > 0L && clipPosMs < selectedClip.fadeInMs) {
                                    (clipPosMs.toFloat() / selectedClip.fadeInMs.toFloat()).coerceIn(0f, 1f)
                                } else 1f
                                val fadeOutAlpha = if (selectedClip.fadeOutMs > 0L && (clipDurMs - clipPosMs) < selectedClip.fadeOutMs) {
                                    ((clipDurMs - clipPosMs).toFloat() / selectedClip.fadeOutMs.toFloat()).coerceIn(0f, 1f)
                                } else 1f
                                val fxAlpha = (when (selectedClip.videoFx) {
                                    VideoFxPreset.FLASH_STROBE -> if ((playheadMs / 120L) % 2L == 0L) 0.65f else 1f
                                    VideoFxPreset.ACTION_FLASH -> if ((playheadMs / 90L) % 3L == 0L) 0.45f else 1f
                                    else -> 1f
                                }) * transAlpha * fadeInAlpha * fadeOutAlpha
                                translationX = selectedClip.reframeOffsetX * 120f + ((kf?.x ?: 0.5f) - 0.5f) * 140f + shakeX + transPanX + selectedClip.panX
                                translationY = ((kf?.y ?: 0.5f) - 0.5f) * 140f + shakeY + selectedClip.panY
                                scaleX = (kf?.scale ?: 1f) * fxScale * transZoom * selectedClip.zoomScale * (if (selectedClip.flipHorizontal) -1f else 1f)
                                scaleY = (kf?.scale ?: 1f) * fxScale * transZoom * selectedClip.zoomScale
                                rotationZ = (kf?.rotationDeg ?: 0f) + selectedClip.rotationDeg
                                alpha = (kf?.opacity ?: 1f) * fxAlpha
                            }
                    )
                } else if (mediaUri.isNotBlank()) {
                    AsyncImage(
                        model = mediaUri,
                        contentDescription = selectedClip.title,
                        contentScale = ContentScale.Crop,
                        colorFilter = colorMatrix?.let { ColorFilter.colorMatrix(it) },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                translationX = selectedClip.reframeOffsetX * 120f + ((kf?.x ?: 0.5f) - 0.5f) * 140f + selectedClip.panX
                                translationY = ((kf?.y ?: 0.5f) - 0.5f) * 140f + selectedClip.panY
                                scaleX = kf?.scale ?: 1f
                                scaleY = kf?.scale ?: 1f
                                scaleX = (kf?.scale ?: 1f) * selectedClip.zoomScale * (if (selectedClip.flipHorizontal) -1f else 1f)
                                scaleY = (kf?.scale ?: 1f) * selectedClip.zoomScale
                                rotationZ = (kf?.rotationDeg ?: 0f) + selectedClip.rotationDeg
                                alpha = kf?.opacity ?: 1f
                            }
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    listOf(SlateVoid, Color(0xFF162238), SlateBase)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = selectedClip.title.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = ElectricCyan
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Tap + above to import video",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }

                if (faceSwapSpec?.enabled == true && sourceFaceBitmap != null && detectedVideoFace != null) {
                    val fBox = detectedVideoFace!!
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val faceW = maxWidth * (fBox.normWidth * faceSwapSpec.scaleMultiplier).coerceIn(0.12f, 0.85f)
                        val faceH = maxHeight * (fBox.normHeight * faceSwapSpec.scaleMultiplier).coerceIn(0.12f, 0.85f)
                        Image(
                            bitmap = sourceFaceBitmap!!.asImageBitmap(),
                            contentDescription = "Face Swap",
                            contentScale = ContentScale.FillBounds,
                            modifier = Modifier
                                .size(faceW, faceH)
                                .offset(
                                    x = maxWidth * fBox.normCenterX - faceW / 2f,
                                    y = maxHeight * fBox.normCenterY - faceH / 2f
                                )
                                .graphicsLayer {
                                    rotationZ = -fBox.headEulerZ
                                    alpha = faceSwapSpec.blendOpacity.coerceIn(0.2f, 1f)
                                }
                        )
                    }
                }

                if (aiAutoCutEnabled && cutoutBitmap != null) {
                    Image(
                        bitmap = cutoutBitmap!!.asImageBitmap(),
                        contentDescription = "AI Auto-Cut",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                if (selectedClip.videoFx in listOf(
                        VideoFxPreset.VHS_RETRO, VideoFxPreset.GLITCH_RGB, VideoFxPreset.CHROMATIC,
                        VideoFxPreset.CINEMA_GRAIN, VideoFxPreset.OLD_TV, VideoFxPreset.NEON_EDGE,
                        VideoFxPreset.SPLIT_2X, VideoFxPreset.SPLIT_3X
                    )
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        when (selectedClip.videoFx) {
                            VideoFxPreset.SPLIT_2X -> {
                                drawLine(Color.White.copy(alpha = 0.85f), Offset(0f, size.height * 0.5f), Offset(size.width, size.height * 0.5f), strokeWidth = 4f)
                                drawRect(Color.Black.copy(alpha = 0.14f), topLeft = Offset(0f, size.height * 0.5f), size = androidx.compose.ui.geometry.Size(size.width, size.height * 0.5f))
                            }
                            VideoFxPreset.SPLIT_3X -> {
                                drawLine(Color.White.copy(alpha = 0.85f), Offset(0f, size.height * 0.333f), Offset(size.width, size.height * 0.333f), strokeWidth = 4f)
                                drawLine(Color.White.copy(alpha = 0.85f), Offset(0f, size.height * 0.666f), Offset(size.width, size.height * 0.666f), strokeWidth = 4f)
                            }
                            VideoFxPreset.NEON_EDGE -> {
                                drawRect(ElectricCyan.copy(alpha = 0.14f))
                                drawRect(ElectricCyan.copy(alpha = 0.85f), style = Stroke(width = 6f))
                            }
                            else -> {
                                val lineAlpha = if (selectedClip.videoFx == VideoFxPreset.VHS_RETRO || selectedClip.videoFx == VideoFxPreset.OLD_TV) 0.22f else 0.10f
                                var y = 0f
                                while (y < size.height) {
                                    drawLine(Color.Black.copy(alpha = lineAlpha), Offset(0f, y), Offset(size.width, y), strokeWidth = 2f)
                                    y += 10f
                                }
                                if (selectedClip.videoFx == VideoFxPreset.CHROMATIC || selectedClip.videoFx == VideoFxPreset.GLITCH_RGB) {
                                    drawRect(Color.Cyan.copy(alpha = 0.08f))
                                }
                            }
                        }
                    }
                }

                if (selectedClip.watermarkRemover.enabled && !selectedClip.watermarkRemover.cropMode) {
                    val wm = selectedClip.watermarkRemover
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(wm.enabled) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    onDragWatermark(dragAmount.x / size.width.toFloat(), dragAmount.y / size.height.toFloat())
                                }
                            }
                    ) {
                        val bw = size.width * wm.boxWidth
                        val bh = size.height * wm.boxHeight
                        val left = (size.width * wm.posX - bw / 2f).coerceIn(0f, size.width - bw)
                        val top = (size.height * wm.posY - bh / 2f).coerceIn(0f, size.height - bh)
                        drawRoundRect(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xEE181C24), Color(0xCC0F172A), Color(0x550F172A)),
                                center = Offset(left + bw / 2f, top + bh / 2f),
                                radius = maxOf(bw, bh) * 0.8f
                            ),
                            topLeft = Offset(left, top),
                            size = androidx.compose.ui.geometry.Size(bw, bh),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f)
                        )
                        drawRoundRect(
                            color = ElectricCyan.copy(alpha = 0.45f),
                            topLeft = Offset(left, top),
                            size = androidx.compose.ui.geometry.Size(bw, bh),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f),
                            style = Stroke(width = 1.5f)
                        )
                    }
                }

                if (selectedClip.maskType == MaskType.ANAMORPHIC_BARS) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.12f)
                            .align(Alignment.TopCenter)
                            .background(Color.Black)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.12f)
                            .align(Alignment.BottomCenter)
                            .background(Color.Black)
                    )
                }
            }

            if (project.tracks.o1Visible) {
                project.pipClips.filter { playheadMs in it.startMs..(it.startMs + it.durationMs) }.forEach { pip ->
                    if (pip.mediaUri.isNotBlank()) {
                        AsyncImage(
                            model = pip.mediaUri,
                            contentDescription = pip.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize(pip.scale.coerceIn(0.25f, 0.9f))
                                .align(Alignment.Center)
                                .graphicsLayer {
                                    alpha = pip.opacity.coerceIn(0.1f, 1f)
                                    rotationZ = pip.rotationDeg
                                    translationX = (pip.posX - 0.5f) * 160f
                                    translationY = (pip.posY - 0.5f) * 200f
                                }
                                .pointerInput(pip.id) {
                                    detectTransformGestures { _, pan, zoom, rotation ->
                                        onTransformPip(pip.id, zoom, pan.x, pan.y, rotation)
                                    }
                                }
                                .clip(RoundedCornerShape(12.dp))
                        )
                    } else if (pip.opticalFxPreset?.startsWith("STICKER:") == true) {
                        val stickerLabel = pip.opticalFxPreset.removePrefix("STICKER:")
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                        ) {
                            Text(
                                text = stickerLabel,
                                fontSize = (20f * pip.scale.coerceIn(0.4f, 1.4f)).sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .offset(
                                        x = ((pip.posX - 0.5f) * 180).dp,
                                        y = ((pip.posY - 0.5f) * 260).dp
                                    )
                                    .pointerInput(pip.id) {
                                        detectDragGestures { change, dragAmount ->
                                            change.consume()
                                            onDragPip(pip.id, dragAmount.x / 220f, dragAmount.y / 320f)
                                        }
                                    }
                                    .background(Color(0xCC111827), RoundedCornerShape(14.dp))
                                    .border(1.5.dp, WarmAmber, RoundedCornerShape(14.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    } else {
                        val composeBlend = when (pip.blendMode) {
                            BlendModePreset.NORMAL -> BlendMode.SrcOver
                            BlendModePreset.SCREEN -> BlendMode.Screen
                            BlendModePreset.MULTIPLY -> BlendMode.Multiply
                            BlendModePreset.ADD -> BlendMode.Plus
                            BlendModePreset.OVERLAY -> BlendMode.Overlay
                        }
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                        ) {
                            val center = Offset(size.width * pip.posX, size.height * pip.posY)
                            val radius = size.minDimension * 0.28f * pip.scale
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(ElectricCyan.copy(alpha = pip.opacity), WarmAmber.copy(alpha = 0.25f), Color.Transparent),
                                    center = center,
                                    radius = radius
                                ),
                                center = center,
                                radius = radius,
                                blendMode = composeBlend
                            )
                        }
                    }
                }
            }

            if (project.tracks.t1Visible) {
                project.captionClips.filter { playheadMs in it.startMs..(it.startMs + it.durationMs) }.forEach { cap ->
                    val capProgress = ((playheadMs - cap.startMs).toFloat() / cap.durationMs.coerceAtLeast(1L)).coerceIn(0f, 1f)
                    val animScale = when (cap.animation3D) {
                        MotionAnimation3D.POP_3D -> if (capProgress < 0.2f) 0.6f + capProgress * 2.2f else 1f
                        MotionAnimation3D.FLOAT_NEON -> 1f + 0.04f * sin(capProgress * 12f)
                        else -> 1f
                    }
                    val rotY = if (cap.animation3D == MotionAnimation3D.FLIP_3D && capProgress < 0.3f) {
                        (1f - capProgress / 0.3f) * 75f
                    } else 0f

                    val anchorX = trackPt?.x ?: cap.posX
                    val anchorY = trackPt?.y ?: cap.posY

                    val rawTxt = if (cap.animation3D == MotionAnimation3D.TYPEWRITER) {
                        cap.text.take((cap.text.length * (capProgress * 2f).coerceAtMost(1f)).toInt().coerceAtLeast(1))
                    } else cap.text
                    val displayTxt = if (cap.stylePreset == CaptionStylePreset.VIRAL_HORMOZI || cap.stylePreset == CaptionStylePreset.MINIMAL_TAG) {
                        rawTxt.uppercase()
                    } else rawTxt

                    val bgModifier = when (cap.stylePreset) {
                        CaptionStylePreset.VIRAL_HORMOZI -> Modifier
                            .background(Color.Black.copy(alpha = 0.48f), RoundedCornerShape(8.dp))
                            .border(1.5.dp, Color(cap.accentHex), RoundedCornerShape(8.dp))
                        CaptionStylePreset.NEON_CYBER -> Modifier
                            .background(Color(0xCC060913), RoundedCornerShape(10.dp))
                            .border(1.5.dp, ElectricCyan, RoundedCornerShape(10.dp))
                        CaptionStylePreset.DARK_PILL -> Modifier
                            .background(Color(0xDD090B10), RoundedCornerShape(22.dp))
                        CaptionStylePreset.GRADIENT_POP -> Modifier
                            .background(
                                Brush.horizontalGradient(listOf(VioletClip, Color(0xFFEC4899), WarmAmber)),
                                RoundedCornerShape(12.dp)
                            )
                        CaptionStylePreset.GOLD_LUXURY -> Modifier
                            .background(Color(0xDD0B0E14), RoundedCornerShape(10.dp))
                            .border(1.5.dp, WarmAmber, RoundedCornerShape(10.dp))
                        CaptionStylePreset.OUTLINE_IMPACT -> Modifier
                        CaptionStylePreset.CINEMA_SUB -> Modifier
                            .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                        CaptionStylePreset.MINIMAL_TAG -> Modifier
                            .background(Color.White.copy(alpha = 0.90f), RoundedCornerShape(6.dp))
                    }

                    val textColor = when (cap.stylePreset) {
                        CaptionStylePreset.MINIMAL_TAG -> Color(0xFF090B10)
                        CaptionStylePreset.VIRAL_HORMOZI, CaptionStylePreset.GOLD_LUXURY -> Color(cap.accentHex)
                        else -> Color(cap.colorHex)
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = displayTxt,
                            color = textColor,
                            fontSize = (cap.fontSizeSp * 0.72f).coerceIn(11f, 26f).sp,
                            fontWeight = if (cap.isBold) FontWeight.ExtraBold else FontWeight.SemiBold,
                            fontFamily = when (cap.fontStyle) {
                                CaptionFontStyle.SANS_BOLD, CaptionFontStyle.ROUNDED_POP -> androidx.compose.ui.text.font.FontFamily.SansSerif
                                CaptionFontStyle.SERIF_EDITORIAL -> androidx.compose.ui.text.font.FontFamily.Serif
                                CaptionFontStyle.MONO_CODE -> androidx.compose.ui.text.font.FontFamily.Monospace
                            },
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            style = androidx.compose.ui.text.TextStyle(
                                shadow = androidx.compose.ui.graphics.Shadow(
                                    color = if (cap.stylePreset == CaptionStylePreset.NEON_CYBER) ElectricCyan else Color.Black,
                                    offset = Offset(0f, 3f),
                                    blurRadius = if (cap.stylePreset == CaptionStylePreset.NEON_CYBER) 12f else 6f
                                )
                            ),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .offset(
                                    x = ((anchorX - 0.5f) * 140).dp,
                                    y = ((anchorY - 0.8f) * 260).dp
                                )
                                .graphicsLayer {
                                    scaleX = animScale
                                    scaleY = animScale
                                    rotationY = rotY
                                    rotationZ = cap.rotationDeg
                                    cameraDistance = 12f * density
                                }
                                .pointerInput(cap.id) {
                                    detectTransformGestures { _, pan, zoom, rotation ->
                                        onTransformCaption(cap.id, zoom, pan.x, pan.y, rotation)
                                    }
                                }
                                .then(bgModifier)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            if (trackPt != null) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cx = size.width * trackPt.x
                    val cy = size.height * trackPt.y
                    drawCircle(
                        color = ElectricCyan,
                        radius = 22f,
                        center = Offset(cx, cy),
                        style = Stroke(width = 2.5f)
                    )
                    drawLine(ElectricCyan, Offset(cx - 30f, cy), Offset(cx + 30f, cy), strokeWidth = 2f)
                    drawLine(ElectricCyan, Offset(cx, cy - 30f), Offset(cx, cy + 30f), strokeWidth = 2f)
                }
            }

            if (selectedClip != null && (selectedClip.zoomScale != 1f || selectedClip.panX != 0f || selectedClip.panY != 0f || selectedClip.rotationDeg != 0f)) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.72f))
                        .border(1.dp, ElectricCyan.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                        .clickable { onResetTransform() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Reset ${"%.1f".format(selectedClip.zoomScale)}x",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElectricCyan
                    )
                }
            }

            if (project.safeZoneVisible) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val insetX = size.width * 0.08f
                    val insetY = size.height * 0.10f
                    drawRect(
                        color = WarmAmber.copy(alpha = 0.65f),
                        topLeft = Offset(insetX, insetY),
                        size = androidx.compose.ui.geometry.Size(size.width - insetX * 2, size.height - insetY * 2),
                        style = Stroke(width = 1.5f)
                    )
                }
            }
        }
    }
}
