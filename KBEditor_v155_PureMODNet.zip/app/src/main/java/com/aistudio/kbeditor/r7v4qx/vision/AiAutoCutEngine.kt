package com.aistudio.kbeditor.r7v4qx.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.coroutines.resume

class AiAutoCutEngine(private val context: android.content.Context? = null) {

    private val resolvedContext: android.content.Context? by lazy {
        context ?: runCatching {
            Class.forName("android.app.ActivityThread")
                .getMethod("currentApplication")
                .invoke(null) as? android.content.Context
        }.getOrNull()
    }

    private val liteRt by lazy { resolvedContext?.let { LiteRtModelEngine(it) } }

    private var prevAlphas: FloatArray? = null
    private var prevW: Int = 0
    private var prevH: Int = 0

    private val subjectSegmenter by lazy {
        val options = SubjectSegmenterOptions.Builder()
            .enableForegroundConfidenceMask()
            .build()
        SubjectSegmentation.getClient(options)
    }

    private val selfieSegmenter by lazy {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
        Segmentation.getClient(options)
    }

    suspend fun segmentForeground(
        sourceBitmap: Bitmap,
        backdropColorHex: Long
    ): Bitmap? = withContext(Dispatchers.Default) {
        val modelInput = boostForMatting(sourceBitmap)
        try {
            // 0. Run Human-Only models: MODNet TFLite (hair-strand portrait matting) + ML Kit SelfieSegmentation (distant/multi-human)
            // Note: Do NOT blindly fuse generic SubjectSegmentation over MODNet, or non-human foreground objects (tree trunks/wood) leak in!
            val modnetRes = liteRt?.takeIf { it.hasModel("modnet_matting.tflite") }?.runMattingMask("modnet_matting.tflite", modelInput)
            val inputImage = InputImage.fromBitmap(modelInput, 0)

            val selfieMask = suspendCancellableCoroutine<SegmentationMask?> { cont ->
                selfieSegmenter.process(inputImage)
                    .addOnSuccessListener { mask ->
                        if (cont.isActive) cont.resume(mask)
                    }
                    .addOnFailureListener {
                        if (cont.isActive) cont.resume(null)
                    }
            }

            if (modnetRes != null) {
                val (mArr, mw, mh) = modnetRes
                val fgCount = mArr.count { it > 0.50f }
                val hasStrongPortrait = fgCount >= (mArr.size / 50)
                val mBuf = java.nio.ByteBuffer.allocateDirect(4 * mArr.size).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                    put(mArr)
                    rewind()
                }
                // Only fuse SelfieSegmentation if MODNet missed a distant/small subject; otherwise keep pure MODNet crisp hair edges!
                val selfieBuf = if (!hasStrongPortrait) selfieMask?.buffer?.duplicate()?.order(ByteOrder.nativeOrder())?.asFloatBuffer() else null
                return@withContext applyMaskFullRes(
                    sourceBitmap = sourceBitmap,
                    maskW = mw,
                    maskH = mh,
                    buffer = mBuf,
                    secondaryBuffer = selfieBuf,
                    secW = selfieMask?.width ?: modelInput.width,
                    secH = selfieMask?.height ?: modelInput.height,
                    backdropColorHex = backdropColorHex
                )
            }

            if (selfieMask != null) {
                val selfieBuf = selfieMask.buffer.duplicate().order(ByteOrder.nativeOrder()).asFloatBuffer()
                return@withContext applyMaskFullRes(
                    sourceBitmap = sourceBitmap,
                    maskW = selfieMask.width,
                    maskH = selfieMask.height,
                    buffer = selfieBuf,
                    secondaryBuffer = null,
                    secW = modelInput.width,
                    secH = modelInput.height,
                    backdropColorHex = backdropColorHex
                )
            }

            // Fallback only if both human models failed
            val subjectMask = suspendCancellableCoroutine<FloatBuffer?> { cont ->
                subjectSegmenter.process(inputImage)
                    .addOnSuccessListener { result ->
                        if (cont.isActive) cont.resume(result.foregroundConfidenceMask)
                    }
                    .addOnFailureListener {
                        if (cont.isActive) cont.resume(null)
                    }
            }

            if (subjectMask != null) {
                return@withContext applyMaskFullRes(
                    sourceBitmap = sourceBitmap,
                    maskW = modelInput.width,
                    maskH = modelInput.height,
                    buffer = subjectMask,
                    secondaryBuffer = null,
                    secW = modelInput.width,
                    secH = modelInput.height,
                    backdropColorHex = backdropColorHex
                )
            }
            null
        } finally {
            if (modelInput !== sourceBitmap) modelInput.recycle()
        }
    }

    /**
     * Pre-Matting Low-Light & Edge Boost (only for AI inference input; original colors remain untouched):
     * Lifts dark shadows & enhances hair-vs-background contrast in dim or fast-motion frames.
     */
    private fun boostForMatting(src: Bitmap): Bitmap {
        val w = src.width.coerceAtLeast(1)
        val h = src.height.coerceAtLeast(1)
        val targetW = minOf(w, 512)
        val targetH = ((h.toFloat() / w) * targetW).toInt().coerceIn(1, 512)
        val scaled = Bitmap.createScaledBitmap(src, targetW, targetH, true)
        val px = IntArray(targetW * targetH)
        scaled.getPixels(px, 0, targetW, 0, 0, targetW, targetH)

        var lumaSum = 0L
        val step = (px.size / 4096).coerceAtLeast(1)
        var samples = 0
        var idx = 0
        while (idx < px.size) {
            val c = px[idx]
            lumaSum += ((Color.red(c) * 77 + Color.green(c) * 150 + Color.blue(c) * 29) shr 8)
            samples++
            idx += step
        }
        val avgLuma = if (samples > 0) lumaSum.toFloat() / samples else 128f
        if (avgLuma >= 112f) return scaled

        val gamma = if (avgLuma < 65f) 0.65 else 0.78
        val lut = IntArray(256) { i ->
            (Math.pow(i / 255.0, gamma) * 255.0).toInt().coerceIn(0, 255)
        }
        for (i in px.indices) {
            val c = px[i]
            px[i] = Color.argb(
                255,
                lut[Color.red(c)],
                lut[Color.green(c)],
                lut[Color.blue(c)]
            )
        }
        scaled.setPixels(px, 0, targetW, 0, 0, targetW, targetH)
        return scaled
    }

    private fun sampleMaskBilinear(buf: FloatArray, mw: Int, mh: Int, fx: Float, fy: Float): Float {
        val x0 = fx.toInt().coerceIn(0, mw - 1)
        val y0 = fy.toInt().coerceIn(0, mh - 1)
        val x1 = (x0 + 1).coerceAtMost(mw - 1)
        val y1 = (y0 + 1).coerceAtMost(mh - 1)
        val dx = (fx - x0).coerceIn(0f, 1f)
        val dy = (fy - y0).coerceIn(0f, 1f)
        val v00 = buf[y0 * mw + x0]
        val v10 = buf[y0 * mw + x1]
        val v01 = buf[y1 * mw + x0]
        val v11 = buf[y1 * mw + x1]
        val top = v00 + (v10 - v00) * dx
        val bot = v01 + (v11 - v01) * dx
        return top + (bot - top) * dy
    }

    private fun applyMaskFullRes(
        sourceBitmap: Bitmap,
        maskW: Int,
        maskH: Int,
        buffer: FloatBuffer,
        secondaryBuffer: FloatBuffer?,
        secW: Int,
        secH: Int,
        backdropColorHex: Long
    ): Bitmap {
        val outW = sourceBitmap.width.coerceAtLeast(1)
        val outH = sourceBitmap.height.coerceAtLeast(1)

        buffer.rewind()
        val m1 = FloatArray(maskW * maskH)
        val n1 = minOf(m1.size, buffer.remaining())
        for (i in 0 until n1) m1[i] = buffer.get().coerceIn(0f, 1f)

        val m2 = if (secondaryBuffer != null) {
            secondaryBuffer.rewind()
            FloatArray(secW * secH).also { arr ->
                val n2 = minOf(arr.size, secondaryBuffer.remaining())
                for (i in 0 until n2) arr[i] = secondaryBuffer.get().coerceIn(0f, 1f)
            }
        } else null

        val pixels = IntArray(outW * outH)
        sourceBitmap.getPixels(pixels, 0, outW, 0, 0, outW, outH)

        val bgColor = backdropColorHex.toInt()
        val bgR = Color.red(bgColor)
        val bgG = Color.green(bgColor)
        val bgB = Color.blue(bgColor)

        val alphas = FloatArray(outW * outH)
        for (y in 0 until outH) {
            val fy1 = (y.toFloat() / outH) * maskH
            val fy2 = (y.toFloat() / outH) * secH
            for (x in 0 until outW) {
                val fx1 = (x.toFloat() / outW) * maskW
                val c1 = sampleMaskBilinear(m1, maskW, maskH, fx1, fy1)
                val c2 = if (m2 != null) {
                    val fx2 = (x.toFloat() / outW) * secW
                    sampleMaskBilinear(m2, secW, secH, fx2, fy2)
                } else 0f
                val confidence = maxOf(c1, c2 * 0.90f)
                alphas[y * outW + x] = if (confidence >= 0.86f) 1f else ((confidence - 0.63f) / 0.23f).coerceIn(0f, 1f)
            }
        }

        // Adaptive Temporal Smoothing: removes frame-to-frame edge flicker without ghosting on fast motion
        val prev = prevAlphas
        if (prev != null && prevW == outW && prevH == outH && prev.size == alphas.size) {
            for (i in alphas.indices) {
                val cur = alphas[i]
                val old = prev[i]
                if (kotlin.math.abs(cur - old) <= 0.35f) {
                    alphas[i] = (cur * 0.72f + old * 0.28f).coerceIn(0f, 1f)
                }
            }
        }
        prevAlphas = alphas.copyOf()
        prevW = outW
        prevH = outH

        // Guided HD Edge Refinement: snaps upsampled alpha transitions to original HD luminance edges for sharper hair & clothes
        val refined = alphas.copyOf()
        for (y in 1 until outH - 1) {
            for (x in 1 until outW - 1) {
                val i = y * outW + x
                val a = alphas[i]
                if (a > 0.04f && a < 0.96f) {
                    val c0 = pixels[i]
                    val l0 = (Color.red(c0) * 77 + Color.green(c0) * 150 + Color.blue(c0) * 29) shr 8
                    var wSum = 1f
                    var aSum = a
                    for (ny in (y - 1)..(y + 1)) {
                        for (nx in (x - 1)..(x + 1)) {
                            if (ny == y && nx == x) continue
                            val ni = ny * outW + nx
                            val nc = pixels[ni]
                            val nl = (Color.red(nc) * 77 + Color.green(nc) * 150 + Color.blue(nc) * 29) shr 8
                            val diff = kotlin.math.abs(l0 - nl)
                            val w = 1f / (1f + (diff * diff) / 360f)
                            wSum += w
                            aSum += alphas[ni] * w
                        }
                    }
                    refined[i] = (aSum / wSum).coerceIn(0f, 1f)
                }
            }
        }
        for (i in refined.indices) {
            alphas[i] = if (refined[i] < 0.12f) 0f else refined[i]
        }

        // Edge Color Decontamination: replaces green/brown background bleed on hair & shoulder edges with pure foreground color
        for (y in 0 until outH) {
            for (x in 0 until outW) {
                val idx = y * outW + x
                val alpha = alphas[idx]
                if (alpha < 0.99f) {
                    val px = pixels[idx]
                    var fgR = Color.red(px)
                    var fgG = Color.green(px)
                    var fgB = Color.blue(px)
                    if (alpha > 0.06f && alpha < 0.92f) {
                        var sumR = 0; var sumG = 0; var sumB = 0; var cnt = 0
                        val yMin = (y - 2).coerceAtLeast(0)
                        val yMax = (y + 2).coerceAtMost(outH - 1)
                        val xMin = (x - 2).coerceAtLeast(0)
                        val xMax = (x + 2).coerceAtMost(outW - 1)
                        for (ny in yMin..yMax) {
                            for (nx in xMin..xMax) {
                                val nIdx = ny * outW + nx
                                if (alphas[nIdx] >= 0.92f) {
                                    val npx = pixels[nIdx]
                                    sumR += Color.red(npx)
                                    sumG += Color.green(npx)
                                    sumB += Color.blue(npx)
                                    cnt++
                                }
                            }
                        }
                        if (cnt > 0) {
                            fgR = (fgR * 0.40f + (sumR / cnt) * 0.60f).toInt().coerceIn(0, 255)
                            fgG = (fgG * 0.40f + (sumG / cnt) * 0.60f).toInt().coerceIn(0, 255)
                            fgB = (fgB * 0.40f + (sumB / cnt) * 0.60f).toInt().coerceIn(0, 255)
                        }
                    }
                    if (backdropColorHex == 0L) {
                        pixels[idx] = Color.argb((alpha * 255f).toInt(), fgR, fgG, fgB)
                    } else {
                        val r = (fgR * alpha + bgR * (1f - alpha)).toInt()
                        val g = (fgG * alpha + bgG * (1f - alpha)).toInt()
                        val b = (fgB * alpha + bgB * (1f - alpha)).toInt()
                        pixels[idx] = Color.argb(255, r, g, b)
                    }
                }
            }
        }

        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, outW, 0, 0, outW, outH)
        return out
    }

    fun close() {
        prevAlphas = null
        runCatching { subjectSegmenter.close() }
        runCatching { selfieSegmenter.close() }
    }
}
