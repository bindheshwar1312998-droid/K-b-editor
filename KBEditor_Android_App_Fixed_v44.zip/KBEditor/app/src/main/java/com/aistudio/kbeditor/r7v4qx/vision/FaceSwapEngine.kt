package com.aistudio.kbeditor.r7v4qx.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.math.atan2
import kotlin.math.hypot

data class DetectedFaceBox(
    val normCenterX: Float,
    val normCenterY: Float,
    val normWidth: Float,
    val normHeight: Float,
    val headEulerZ: Float
)

data class PreparedSourceFace(
    val bitmap: Bitmap,
    val leftEye: PointF,
    val rightEye: PointF,
    val noseBase: PointF,
    val mouthCenter: PointF,
    val contourPts: List<PointF>,
    val meanR: Float,
    val meanG: Float,
    val meanB: Float
)

class FaceSwapEngine(private val context: Context) {

    private val detector by lazy {
        val opts = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
            .build()
        FaceDetection.getClient(opts)
    }

    private suspend fun detectFacesRaw(bitmap: Bitmap): List<Face> = withContext(Dispatchers.Default) {
        val image = InputImage.fromBitmap(bitmap, 0)
        suspendCancellableCoroutine { cont ->
            detector.process(image)
                .addOnSuccessListener { list ->
                    if (cont.isActive) cont.resume(list)
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume(emptyList())
                }
        }
    }

    private fun extractKeyPoints(face: Face, w: Float, h: Float): Array<PointF> {
        val box = face.boundingBox
        val cx = box.exactCenterX().coerceIn(0f, w)
        val cy = box.exactCenterY().coerceIn(0f, h)
        val bw = box.width().toFloat().coerceAtLeast(20f)
        val bh = box.height().toFloat().coerceAtLeast(20f)

        val lEye = face.getLandmark(FaceLandmark.LEFT_EYE)?.position
            ?: PointF(cx - bw * 0.20f, cy - bh * 0.14f)
        val rEye = face.getLandmark(FaceLandmark.RIGHT_EYE)?.position
            ?: PointF(cx + bw * 0.20f, cy - bh * 0.14f)
        val nose = face.getLandmark(FaceLandmark.NOSE_BASE)?.position
            ?: PointF(cx, cy + bh * 0.05f)
        val mLeft = face.getLandmark(FaceLandmark.MOUTH_LEFT)?.position
        val mRight = face.getLandmark(FaceLandmark.MOUTH_RIGHT)?.position
        val mouth = if (mLeft != null && mRight != null) {
            PointF((mLeft.x + mRight.x) * 0.5f, (mLeft.y + mRight.y) * 0.5f)
        } else {
            face.getLandmark(FaceLandmark.MOUTH_BOTTOM)?.position
                ?: PointF(cx, cy + bh * 0.28f)
        }
        return arrayOf(lEye, rEye, nose, mouth)
    }

    private fun sampleInnerFaceRgb(bmp: Bitmap, cx: Float, cy: Float, radius: Float): Triple<Float, Float, Float> {
        var rSum = 0L
        var gSum = 0L
        var bSum = 0L
        var count = 0
        val rad = radius.toInt().coerceIn(4, 48)
        val ix = cx.toInt()
        val iy = cy.toInt()
        val step = (rad / 4).coerceAtLeast(1)
        for (y in (iy - rad)..(iy + rad) step step) {
            if (y !in 0 until bmp.height) continue
            for (x in (ix - rad)..(ix + rad) step step) {
                if (x !in 0 until bmp.width) continue
                val px = bmp.getPixel(x, y)
                rSum += Color.red(px)
                gSum += Color.green(px)
                bSum += Color.blue(px)
                count++
            }
        }
        if (count == 0) return Triple(128f, 110f, 98f)
        return Triple(rSum.toFloat() / count, gSum.toFloat() / count, bSum.toFloat() / count)
    }

    suspend fun detectPrimaryFace(bitmap: Bitmap): DetectedFaceBox? {
        val faces = detectFacesRaw(bitmap)
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return null
        val box = face.boundingBox
        val w = bitmap.width.toFloat().coerceAtLeast(1f)
        val h = bitmap.height.toFloat().coerceAtLeast(1f)
        return DetectedFaceBox(
            normCenterX = (box.exactCenterX() / w).coerceIn(0.1f, 0.9f),
            normCenterY = (box.exactCenterY() / h).coerceIn(0.1f, 0.9f),
            normWidth = (box.width() / w).coerceIn(0.12f, 0.85f),
            normHeight = (box.height() / h).coerceIn(0.12f, 0.85f),
            headEulerZ = face.headEulerAngleZ
        )
    }

    suspend fun prepareSourceFaceProfile(faceUriStr: String): PreparedSourceFace? = withContext(Dispatchers.IO) {
        if (faceUriStr.isBlank()) return@withContext null
        val raw = runCatching {
            context.contentResolver.openInputStream(Uri.parse(faceUriStr))?.use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        }.getOrNull() ?: return@withContext null

        val maxDim = 768f
        val scale = minOf(maxDim / raw.width.coerceAtLeast(1), maxDim / raw.height.coerceAtLeast(1), 1f)
        val bmp = if (scale < 0.99f) {
            Bitmap.createScaledBitmap(raw, (raw.width * scale).toInt().coerceAtLeast(64), (raw.height * scale).toInt().coerceAtLeast(64), true).also {
                if (it !== raw) raw.recycle()
            }
        } else raw

        val faces = detectFacesRaw(bmp)
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
        if (face == null) {
            val w = bmp.width.toFloat()
            val h = bmp.height.toFloat()
            val (mr, mg, mb) = sampleInnerFaceRgb(bmp, w * 0.5f, h * 0.5f, minOf(w, h) * 0.15f)
            return@withContext PreparedSourceFace(
                bitmap = bmp,
                leftEye = PointF(w * 0.38f, h * 0.40f),
                rightEye = PointF(w * 0.62f, h * 0.40f),
                noseBase = PointF(w * 0.50f, h * 0.52f),
                mouthCenter = PointF(w * 0.50f, h * 0.66f),
                contourPts = emptyList(),
                meanR = mr, meanG = mg, meanB = mb
            )
        }

        val pts = extractKeyPoints(face, bmp.width.toFloat(), bmp.height.toFloat())
        val contour = face.getContour(FaceContour.FACE)?.points.orEmpty()
        val (mr, mg, mb) = sampleInnerFaceRgb(bmp, pts[2].x, pts[2].y, face.boundingBox.width() * 0.16f)
        PreparedSourceFace(
            bitmap = bmp,
            leftEye = pts[0],
            rightEye = pts[1],
            noseBase = pts[2],
            mouthCenter = pts[3],
            contourPts = contour,
            meanR = mr,
            meanG = mg,
            meanB = mb
        )
    }

    suspend fun renderLandmarkFaceOverlay(
        targetFrame: Bitmap,
        source: PreparedSourceFace,
        outW: Int,
        outH: Int,
        scaleMultiplier: Float = 1.0f,
        blendOpacity: Float = 0.92f,
        lipSyncEnabled: Boolean = true
    ): Bitmap? = withContext(Dispatchers.Default) {
        val faces = detectFacesRaw(targetFrame)
        val tgtFace = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return@withContext null

        val sx = outW.toFloat() / targetFrame.width.coerceAtLeast(1)
        val sy = outH.toFloat() / targetFrame.height.coerceAtLeast(1)
        val tgtPts = extractKeyPoints(tgtFace, targetFrame.width.toFloat(), targetFrame.height.toFloat())

        val tgtLEye = PointF(tgtPts[0].x * sx, tgtPts[0].y * sy)
        val tgtREye = PointF(tgtPts[1].x * sx, tgtPts[1].y * sy)
        val tgtNose = PointF(tgtPts[2].x * sx, tgtPts[2].y * sy)

        val srcEyeDx = (source.rightEye.x - source.leftEye.x).toDouble()
        val srcEyeDy = (source.rightEye.y - source.leftEye.y).toDouble()
        val srcEyeDist = hypot(srcEyeDx, srcEyeDy).toFloat().coerceAtLeast(8f)
        val srcAngle = Math.toDegrees(atan2(srcEyeDy, srcEyeDx)).toFloat()
        val srcMidX = (source.leftEye.x + source.rightEye.x) * 0.5f
        val srcMidY = (source.leftEye.y + source.rightEye.y) * 0.5f

        val tgtEyeDx = (tgtREye.x - tgtLEye.x).toDouble()
        val tgtEyeDy = (tgtREye.y - tgtLEye.y).toDouble()
        val tgtEyeDist = hypot(tgtEyeDx, tgtEyeDy).toFloat().coerceAtLeast(8f)
        val tgtAngle = Math.toDegrees(atan2(tgtEyeDy, tgtEyeDx)).toFloat()
        val tgtMidX = (tgtLEye.x + tgtREye.x) * 0.5f
        val tgtMidY = (tgtLEye.y + tgtREye.y) * 0.5f

        val srcEyeToMouth = hypot((source.mouthCenter.x - srcMidX).toDouble(), (source.mouthCenter.y - srcMidY).toDouble()).toFloat().coerceAtLeast(8f)
        val tgtMouth = PointF(tgtPts[3].x * sx, tgtPts[3].y * sy)
        val tgtEyeToMouth = hypot((tgtMouth.x - tgtMidX).toDouble(), (tgtMouth.y - tgtMidY).toDouble()).toFloat().coerceAtLeast(8f)
        val matchScaleX = (tgtEyeDist / srcEyeDist) * scaleMultiplier.coerceIn(0.6f, 1.6f)
        val rawScaleY = (tgtEyeToMouth / srcEyeToMouth) * scaleMultiplier.coerceIn(0.6f, 1.6f)
        val matchScaleY = rawScaleY.coerceIn(matchScaleX * 0.82f, matchScaleX * 1.22f)
        val deltaAngle = tgtAngle - srcAngle

        // Local skin-tone color matching
        val (tr, tg, tb) = sampleInnerFaceRgb(targetFrame, tgtPts[2].x, tgtPts[2].y, tgtFace.boundingBox.width() * 0.16f)
        val rGain = (tr / source.meanR.coerceAtLeast(24f)).coerceIn(0.80f, 1.26f)
        val gGain = (tg / source.meanG.coerceAtLeast(24f)).coerceIn(0.80f, 1.26f)
        val bGain = (tb / source.meanB.coerceAtLeast(24f)).coerceIn(0.80f, 1.26f)
        val colorCm = ColorMatrix(
            floatArrayOf(
                rGain, 0f, 0f, 0f, 0f,
                0f, gGain, 0f, 0f, 0f,
                0f, 0f, bGain, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val outBmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBmp)

        val alignMatrix = Matrix().apply {
            postTranslate(-srcMidX, -srcMidY)
            postRotate(deltaAngle)
            postScale(matchScaleX, matchScaleY)
            postTranslate(tgtMidX, tgtMidY)
        }

        val facePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(colorCm)
            alpha = (blendOpacity.coerceIn(0.2f, 1f) * 255).toInt()
        }
        canvas.drawBitmap(source.bitmap, alignMatrix, facePaint)

        // Clip & feather along actual ML Kit target face contour (or oval fallback)
        val maskBmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val maskCanvas = Canvas(maskBmp)
        val contour = tgtFace.getContour(FaceContour.FACE)?.points.orEmpty()
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            maskFilter = android.graphics.BlurMaskFilter((tgtEyeDist * 0.28f).coerceIn(8f, 34f), android.graphics.BlurMaskFilter.Blur.NORMAL)
        }
        if (contour.size >= 8) {
            val path = Path()
            val inset = 0.85f
            contour.forEachIndexed { idx, pt ->
                val px = tgtNose.x + (pt.x * sx - tgtNose.x) * inset
                val py = tgtNose.y + (pt.y * sy - tgtNose.y) * inset
                if (idx == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            maskCanvas.drawPath(path, maskPaint)
        } else {
            val bw = tgtFace.boundingBox.width() * sx * 0.42f * scaleMultiplier
            val bh = tgtFace.boundingBox.height() * sy * 0.46f * scaleMultiplier
            maskCanvas.drawOval(tgtNose.x - bw, tgtNose.y - bh, tgtNose.x + bw, tgtNose.y + bh, maskPaint)
        }

        if (lipSyncEnabled) {
            val lipPts = (tgtFace.getContour(FaceContour.UPPER_LIP_TOP)?.points.orEmpty() +
                tgtFace.getContour(FaceContour.LOWER_LIP_BOTTOM)?.points.orEmpty())
            val mCx: Float
            val mCy: Float
            val mRx: Float
            val mRy: Float
            if (lipPts.size >= 4) {
                val minX = lipPts.minOf { it.x * sx }
                val maxX = lipPts.maxOf { it.x * sx }
                val minY = lipPts.minOf { it.y * sy }
                val maxY = lipPts.maxOf { it.y * sy }
                mCx = (minX + maxX) * 0.5f
                mCy = (minY + maxY) * 0.5f
                mRx = ((maxX - minX) * 0.68f).coerceAtLeast(tgtEyeDist * 0.28f)
                mRy = ((maxY - minY) * 0.80f).coerceAtLeast(tgtEyeDist * 0.16f)
            } else {
                mCx = tgtPts[3].x * sx
                mCy = tgtPts[3].y * sy
                mRx = tgtEyeDist * 0.34f
                mRy = tgtEyeDist * 0.19f
            }
            val mouthCutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                alpha = 240
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
                maskFilter = android.graphics.BlurMaskFilter((tgtEyeDist * 0.14f).coerceIn(4f, 16f), android.graphics.BlurMaskFilter.Blur.NORMAL)
            }
            maskCanvas.drawOval(mCx - mRx, mCy - mRy, mCx + mRx, mCy + mRy, mouthCutPaint)
        }

        val xferPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        canvas.drawBitmap(maskBmp, 0f, 0f, xferPaint)
        maskBmp.recycle()
        outBmp
    }

    suspend fun prepareFeatheredFaceBitmap(faceUriStr: String): Bitmap? = withContext(Dispatchers.IO) {
        if (faceUriStr.isBlank()) return@withContext null
        val raw = runCatching {
            context.contentResolver.openInputStream(Uri.parse(faceUriStr))?.use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        }.getOrNull() ?: return@withContext null

        val faceBox = detectPrimaryFace(raw)
        val cropX: Int
        val cropY: Int
        val cropW: Int
        val cropH: Int
        if (faceBox != null) {
            cropW = (raw.width * faceBox.normWidth * 0.90f).toInt().coerceIn(48, raw.width)
            cropH = (raw.height * faceBox.normHeight * 1.02f).toInt().coerceIn(48, raw.height)
            cropX = ((raw.width * faceBox.normCenterX) - cropW / 2f).toInt().coerceIn(0, (raw.width - cropW).coerceAtLeast(0))
            cropY = ((raw.height * (faceBox.normCenterY + faceBox.normHeight * 0.04f)) - cropH / 2f).toInt().coerceIn(0, (raw.height - cropH).coerceAtLeast(0))
        } else {
            val side = minOf(raw.width, raw.height)
            cropX = (raw.width - side) / 2
            cropY = (raw.height - side) / 2
            cropW = side
            cropH = side
        }

        val cropped = Bitmap.createBitmap(raw, cropX, cropY, cropW, cropH)
        val outSize = 256
        val scaled = Bitmap.createScaledBitmap(cropped, outSize, outSize, true)
        if (cropped !== raw) cropped.recycle()
        raw.recycle()

        val result = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawBitmap(scaled, 0f, 0f, paint)
        scaled.recycle()

        val ovalMatrix = Matrix().apply {
            setScale(0.84f, 1.0f, outSize / 2f, outSize / 2f)
        }
        val grad = RadialGradient(
            outSize / 2f,
            outSize / 2f,
            outSize * 0.46f,
            intArrayOf(0xFFFFFFFF.toInt(), 0xDDFFFFFF.toInt(), 0x55FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.44f, 0.76f, 1f),
            Shader.TileMode.CLAMP
        ).apply { setLocalMatrix(ovalMatrix) }
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            shader = grad
        }
        canvas.drawRect(0f, 0f, outSize.toFloat(), outSize.toFloat(), maskPaint)
        result
    }


    suspend fun runCloudFaceSwapFrame(
        targetBmp: Bitmap,
        sourceBmp: Bitmap,
        apiKey: String,
        provider: String
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Enter your Cloud Face Swap API Key first."))
        }
        runCatching {
            fun bmpToB64(b: Bitmap): String {
                val baos = java.io.ByteArrayOutputStream()
                b.compress(Bitmap.CompressFormat.JPEG, 92, baos)
                return android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP)
            }
            val srcB64 = bmpToB64(sourceBmp)
            val tgtB64 = bmpToB64(targetBmp)

            if (provider.equals("Segmind", ignoreCase = true)) {
                val url = java.net.URL("https://api.segmind.com/v1/faceswap-v2")
                val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-api-key", cleanKey)
                }
                val body = org.json.JSONObject().apply {
                    put("source_img", srcB64)
                    put("target_img", tgtB64)
                    put("input_faces_index", 0)
                    put("source_faces_index", 0)
                    put("face_restore", "codeformer-v0.1.0.pth")
                    put("base64", false)
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                if (code !in 200..299) {
                    val err = conn.errorStream?.bufferedReader()?.readText() ?: "HTTP $code"
                    throw IllegalStateException("Segmind error ($code): ${err.take(120)}")
                }
                val bytes = conn.inputStream.use { it.readBytes() }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalStateException("Invalid image returned from Segmind.")
            } else {
                val url = java.net.URL("https://api.replicate.com/v1/predictions")
                val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $cleanKey")
                }
                val payload = org.json.JSONObject().apply {
                    put("version", "278a81e7ebb22db98bcba54de985d22cc1abeead2754eb4f217b9416254a0256")
                    put("input", org.json.JSONObject().apply {
                        put("swap_image", "data:image/jpeg;base64,$srcB64")
                        put("input_image", "data:image/jpeg;base64,$tgtB64")
                    })
                }
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val respText = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.readText().orEmpty()
                if (code !in 200..299) throw IllegalStateException("Replicate error ($code): ${respText.take(120)}")
                val pred = org.json.JSONObject(respText)
                val pollUrl = pred.optJSONObject("urls")?.optString("get").orEmpty()
                if (pollUrl.isBlank()) throw IllegalStateException("Missing Replicate poll URL.")
                var outUrl = ""
                for (attempt in 0 until 22) {
                    kotlinx.coroutines.delay(1500L)
                    val pConn = (java.net.URL(pollUrl).openConnection() as java.net.HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 15000
                        readTimeout = 20000
                        setRequestProperty("Authorization", "Bearer $cleanKey")
                    }
                    val pJson = org.json.JSONObject(pConn.inputStream.bufferedReader().readText())
                    val status = pJson.optString("status")
                    if (status == "succeeded") {
                        outUrl = pJson.optString("output").ifBlank {
                            pJson.optJSONArray("output")?.optString(0).orEmpty()
                        }
                        break
                    } else if (status == "failed" || status == "canceled") {
                        throw IllegalStateException("Replicate failed: ${pJson.optString("error")}")
                    }
                }
                if (outUrl.isBlank()) throw IllegalStateException("Cloud AI Swap timed out. Retry.")
                val imgBytes = java.net.URL(outUrl).openStream().use { it.readBytes() }
                BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.size)
                    ?: throw IllegalStateException("Could not decode Cloud AI result.")
            }
        }
    }


    suspend fun runCloudVideoFaceSwap(
        videoUri: Uri,
        sourceBmp: Bitmap,
        apiKey: String
    ): Result<Uri> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Enter your Replicate API Key first."))
        }
        runCatching {
            fun uploadToReplicate(bytes: ByteArray, fileName: String, mimeType: String): String {
                val boundary = "----KBBoundary${System.currentTimeMillis()}"
                val conn = (java.net.URL("https://api.replicate.com/v1/files").openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 25000
                    readTimeout = 90000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $cleanKey")
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                }
                conn.outputStream.use { out ->
                    out.write("--$boundary\r\n".toByteArray())
                    out.write("Content-Disposition: form-data; name=\"content\"; filename=\"$fileName\"\r\n".toByteArray())
                    out.write("Content-Type: $mimeType\r\n\r\n".toByteArray())
                    out.write(bytes)
                    out.write("\r\n--$boundary--\r\n".toByteArray())
                }
                val code = conn.responseCode
                val txt = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.readText().orEmpty()
                if (code !in 200..299) throw IllegalStateException("Upload error ($code): ${txt.take(120)}")
                val json = org.json.JSONObject(txt)
                return json.optJSONObject("urls")?.optString("get").orEmpty().ifBlank {
                    throw IllegalStateException("Missing uploaded file URL from Replicate.")
                }
            }

            val imgBaos = java.io.ByteArrayOutputStream()
            sourceBmp.compress(Bitmap.CompressFormat.JPEG, 92, imgBaos)
            val swapImgUrl = uploadToReplicate(imgBaos.toByteArray(), "source_face.jpg", "image/jpeg")

            val videoBytes = if (videoUri.scheme == "file" && videoUri.path != null) {
                java.io.File(videoUri.path!!).readBytes()
            } else {
                context.contentResolver.openInputStream(videoUri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("Cannot read video file.")
            }
            if (videoBytes.size > 45 * 1024 * 1024) {
                throw IllegalStateException("Trim video under 45 MB for Cloud AI Video Face Swap.")
            }
            val tgtVideoUrl = uploadToReplicate(videoBytes, "target_video.mp4", "video/mp4")

            val predConn = (java.net.URL("https://api.replicate.com/v1/predictions").openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 25000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $cleanKey")
                setRequestProperty("Content-Type", "application/json")
            }
            val payload = org.json.JSONObject().apply {
                put("version", "11b6bf0f4e14d808f655e87e5448233cceff10a45f659d71539cafb7163b2e84")
                put("input", org.json.JSONObject().apply {
                    put("swap_image", swapImgUrl)
                    put("target_video", tgtVideoUrl)
                })
            }
            predConn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val pCode = predConn.responseCode
            val pTxt = (if (pCode in 200..299) predConn.inputStream else predConn.errorStream)?.bufferedReader()?.readText().orEmpty()
            if (pCode !in 200..299) throw IllegalStateException("Replicate error ($pCode): ${pTxt.take(120)}")
            val pollUrl = org.json.JSONObject(pTxt).optJSONObject("urls")?.optString("get").orEmpty()
            if (pollUrl.isBlank()) throw IllegalStateException("Missing Replicate poll URL.")

            var outVideoUrl = ""
            for (attempt in 0 until 80) {
                kotlinx.coroutines.delay(3000L)
                val pollConn = (java.net.URL(pollUrl).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 25000
                    setRequestProperty("Authorization", "Bearer $cleanKey")
                }
                val j = org.json.JSONObject(pollConn.inputStream.bufferedReader().readText())
                val status = j.optString("status")
                if (status == "succeeded") {
                    outVideoUrl = j.optString("output").ifBlank {
                        j.optJSONArray("output")?.optString(0).orEmpty()
                    }
                    break
                } else if (status == "failed" || status == "canceled") {
                    throw IllegalStateException("Cloud Video Swap failed: ${j.optString("error")}")
                }
            }
            if (outVideoUrl.isBlank()) throw IllegalStateException("Cloud Video Swap timed out. Retry.")

            val outFile = java.io.File(context.cacheDir, "cloud_swap_vid_${System.currentTimeMillis()}.mp4")
            java.net.URL(outVideoUrl).openStream().use { inp ->
                java.io.FileOutputStream(outFile).use { out -> inp.copyTo(out) }
            }
            Uri.fromFile(outFile)
        }
    }

    fun close() {
        runCatching { detector.close() }
    }
}
